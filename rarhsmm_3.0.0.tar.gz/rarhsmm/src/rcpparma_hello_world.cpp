// -*- mode: C++; c-indent-level: 4; c-basic-offset: 4; indent-tabs-mode: nil; -*-

// we only include RcppArmadillo.h which pulls Rcpp.h in for us
#include "RcppArmadillo.h"

// via the depends attribute we tell Rcpp to create hooks for
// RcppArmadillo so that the build process will know what to do
//
// [[Rcpp::depends(RcppArmadillo)]]

// simple example of creating two matrices and
// returning the result of an operatioon on them
//
// via the exports attribute we tell Rcpp to make this function
// available from R
//
////////////////////

/////////////////////////
// [[Rcpp::export]]
arma::mat vectorize(arma::mat mat, int axis){
    int row = mat.n_rows;
    int col = mat.n_cols;
    int i,j;
    arma::mat result(row*col,1);
    for(i=0;i<row;i++){
        for(j=0;j<col;j++){
            if(axis==0)  result(i+j*row,0) = mat(i,j);  // by column
            else result(j+i*col,0) = mat(i,j); //by row
        }
    }
    return result;
}
///////////////////////////////////////
// [[Rcpp::export]]
arma::vec colsum(arma::mat matrix){
    long row = matrix.n_rows;
    int col = matrix.n_cols;
    long i;
    int j;
    arma::vec columnsum(col);

    for(j=0; j<col; j++) columnsum(j) = 0;
    for(i=0; i<row; i++){
        for(j=0; j<col; j++){
            columnsum(j) += matrix(i,j);
        }
    }
    return columnsum;
}

///////////////////////////////////////
// [[Rcpp::export]]
arma::vec rowsum(arma::mat matrix){
    long row = matrix.n_rows;
    int col = matrix.n_cols;
    long i;
    int j;
    arma::vec rowsum(row);

    for(i=0; i<row; i++) rowsum(i) = 0;
    for(j=0; j<col; j++){
        for(i=0; i<row; i++){
            rowsum(i) += matrix(i,j);
        }
    }
    return rowsum;
}

//////////////////////////////////////////////////////////////////////////////////
//subset a big matrix by the beginning and ending of row/col index
// [[Rcpp::export]]
arma::mat subsetmatrix(arma::mat rawmat, arma::vec rowindex, arma::vec colindex){
    int row = rowindex(1) - rowindex(0) + 1;
    int col = colindex(1) - colindex(0) + 1;
    arma::mat result(row,col);
    int i,j;
    for(i=0;i<row;i++){
        for(j=0;j<col;j++){
            result(i,j) = rawmat(rowindex(0)+i,colindex(0)+j);
        }
    }
    return result;
}

/////////////////////////////
//compute matrix power
// [[Rcpp::export]]
arma::mat matrixpower(arma::mat oldmat, int power){
    arma::mat newmat = oldmat;
    int i;

    for(i=1;i<power;i++) newmat *= oldmat;

    return newmat;
}

///////////////////////////
//compute matrix exponential
// [[Rcpp::export]]
arma::mat matrixexp(arma::mat oldmat, double t){
    arma::mat temp = t * oldmat;
    arma::mat newmat = arma::expmat(temp);
    return newmat;
}

/////////////
// [[Rcpp::export]]
double matrixsum(arma::mat mat1, arma::mat mat2){
    double tempsum=0;
    arma::mat temp = mat1 % mat2;
    int row = mat1.n_rows;
    int col = mat1.n_cols;
    int i,j;
    for(i=0;i<row;i++){
        for(j=0;j<col;j++){
            tempsum += temp(i,j);
        }
    }
    return(tempsum);
}

////////////
//integral of matrix exponential
// x and y starts from 0
// [[Rcpp::export]]
arma::mat matrixintegral(arma::mat Q, double interval, int x, int y){
    int M = Q.n_cols;
    arma::mat temp(2*M, 2*M);
    temp.zeros();
    int i,j;

    for(i=0;i<M;i++)
    for(j=0;j<M;j++)
    temp(i,j) = Q(i,j);

    for(i=M;i<2*M;i++)
    for(j=M;j<2*M;j++)
    temp(i,j) = Q(i-M,j-M);

    temp(x, M+y) = 1;


    arma::mat temp1 = matrixexp(temp, interval);
    //Rcpp::Rcout<<temp1<<std::endl;
    arma::vec rowindex(2);
    arma::vec colindex(2);
    rowindex(0)=0; rowindex(1) = M-1; colindex(0) = M; colindex(1) = 2*M-1;
    arma::mat result = subsetmatrix(temp1,rowindex,colindex);
    return result;
}



/////////////
//convert discrete time HSMM tpm to discrete time HMM tpm with expanded states
//[[Rcpp::export]]
arma::mat hsmm_hmm (arma::mat omega, arma::mat dm, arma::vec mv){
    //each row in dm is a dwell time pmf
    //mv is vector of the length until the first zero in each dwell time distribution
    int m = omega.n_rows;
    int dmrow = dm.n_rows;
    int dmcol = dm.n_cols;
    int dim = arma::sum(mv); // dimension of the final result

    int i,j,p,q,mi,rowsum,colsum;
    //double tempsum;
    arma::mat temp(dmrow,dmcol);
    arma::mat ci(dmrow,dmcol);
    arma::mat cim(dmrow,dmcol);
    arma::mat gamma(dim,dim);

    //Rcpp::Rcout << dim << std::endl;

    for(i=0;i<m;i++){
        mi = mv[i];

        for(j=0;j<mi;j++){
            if(j==0) temp(i,j) = 0;
            else temp(i,j) = temp(i,j-1) + dm(i,j-1);
        }

        for(j=0;j<mi;j++){
            if(std::abs(1-temp(i,j))>0.000000001) ci(i,j) = dm(i,j)/(1-temp(i,j));
            else ci(i,j) = 1;
            if(1-ci(i,j)>0) cim(i,j)=1-ci(i,j);
            else cim(i,j) = 0;
        }
    }

    rowsum = 0;


    for(i=0; i<m; i++){
        colsum = 0;
        for(j=0; j<m; j++){
            if(i==j){
                if(mv[i]==1) gamma(rowsum,colsum) = cim(i,0);
                else{
                    for(p=0; p<mv[i]; p++){
                        for(q=0; q<mv[j]; q++){
                            if((q-p)==1) gamma(rowsum+p,colsum+q)=cim(i,p);
                            else if((p==mv[i]-1) & (q==mv[j]-1)) gamma(rowsum+p,colsum+q)=cim(i,p);
                            else gamma(rowsum+p,colsum+q)=0;
                        }
                    }
                }
            }
            else{
                for(p=0; p<mv[i]; p++){
                    for(q=0; q<mv[j]; q++){
                        if(q==0) gamma(rowsum+p, colsum+q)=omega(i,j)*ci(i,p);
                        else gamma(rowsum+p, colsum+q)=0;
                    }
                }

            }
            colsum += mv[j];
        }
        rowsum += mv[i];
    }


    return(gamma);

}



/////////////////////////////////
//multinomial RNG
//' multinomial random variable generator
//' @param n number of random variables to generate
//' @param k number of categories
//' @param prob vector of probabilities summing up to 1
//' @param label vector of labels for each category
//' @return multinomial random variables
//' @export
//[[Rcpp::export]]
arma::vec rmultinomial(int n, int k, arma::vec prob, arma::vec label){
    arma::vec result(n);
    arma::vec cumprob(k);
    int i,j;
    double u;

    cumprob(0) = prob(0);
    for(i=1; i<k;i++){
        cumprob(i) = cumprob(i-1) + prob(i);
    }


    for(j=0;j<n;j++){
        u = Rcpp::runif(1,0,1)(0);   //to make type match
        for(i=0; i<k;i++){
            if(u<cumprob(i)) {
                result(j) = label(i);
                break;
            }
        }
    }
    return(result);
}


///////////////////////////////////////////////////////
//generate multivariate normal random variables
//' multivariate normal random number generator
//' @param n number of random vectors to generate
//' @param mu vector of means
//' @param sigma variance-covariance matrix
//' @return a matrix with each row as a realization of multivariate normal random vector
//' @export
// [[Rcpp::export]]
arma::mat mvrnorm(int n, arma::vec mu, arma::mat sigma) {
    int ncols = sigma.n_cols;
    arma::mat Y = arma::randn(n, ncols); //row vector of standard normal RVs
    return arma::repmat(mu, 1, n).t() + Y * arma::chol(sigma); // chol() returns upper by default
}

////////////////////////////////
//multivariate normal density
//' multivariate normal density
//' @param x matrix with each row as an observed vector of multivariate normal RVs
//' @param mean vector of means
//' @param sigma variance-covariance matrix
//' @param logd whether log transformation should be used
//' @return a vector of density values for each observed vector
//' @export
// [[Rcpp::export]]
arma::vec mvdnorm(arma::mat x,
                  arma::rowvec mean,
                  arma::mat sigma,
                  bool logd) {
    const double log2pi = std::log(2.0 * M_PI);
    int n = x.n_rows;
    int xdim = x.n_cols;
    arma::vec out(n);
    arma::mat rooti = arma::trans(arma::inv(trimatu(arma::chol(sigma)))); //generate upper triangular
    double rootisum = arma::sum(log(rooti.diag()));
    double constants = -(static_cast<double>(xdim)/2.0) * log2pi;

    for (int i=0; i < n; i++) {
        arma::vec z = rooti * arma::trans( x.row(i) - mean) ;
        out(i)      = constants - 0.5 * arma::sum(z%z) + rootisum;
    }

    if (logd == FALSE) {
        out = exp(out);
    }
    return(out);
}

//number of trials before failure (p=prob of failure)
//[[Rcpp::export]]
arma::vec rgeometric(int n, double pp){
    arma::vec result;
    result = Rcpp::rgeom(n,pp)+1;
    return result;
}

//[[Rcpp::export]]
double dgeometric(int x, double pp, bool loga){
    double result;
    result = R::dgeom(x-1, pp, loga);
    return result;
}




///////////////////////////////////////////////////////////////////////////
/*part 2: simulate a hidden Markov series*/


///////////////////////////
//generate multivariate normal hidden markov time series
//[[Rcpp::export]]
Rcpp::List mvnhmm_gen (long n, int M, int d, arma::vec prior, arma::mat tpm,
                       Rcpp::List meanlist, Rcpp::List sigmalist){

    int prev, curr, i, j;
    arma::vec label(M);

    arma::mat series(n,d);
    arma::vec state(n);

    for(i=0; i<M; i++) label(i) = i + 1;

    //initial state
    state(0) = rmultinomial(1, M, prior, label)(0);
    curr = state(0) - 1;
    series.row(0) = mvrnorm(1, meanlist(curr), sigmalist(curr));

    //recursion
    for(j=1; j<n; j++){
        prev = state(j-1) - 1;
        state(j) = rmultinomial(1, M, tpm.row(prev).t(), label)(0);

        curr = state(j) - 1;
        series.row(j) = mvrnorm(1, meanlist(curr), sigmalist(curr));
    }

    return Rcpp::List::create(Rcpp::Named("series")=series,
                              Rcpp::Named("state")=state);

}



/////////////////////////////////////
/*part 3: log likelihoods*/
///////////////////////////////////////////
////////////////////////////////
// [[Rcpp::export]]
arma::mat getnodeprob_nocov_mvn(arma::mat ystar, Rcpp::List mean, Rcpp::List sigma,
                                int m, int p, int arp, Rcpp::List automat){
    long ns = ystar.n_rows; //original numeric series starting from 1

    arma::mat nodeprob(ns, m);
    arma::mat tempmat(1,p);
    long i;
    int j;

    if(arp==0){
        for(i=0;i<ns;i++){
            for(j=0;j<m;j++){
                tempmat = ystar.row(i);
                nodeprob(i,j) = mvdnorm(tempmat,mean(j),sigma(j),FALSE)(0);
            }
        }
    }

    return nodeprob;
}

////////////////////////////////
// [[Rcpp::export]]
arma::mat getnodeprob_part2(arma::mat y, arma::mat x, arma::cube beta, arma::cube mu, Rcpp::List sigma,
                                int m, int p){
    long ns = y.n_rows; //original numeric series starting from 1

    arma::mat nodeprob(ns, m);
    arma::mat tempmat(1,p);
    arma::mat mean(1,p);
    long i;
    int j;


        for(i=0;i<ns;i++){
            for(j=0;j<m;j++){
                tempmat = y.row(i);
                mean = mu.slice(j) + x.row(i) * beta.slice(j).t();
                //Rcpp::Rcout<<mean<<std::endl;
                nodeprob(i,j) = mvdnorm(tempmat,mean,sigma(j),FALSE)(0);
            }
        }


    return nodeprob;
}




////////////////////////////////////////////////////
// this forward-backward can be used to build the smoothing function for prediction and interpolation
// [[Rcpp::export]]
Rcpp::List forwardbackward(arma::vec Pi, arma::mat P, arma::mat nodeprob,
                           long dim, arma::vec ntimes){


    int M = nodeprob.n_cols;
    int n = ntimes.n_rows;
    int j,m,t,i,k;
    double tempsum;
    arma::vec tempval;
    arma::mat tempmat(1,M);
    arma::mat tempmat2(M,M);

    arma::mat alpha(dim, M);
    arma::vec scale(dim);
    arma::mat beta(dim, M);
    arma::mat Gamma(dim, M);
    arma::mat xi(dim-1, M*M);

    arma::vec colsumgamma(M);
    arma::vec tempsumxi(M*M);
    arma::mat colsumxi(M,M);
    double loglik = 0;

    int count = 0;
    for(j=0; j<n; j++){

        //forward probs
        alpha.row(count) = Pi.t() % nodeprob.row(count);
        tempval = nodeprob.row(count) * Pi;
        scale(count) = tempval(0);//double
        for(m=0; m<M; m++) alpha(count, m) = alpha(count,m) / scale(count);

        for(t=1; t<ntimes(j); t++){
            tempmat = alpha.row(count+t-1) * P; //row matrix
            alpha.row(count+t) = tempmat % nodeprob.row(count+t);
            tempval = tempmat * nodeprob.row(count+t).t();
            scale(count+t) = tempval(0);//double
            for(m=0; m<M; m++) alpha(count+t, m) = alpha(count+t,m) / scale(count+t);
        }

        //backward probs and state conditional probs
        for(m=0; m<M; m++) beta(count + ntimes(j) - 1,m) = 1 / (M * scale(count + ntimes(j) - 1));
        Gamma.row(count+ntimes(j)-1) = alpha.row(count+ntimes(j)-1) % beta.row(count+ntimes(j)-1);
        tempval = alpha.row(count+ntimes(j)-1) * beta.row(count+ntimes(j)-1).t();
        for(m=0; m<M; m++) Gamma(count+ntimes(j)-1,m)=Gamma(count+ntimes(j)-1,m)/tempval(0); //double

        for(t=ntimes(j)-2; t>=0; t--){
            tempmat = beta.row(count+t+1) % nodeprob.row(count+t+1);
            beta.row(count+t) = tempmat * P.t();
            for(m=0; m<M; m++) beta(count+t,m) = beta(count+t,m) / scale(count + t);

            Gamma.row(count+t) = alpha.row(count+t) % beta.row(count+t);
            tempval = alpha.row(count+t) * beta.row(count+t).t();
            for(m=0; m<M; m++) Gamma(count+t,m)=Gamma(count+t,m)/tempval(0); //double
        }

        //transition probs
        for(t=0; t<ntimes(j)-1; t++){
            tempmat = beta.row(count+t+1) % nodeprob.row(count+t+1);
            tempmat2 = P % (alpha.row(count+t).t() * tempmat);

            tempsum = 0;
            for(i=0; i<M; i++){
                for(k=0; k<M; k++){
                    xi(count+t, i + k*M) = tempmat2(i,k);
                    tempsum += xi(count+t, i + k*M);
                }
            }

            for(m=0; m<M*M; m++) xi(count+t, m) = xi(count+t, m) / tempsum;
        }

        count += ntimes(j);
    }


    //get the column sums
    colsumgamma = colsum(Gamma);
    tempsumxi = colsum(xi);

    for(i=0; i<M; i++)
    for(k=0; k<M; k++)
    colsumxi(i,k) = tempsumxi(i+k*M);

    loglik = arma::sum(log(scale));

    return Rcpp::List::create(Rcpp::Named("colsumgamma")=colsumgamma,
                              Rcpp::Named("colsumxi")=colsumxi,
                              Rcpp::Named("Gamma")=Gamma,
                              Rcpp::Named("xi")=xi,
                              Rcpp::Named("loglik")=loglik);
}


//////////////////////////
// generic function for loglikelihood for HMM
// [[Rcpp::export]]
double hmmllk(arma::vec delta, arma::mat gamma, arma::mat nodeprob,
              arma::vec y, arma::vec ntimes, arma::vec timeindex,int missing){
    double loglik = 0;
    //long dim = y.n_rows;
    int M = nodeprob.n_cols;
    int n = ntimes.n_rows;
    int j,m,t;
    double tempsum;

    arma::vec forward(M);
    arma::vec forwardsum;  //then forwardsum(0) is double
    arma::mat tempmat(1,M);
    arma::mat transit(M,M);
    int interval=1;

    int count = 0;
    //Rcpp::Rcout << arma::max(timeindex) << std::endl;
    //Rcpp::Rcout << y.n_rows << std::endl;

    if(missing==0){ //no missing

        for(j=0; j<n; j++){

            tempsum = 0;
            //initialize the forward variable
            forward = delta % nodeprob.row(count).t(); //element wise multiplication
            forwardsum = delta.t() * nodeprob.row(count).t();
            tempsum = log(forwardsum(0));
            //Rcpp::Rcout << "loglik=" << loglik << std::endl;

            for(m=0; m<M; m++) forward(m) = forward(m) / forwardsum(0);

            //recursion
            for(t=1; t<ntimes(j); t++){

                tempmat = forward.t() * gamma; //row matrix
                forward = tempmat.t() % nodeprob.row(count+t).t();
                forwardsum = tempmat * nodeprob.row(count+t).t();
                tempsum += log(forwardsum(0));
                for(m=0; m<M; m++) forward(m) = forward(m) / forwardsum(0);
            }

            loglik += tempsum;
            count += ntimes(j);
        }
    }
    else{ //missing
        for(j=0; j<n; j++){

            tempsum = 0;
            //initialize the forward variable
            forward = delta % nodeprob.row(count).t(); //element wise multiplication
            forwardsum = delta.t() * nodeprob.row(count).t();
            tempsum = log(forwardsum(0));
            //Rcpp::Rcout << "loglik=" << loglik << std::endl;

            for(m=0; m<M; m++) forward(m) = forward(m) / forwardsum(0);

            //recursion
            for(t=1; t<ntimes(j); t++){
                //calculate interval from last time point
                interval = timeindex(count+t) - timeindex(count+t-1);
                transit = matrixpower(gamma, interval);

                tempmat = forward.t() * transit; //row matrix
                forward = tempmat.t() % nodeprob.row(count+t).t();
                forwardsum = tempmat * nodeprob.row(count+t).t();
                tempsum += log(forwardsum(0));
                for(m=0; m<M; m++) forward(m) = forward(m) / forwardsum(0);
            }

            loglik += tempsum;
            count += ntimes(j);
        }

    }

    return loglik;

}



//////////////////////////////////////////////////////////////
/*part 3: continuous time hidden markov model*/
/*missing value interpolation*/
/*smoothing, soft-cluster*/

//////////////////////////
// generic function for loglikelihood for HMM
// [[Rcpp::export]]
double hmmllk_cont(arma::vec delta, arma::mat gamma, arma::mat nodeprob,
                   arma::vec y, arma::vec ntimes, arma::vec timeindex){
    double loglik = 0;
    //long dim = y.n_rows;
    int M = nodeprob.n_cols;
    int n = ntimes.n_rows;
    int j,m,t;
    double tempsum;

    arma::vec forward(M);
    arma::vec forwardsum;  //then forwardsum(0) is double
    arma::mat tempmat(1,M);
    arma::mat transit(M,M);
    int interval=1;

    int count = 0;
    //Rcpp::Rcout << arma::max(timeindex) << std::endl;
    //Rcpp::Rcout << y.n_rows << std::endl;


    for(j=0; j<n; j++){

        tempsum = 0;
        //initialize the forward variable
        forward = delta % nodeprob.row(count).t(); //element wise multiplication
        forwardsum = delta.t() * nodeprob.row(count).t();
        tempsum = log(forwardsum(0));
        //Rcpp::Rcout << 0 << "," << tempsum << std::endl;

        for(m=0; m<M; m++) forward(m) = forward(m) / forwardsum(0);

        //recursion
        for(t=1; t<ntimes(j); t++){
            //calculate interval from last time point
            interval = timeindex(count+t) - timeindex(count+t-1);
            //interval = MIN(interval, 50);
            transit = matrixexp(gamma, interval);

            tempmat = forward.t() * transit; //row matrix
            forward = tempmat.t() % nodeprob.row(count+t).t();
            forwardsum = tempmat * nodeprob.row(count+t).t();
            tempsum += log(forwardsum(0));
            for(m=0; m<M; m++) forward(m) = forward(m) / forwardsum(0);
            //Rcpp::Rcout << t << "," << tempsum << std::endl;
        }

        loglik += tempsum;
        count += ntimes(j);
    }

    return loglik;

}


//////////////////////////////////////////////////////////////////////
// [[Rcpp::export]]
Rcpp::List fb_cont(arma::vec Pi, arma::mat P, arma::mat nodeprob,
                   long dim, arma::vec ntimes, arma::vec timeindex){


    int M = nodeprob.n_cols;
    int n = ntimes.n_rows;
    int j,m,t,i,k;
    int interval;
    arma::mat transit(M,M);
    double tempsum;
    arma::vec tempval;
    arma::mat tempmat(1,M);
    arma::mat tempmat2(M,M);

    arma::mat alpha(dim, M);
    arma::vec scale(dim);
    arma::mat beta(dim, M);
    arma::mat Gamma(dim, M);
    arma::mat xi(dim-1, M*M);

    arma::vec colsumgamma(M);
    arma::vec tempsumxi(M*M);
    arma::mat colsumxi(M,M);
    double loglik = 0;

    int count = 0;
    for(j=0; j<n; j++){

        //forward probs
        alpha.row(count) = Pi.t() % nodeprob.row(count);
        tempval = nodeprob.row(count) * Pi;
        scale(count) = tempval(0);//double
        for(m=0; m<M; m++) alpha(count, m) = alpha(count,m) / scale(count);

        for(t=1; t<ntimes(j); t++){

            interval = timeindex(count+t) - timeindex(count+t-1);
            transit = matrixexp(P,interval);

            tempmat = alpha.row(count+t-1) * transit; //row matrix
            alpha.row(count+t) = tempmat % nodeprob.row(count+t);
            tempval = tempmat * nodeprob.row(count+t).t();
            scale(count+t) = tempval(0);//double
            for(m=0; m<M; m++) alpha(count+t, m) = alpha(count+t,m) / scale(count+t);
        }

        //backward probs and state conditional probs
        for(m=0; m<M; m++) beta(count + ntimes(j) - 1,m) = 1 / (M * scale(count + ntimes(j) - 1));
        Gamma.row(count+ntimes(j)-1) = alpha.row(count+ntimes(j)-1) % beta.row(count+ntimes(j)-1);
        tempval = alpha.row(count+ntimes(j)-1) * beta.row(count+ntimes(j)-1).t();
        for(m=0; m<M; m++) Gamma(count+ntimes(j)-1,m)=Gamma(count+ntimes(j)-1,m)/tempval(0); //double

        for(t=ntimes(j)-2; t>=0; t--){
            interval = timeindex(count+t+1) - timeindex(count+t);
            transit = matrixexp(P, interval);

            tempmat = beta.row(count+t+1) % nodeprob.row(count+t+1);
            beta.row(count+t) = tempmat * transit.t();
            for(m=0; m<M; m++) beta(count+t,m) = beta(count+t,m) / scale(count + t);

            Gamma.row(count+t) = alpha.row(count+t) % beta.row(count+t);
            tempval = alpha.row(count+t) * beta.row(count+t).t();
            for(m=0; m<M; m++) Gamma(count+t,m)=Gamma(count+t,m)/tempval(0); //double
        }



        //transition probs
        for(t=0; t<ntimes(j)-1; t++){
            interval = timeindex(count+t+1) - timeindex(count+t);
            transit = matrixexp(P, interval);

            tempmat = beta.row(count+t+1) % nodeprob.row(count+t+1);
            tempmat2 = transit % (alpha.row(count+t).t() * tempmat);

            tempsum = 0;
            for(i=0; i<M; i++){
                for(k=0; k<M; k++){
                    xi(count+t, i + k*M) = tempmat2(i,k);
                    tempsum += xi(count+t, i + k*M);
                }
            }
            //Rcpp::Rcout<<count+t<<std::endl;
            for(m=0; m<M*M; m++) xi(count+t, m) = xi(count+t, m) / tempsum;
        }

        count += ntimes(j);
    }


    //get the column sums
    colsumgamma = colsum(Gamma);
    tempsumxi = colsum(xi);

    for(i=0; i<M; i++)
    for(k=0; k<M; k++)
    colsumxi(i,k) = tempsumxi(i+k*M);

    loglik = arma::sum(log(scale));

    return Rcpp::List::create(Rcpp::Named("colsumgamma")=colsumgamma,
                              Rcpp::Named("colsumxi")=colsumxi,
                              Rcpp::Named("Gamma")=Gamma,
                              Rcpp::Named("xi")=xi,
                              Rcpp::Named("loglik")=loglik);
}

///////////////////////////////////////////
///////////////////////////////
//FOR PAPER 6: CONTINUOUS-TIME SEMI-MARKOV PROCESS
//' compute transition probability matrix for semi-Markov process
//' @param parmmat matrix where 1st column is Gamma shape and 2nd column is scale for off-diagonals
//' @param M number of states
//' @param time interval between this and next observations
//' @param ngrid number of grid points for approximation
//' @param lower starting grid
//' @return transition probability matrix
//' @export
// [[Rcpp::export]]
arma::mat smprcpp(arma::mat parmmat, int M, double time, int ngrid, double lower){
    int i,j,k,m,s,t,nextindex;
    arma::cube pp(M,M,ngrid);
    pp.zeros();
    for(i=0; i<M; i++)
        pp(i,i,0) = 1;

    arma::vec grids(ngrid);
    double h = (time - lower) / (ngrid - 1);
    for(i=0; i<ngrid; i++)
        grids(i) = lower + i * h;

    arma::cube densities(M,M,ngrid);
    densities.zeros();
    arma::cube cdfs(M,M,ngrid);
    cdfs.zeros();


    for(m=0; m<ngrid; m++){
        nextindex = 0;
        for(i=0; i<M; i++){
            for(j=0; j<M; j++){
                if(i!=j){
                    densities(i,j,m) = R::dgamma(grids(m),parmmat(nextindex,0),parmmat(nextindex,1),FALSE);
                    cdfs(i,j,m) = R::pgamma(grids(m),parmmat(nextindex,0),parmmat(nextindex,1),TRUE,FALSE);
                    nextindex += 1;
                    //Rcpp::Rcout<<i<<"and"<<j<<"and"<<m<<std::endl;
                }
            }
        }
    }

    //Rcpp::Rcout<<cdfs.slice(0)<<std::endl;

    double tempsum;
    double part1;
    double part2;
    double temprowsum;

    for(m=1; m<ngrid; m++){
        for(i=0; i<M; i++){
            for(j=0; j<M; j++){
                if(i!=j){
                    pp(i,j,m) = 0;

                    for(k=0; k<M; k++){
                        if(k!=i){

                            tempsum = 0;
                            for(s=0; s<m-1; s++){
                                part1 = pp(k,j,m-s-2);

                                temprowsum = 0;
                                for(t=0; t<M; t++){
                                    temprowsum += cdfs(i,t,s);
                                }

                                part2 = densities(i,k,s)*cdfs(i,k,s)/temprowsum;

                                tempsum += part1 * part2;

                            }

                            pp(i,j,m) += h*tempsum;

                            /*
                             double result=0;
                             for(int i=0; i<m-1; i++){
                             result += vec1(m-i-2) * vec2(i);
                             }
                             */

                        }
                    }

                }
            }
        }


        for(i=0; i<M; i++){
            temprowsum = 0;
            for(t = 0; t<M; t++) temprowsum += pp(i,t,m);
            if(temprowsum<1) pp(i,i,m) = 1 - temprowsum;
            else pp(i,i,m) = 0;
        }

    }

    return pp.slice(ngrid-1);

}


///////////////////////////////////////////////////////////////////
// [[Rcpp::export]]
double getmindiag(arma::mat mat){
    int p = mat.n_cols;
    arma::vec temp(p);
    for(int i =0; i<p; i++) temp(i) = mat(i,i);
    double min = temp.min();
    return min;
}

////////////////////////////////////////////////////////////////
//delta, scalevec, mumat, variance, csparm, arcube
//[[Rcpp::export]]
Rcpp::List retrieve_ar1smp(arma::vec allparm,int M, int ncolscale, int ncolx){
    
    int i,j,k,nextindex = 0;
    double temp1, temp2;
    
    arma::mat scalemat(M*(M-1), ncolscale);
    arma::mat mumat(M, ncolx);
    arma::mat tempmat(ncolx, ncolx);
    arma::cube covcube(ncolx,ncolx,M);
    arma::cube arcube(ncolx,ncolx,M);
    
    scalemat.zeros();
    mumat.zeros();
    covcube.zeros();
    arcube.zeros();
    
    //shapemat: M*(M-1)*(ncolshape)
    for(i=0; i<M*(M-1); i++){
        for(j=0; j<ncolscale; j++){
            scalemat(i,j) = allparm(nextindex + i*ncolscale + j);
        }
    }
    nextindex += M*(M-1)*ncolscale;
    //Rcpp::Rcout<<shapemat<<std::endl;
    
    
    //mumat: M*ncolx
    for(i=0; i<M; i++){
        for(j=0; j<ncolx; j++){
            mumat(i,j) = allparm(nextindex + i*ncolx + j);
        }
    }
    nextindex += M*ncolx;
    //Rcpp::Rcout<<mumat<<std::endl;
    
    //variance: M * ncolx, log(variance)
    for(k=0; k<M; k++){
        for(i=0; i<ncolx; i++){
            covcube(i,i,k) = exp(allparm(nextindex + k*ncolx + i));
        }
    }
    nextindex += M*ncolx;
    
    //Rcpp::Rcout<<covcube<<std::endl;
    //csparm: M,
    /*
     for(k=0; k<M; k++){
     tempmat = covcube.slice(k);
     tempsum = getmindiag(tempmat);
     
     for(i=0; i<ncolx; i++){
     for(j=0; j<ncolx; j++){
     
     if(i!=j){
     covcube(i,j,k) = 0.9 * tempsum * exp(allparm(nextindex + k))/(1+exp(allparm(nextindex+k))) ;
     }
     
     }
     }
     }
     nextindex += M;
     */
    //Rcpp::Rcout<<covcube<<std::endl;
    //arcube: M * ncolx, tanh to get between -1 and 1
    for(k=0; k<M; k++){
        for(i=0; i<ncolx; i++){
            temp1 = exp(allparm(nextindex+k*ncolx+i));
            temp2 = exp(-allparm(nextindex+k*ncolx+i));
            arcube(i,i,k) = (temp1 - temp2) / (temp1 + temp2);
        }
    }
    // Rcpp::Rcout<<arcube<<std::endl;
    return Rcpp::List::create(Rcpp::Named("scalemat")=scalemat,
                              Rcpp::Named("mumat")=mumat,
                              Rcpp::Named("covcube")=covcube,
                              Rcpp::Named("arcube")=arcube);
}

///////////////////////////////////////////////////////
//[[Rcpp::export]]
arma::mat getscale(arma::vec xvec, arma::mat scalemat, int m){
    //int k = scalemat.n_rows;
    int i,j,k;
    arma::vec tempval;
    arma::mat result(m,m);
    result.zeros();
    double tempsum;
    //xvec: intercept + trt
    k=0;
    
    for(i=0;i<m;i++){
        tempsum = 0;
        for(j=0;j<m;j++){
            
            if (j==i) {
                continue;
            }
            else{
                tempval = scalemat.row(k) * xvec;
                result(i,j) = exp(tempval(0)) / (1 + exp(tempval[0]));
                k++;
                tempsum += result(i,j);
            }
        }
        result(i,i) = - tempsum;
    }
    
    return result;
}

/////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////
//[[Rcpp::export]]
arma::mat get_transit(arma::vec xvec, arma::mat scalemat, double time, int m){
    //xvec: intercept + trt
    arma::mat parmmat = getscale(xvec, scalemat, m);
    arma::mat transit = matrixexp(parmmat, time);
    return transit;

}


////////////////////////////////
// [[Rcpp::export]]
arma::mat getnodeprob_ar1(arma::mat y, arma::mat mumat, arma::cube covcube, arma::cube arcube){
    long ns = y.n_rows; //original numeric series starting from 1

    int m = mumat.n_rows;
    int p = mumat.n_cols;
    arma::mat nodeprob(ns, m);
    arma::mat tempmat(1,p);
    arma::mat mean(1,p);
    long i;
    int j;


    for(i=0;i<ns;i++){
        for(j=0;j<m;j++){
            tempmat = y.row(i);

            if(i==0){
                mean = mumat.row(j);
            }else{
                mean = mumat.row(j) + y.row(i-1) * arcube.slice(j);
            }

            //Rcpp::Rcout<<mean<<std::endl;
            nodeprob(i,j) = mvdnorm(tempmat,mean,covcube.slice(j),FALSE)(0);
        }
    }


    return nodeprob;
}



////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////
//' pmf for truncated zero-inflated poisson
//' @param p proportion of structural zero's
//' @param theta the poisson mean
//' @param upper the upper bound
//' @param y the observed value
//' @param loga Logical. Whether to return the log probability or not.
//' @return the probability mass of the zero-inflated poisson distribution
//' @export
// [[Rcpp::export]]
double dzip(double p, double theta, int upper, int y, bool loga){
    double result;
    double den;

    if(upper == 0){
        if(loga == FALSE) result = 1;
        else result = 0;
    }
    else{
        den = p + (1-p) * R::ppois(upper,theta,TRUE,FALSE);
        if(loga == FALSE){
            if(y==0) result = (p + (1-p) * exp(-theta)) / den;
            else result = (1-p) * R::dpois(y, theta, loga) / den;
        }
        else{
            if(y==0) result = log(p + (1-p) * exp(-theta)) - log(den);
            else result = log(1-p) + R::dpois(y, theta, loga) - log(den);
        }
    }
    return result;

}

////////////////////////////////////////////////////////////
// [[Rcpp::export]]
arma::vec rzip(int n, double p, double theta, int upper){
    arma::vec result(n);
    int i;
    double u;
    int temp;

    for(i=0;i<n;i++){
        u =  Rcpp::runif(1,0,1)(0);
        if(u <= p) result(i) = 0;
        else {
            temp = Rcpp::rpois(1, theta)(0);
            if(temp > upper) result(i) = upper;
            else result(i) = temp;
        }
    }
    return result;
}


///////////////////////////////////////////////////////////////////
// [[Rcpp::export]]
Rcpp::List ar1_smp_nllk_single1(arma::vec delta, arma::mat scalemat,
                               arma::mat mumat, arma::cube covcube, arma::cube arcube,
                               arma::vec time, int M,
                                arma::mat x, arma::mat trtmat){
    //trtmat include intercept
    double nllk = 0;
    int n = x.n_rows; //excluding baseline row
    int j,m;
    double interval;

    arma::mat transit(M,M);
    arma::vec tempval;
    arma::mat tempmat(1, M);
    //arma::mat parmmat(M*(M-1),2);
    arma::mat alpha(n+1,M);
    arma::vec scale(n+1);
    
    //initialize
    arma::mat nodeprob = getnodeprob_ar1(x, mumat, covcube, arcube);
    for(m=0; m<M; m++) alpha(0,m) = delta(m);
    scale(0) = 1;
    
    for(j=1; j<n+1; j++){

            interval = time(j) - time(j-1);
            transit = get_transit(trtmat.row(j-1).t(), scalemat, interval,M);
            tempmat = alpha.row(j-1) * transit;
            alpha.row(j) = tempmat % nodeprob.row(j-1);
            tempval = tempmat * nodeprob.row(j-1).t();
            scale(j) = tempval(0);
            for(m=0; m<M; m++) alpha(j, m) = alpha(j,m) / scale(j);

    }

    nllk = - arma::sum(log(scale));

    return Rcpp::List::create(Rcpp::Named("alpha")=alpha,
                              Rcpp::Named("nllk")=nllk);
}

///////////////////////////////////////////////////////////////////
//Assume a binary treatment {0,1}. The initial
//probabilities are already estimated from the baseline characteristics.
//The transitions only depend on treatment, which is assigned according
//to a random or deterministic policy.
// [[Rcpp::export]]
double ar1_smp_nllk1(arma::vec allparm, Rcpp::List timelist, Rcpp::List initiallist, int M, int ncolscale,
                     Rcpp::List x, int ncolx, Rcpp::List trt, int nsubj, arma::vec nullid){

    Rcpp::List templist;
    Rcpp::List nat_par = retrieve_ar1smp(allparm, M, ncolscale, ncolx);

    arma::mat scalemat = nat_par("scalemat");
    arma::mat mumat = nat_par("mumat");
    arma::cube covcube = nat_par("covcube");
    arma::cube arcube = nat_par("arcube");

    int i,j, flag;
    int n_null = nullid.n_rows;
    double tempval;
    double nllk = 0;

    for(i=0; i<nsubj; i++){

        flag = 0;
        for(j=0; j<n_null; j++){
            if(i==nullid(j)-1) {
                flag = 1;
                break;
            }
        }

        //Rcpp::Rcout<<i<<","<<flag<<","<<nllk<<std::endl;
        if(flag==1) {
            continue;
        }
        else{
            templist = ar1_smp_nllk_single1(initiallist(i), scalemat, mumat, covcube, arcube,
                                       timelist(i), M, x(i), trt(i));
            tempval = templist("nllk");
        //Rcpp::Rcout<<tempval<<std::endl;
            nllk += tempval;
        }

    }

    return nllk;
}


///////////////////////////////////////////////////////////////////
// [[Rcpp::export]]
arma::mat ar1_smp_fb(arma::vec delta, arma::mat scalemat,
                                arma::mat mumat, arma::cube covcube, arma::cube arcube,
                                arma::vec time, int M,
                                arma::mat x, arma::mat trtmat){
    //double nllk = 0;
    int n = x.n_rows; //excluding baseline row
    int j,m,t;
    double interval;

    arma::mat transit(M,M);
    arma::vec tempval;
    arma::mat tempmat(1, M);
    //arma::mat parmmat(M*(M-1),2);
    arma::mat alpha(n+1,M);
    arma::vec scale(n+1);
    arma::mat beta(n+1, M);
    arma::mat Gamma(n+1, M);

    //initialize
    arma::mat nodeprob = getnodeprob_ar1(x, mumat, covcube, arcube);
    for(m=0; m<M; m++) alpha(0,m) = delta(m);
    scale(0) = 1;

    for(j=1; j<n+1; j++){

        interval = time(j) - time(j-1);
        transit = get_transit(trtmat.row(j-1).t(), scalemat, interval, M);
        tempmat = alpha.row(j-1) * transit;
        alpha.row(j) = tempmat % nodeprob.row(j-1);
        tempval = tempmat * nodeprob.row(j-1).t();
        scale(j) = tempval(0);
        for(m=0; m<M; m++) alpha(j, m) = alpha(j,m) / scale(j);

    }

    //backward probs and state conditional probs
    for(m=0; m<M; m++) beta(n, m) = 1 / (M * scale(n));
    Gamma.row(n) = alpha.row(n) % beta.row(n);
    tempval = alpha.row(n) * beta.row(n).t();
    for(m=0; m<M; m++) Gamma(n,m)=Gamma(n,m)/tempval(0); //double

    for(t=n-1; t>=0; t--){

        interval = time(t+1) - time(t);
        transit = get_transit(trtmat.row(t).t(), scalemat, interval, M);

        tempmat = beta.row(t+1) % nodeprob.row(t);
        beta.row(t) = tempmat * transit.t();
        for(m=0; m<M; m++) beta(t,m) = beta(t,m) / scale(t);

        Gamma.row(t) = alpha.row(t) % beta.row(t);
        tempval = alpha.row(t) * beta.row(t).t();
        for(m=0; m<M; m++) Gamma(t,m)=Gamma(t,m)/tempval(0); //double
    }

    return Gamma;
}


/////////////////////////////////
//compute AIPW for potential outcome
//' Compute AIPW estimator for potential outcome
//' @param ey estimated conditional mean
//' @param Q the estimated value function (max_trt)
//' @param truetrt true treatment assignment
//' @param predtrt predicted treatment assignment
//' @param pps propensity score
//' @param type type of output
//' @return AIPW for potential outcome
//' @export
// [[Rcpp::export]]
double aipwrcpp(arma::vec ey, arma::vec Q,
                 arma::vec truetrt, arma::vec predtrt, arma::vec pps,
                 int type){
    int n = ey.n_rows;
    int k;
    double cc, pp, tempval, tempsum;

    tempsum = 0;

    if(type == 1){ //aipw
		for(k=0; k<n; k++){
			cc = truetrt(k) * predtrt(k) + (1-truetrt(k))*(1-predtrt(k));
			pp = pps(k)*predtrt(k) + (1-pps(k))*(1-predtrt(k));
			tempval = cc*Q(k) / pp - (cc-pp) * ey(k) / pp;
			tempsum += tempval;
		}
	}
	else if(type == 2){ //ipw
		for(k=0; k<n; k++){
					cc = truetrt(k) * predtrt(k) + (1-truetrt(k))*(1-predtrt(k));
					pp = pps(k)*predtrt(k) + (1-pps(k))*(1-predtrt(k));
					tempval = cc*Q(k) / pp ;
					tempsum += tempval;
		}
	}
	else{
		for(k=0; k<n; k++){
							 tempsum += Q(k);
		}
	}

    return tempsum;
}

// [[Rcpp::export]]
int nextid(int thisrow, arma::vec pattern, int maxdepth, int type){
    //assume thisrow <= maxdepth+1, and thisrow < l
    //type = 0 left, 1 right
    int counter = 0;
    
    double thisval = pattern(thisrow);
    int l = pattern.n_rows;
    int i;
    
    if(type == 0){
        for(i=thisrow+1; i<l; i++){
            if(pattern(i)==thisval + 1) break;
        }
    }
    else{
        for(i=thisrow+1; i<l; i++){
            if(pattern(i)==thisval + 1) counter += 1;
            if(counter==2) break;
        }
    }
    
    return i;
}


/////////////////////////////////
//map decision tree rule matrix to treatment
//' map decision tree rule matrix to treatment
//' @param rulemat decision tree rule matrix
//' @param data training dataset
//' @param maxdepth maximum depth
//' @return a vector of binary treatment
//' @export
//[[Rcpp::export]]
arma::vec rule2trtrcpp(arma::mat rulemat, arma::mat data, int maxdepth){
    int n = data.n_rows;
    //int deep = rulemat.n_rows;
    arma::vec predtrt(n);
    int i,j;
    int id;
    double cut;
    arma::vec pattern = rulemat.col(0);
    int thisrow = 0;
    //int patternid;
    
    for(i=0; i<n; i++){
        
        thisrow = 0;
        
        for(j=0; j<maxdepth; j++){
            
            id = rulemat(thisrow,1) - 1;
            cut = rulemat(thisrow,2);
            
            if(data(i,id) < cut){
                thisrow = nextid(thisrow, pattern, maxdepth, 0);
                if(rulemat(thisrow, 1) == 9999){
                    predtrt(i) = 1;
                    break;
                }
            }
            else{
                thisrow = nextid(thisrow, pattern, maxdepth, 1);
                if(rulemat(thisrow, 1) == 9999){
                    predtrt(i) = 0;
                    break;
                }
            }
            
        }
        
        
    }
    return predtrt;
    
}


 
/////////////////////////////////
//compute AIPW for each rule at a certain stage
//' Compute AIPW for each rule at a certain stage
//' @param data data matrix
//' @param ey estimated conditional mean
//' @param Q the estimated value function (max_trt)
//' @param truetrt true treatment assignment
//' @param pps propensity score
//' @param urules list of rule matrices
//' @param nrules number of unique rules
//' @param type type of output
//' @param maxdepth maximum tree depth
//' @return AIPW vector for each rule
//' @export
//[[Rcpp::export]]
arma::vec aipwvecrcpp(arma::mat data, arma::vec ey, arma::vec Q, arma::vec truetrt, arma::vec pps,
                   Rcpp::List urules, int nrules, int type, int maxdepth){
    int n = ey.n_rows;
    int k;
    arma::vec result(nrules);
    arma::vec predtrt(n);
    result.zeros();

    for(k=0; k<nrules; k++){
        predtrt = rule2trtrcpp(urules(k), data, maxdepth);
        result(k) = aipwrcpp(ey,Q,truetrt, predtrt, pps, type);
    }
    return result;
}

///////////////////////////////////////////////////////////////////
// [[Rcpp::export]]
double calcQrcpp(arma::vec qvec, int maxstage, int stageleft, int timeleft, arma::vec zipparm){
    //stageleft from 0 to maxstage-1
    double zeroparm = zipparm(0);
    double meanparm = zipparm(1);
    double zeroprop = exp(zeroparm) / (1+exp(zeroparm));
    double lambda  = exp(meanparm + log(timeleft));
    double Q = 0;
    int j = 0;
    double tempval, tempp;

    for(j=0; j<stageleft+1; j++){
        tempval = qvec(maxstage-1-j);
        tempp = dzip(zeroprop, lambda, stageleft, j, FALSE);
        Q += tempval * tempp;
    }
    return Q;
}

///////////////////////////////////////////////////////////////////
// [[Rcpp::export]]
double calcQrcpp_cov(arma::vec qvec, int maxstage, int stageleft, int timeleft, arma::vec zipparm,
                     int m, arma::mat datarow){
    //datarow: trt, timeleft, stageleft, actualstageleft, p1:m, trt0d, trt1d, -p1:m, -trt0d, -trt1d,...
    //stageleft from 0 to maxstage-1
    arma::vec zeroparm(m);
    arma::vec meanparm(m);
    arma::rowvec xvec(m);
    arma::vec temp(1);

    double zeroprop;
    double lambda;
    double Q = 0;
    int j = 0;
    double tempval, tempp;
    
    for(j=0;j<m;j++){
        zeroparm(j) = zipparm(j);
        meanparm(j) = zipparm(m+j);
    }
    
    xvec.ones();
    for(j=0;j<m-1;j++)
        xvec(1+j) = datarow(4+j);
    
    temp = xvec * zeroparm;
    zeroprop = exp(temp(0)) / (1+exp(temp(0)));
    temp = xvec * meanparm;
    lambda = exp(temp(0) + log(timeleft));
    
    for(j=0; j<stageleft+1; j++){
        tempval = qvec(maxstage-1-j);
        tempp = dzip(zeroprop, lambda, stageleft, j, FALSE);
        Q += tempval * tempp;
    }
    return Q;
}

/////////////////////////////////
//compute AIPW for each rule at a certain stage for 1 row of data for unknown total stages
//' Compute AIPW for each rule at a certain stage for 1 row of data for unknown total stages
//' @param datarow data row
//' @param triang matrix of aipw for each rule at each stage
//' @param urules list of rule matrices
//' @param nrules number of unique rules
//' @param maxstage maximum number of stages
//' @param stageleft number of stages left
//' @param timeleft remaining time
//' @param zipparm parameter for zero inflated poisson
//' @param maxdepth maximum tree depth
//' @param m number of latent states
//' @param cov whether covariates for zip
//' @return a list of treatments and aipws
//' @export
//[[Rcpp::export]]
Rcpp::List aipwrowrcpp(arma::mat datarow, arma::mat triang, Rcpp::List urules, int nrules,
                      int maxstage, int stageleft, double timeleft, arma::vec zipparm, int maxdepth,
                      int m, bool cov){

    int j;
    arma::vec trtgrid(nrules);
    arma::vec aipwgrid(nrules);
    arma::vec tempvec;
    trtgrid.zeros();
    aipwgrid.zeros();
    
    if(cov == FALSE){
        for(j=0; j<nrules; j++){
            tempvec = rule2trtrcpp(urules(j), datarow, maxdepth);
            trtgrid(j) = tempvec(0);
            aipwgrid(j) = calcQrcpp(triang.col(j), maxstage, stageleft, timeleft, zipparm);
        }
    }
    else{
        for(j=0; j<nrules; j++){
            tempvec = rule2trtrcpp(urules(j), datarow, maxdepth);
            trtgrid(j) = tempvec(0);
            aipwgrid(j) = calcQrcpp_cov(triang.col(j), maxstage, stageleft, timeleft, zipparm,
                                        m, datarow);
        }
    }

    return Rcpp::List::create(Rcpp::Named("trtgrid")=trtgrid,
                              Rcpp::Named("aipwgrid")=aipwgrid);
}

/////////////////////////////////
//filter treatment responder for 2 states
//' filter treatment responder for latent process with 2 states
//' @param trtvec treatment vector
//' @param probmat probability matrix
//' @return a matrix of filtered trt0d and trt1d and ntrt0right and ntrt1right
//' @export
//[[Rcpp::export]]
arma::mat trtfilter2(arma::vec trtvec, arma::mat probmat){
    int nrow = trtvec.n_rows - 1;
    int i;
    //trt0d, trt1d, ntrt0right, ntrt1right
    arma::mat result(nrow+1, 4); //first row is 0
    result.zeros();
    
    for(i=0; i<nrow; i++){
        if(trtvec(i) == 0){
            result(i+1, 0) = result(i, 0) + probmat(i+1, 0) - probmat(i+1, 1) ;
            result(i+1, 1) = result(i, 1);
        }
        else{
            result(i+1, 0) = result(i, 0);
            result(i+1, 1) = result(i, 1) + probmat(i+1, 0) - probmat(i+1, 1) ;
        }
    }
    
    for(i=1; i<nrow+1; i++){
        if(trtvec(i)==0){
            if(result(i,0)>0) result(i,2) = result(i-1,2) + 1;
            if(result(i,0)<0) result(i,2) = result(i-1,2) - 1;
            if(result(i,0)==0) result(i,2) = result(i-1,2);
            result(i,3) = result(i-1,3);
        }
        if(trtvec(i)==1){
            if(result(i,1)>0) result(i,3) = result(i-1,3) + 1;
            if(result(i,1)<0) result(i,3) = result(i-1,3) - 1;
            if(result(i,1)==0) result(i,3) = result(i-1,3);
            result(i,2) = result(i-1,2);
        }

    }
    
    return result;
}

/////////////////////////////////
//filter treatment responder for 3 states
//' filter treatment responder for latent process with 2 states
//' @param trtvec treatment vector
//' @param probmat probability matrix
//' @return a matrix of filtered trt01v2, trt03v2, trt11v2, trt13v2, ntrt0right, ntrt1right
//' @export
//[[Rcpp::export]]
arma::mat trtfilter3(arma::vec trtvec, arma::mat probmat){
    int nrow = trtvec.n_rows - 1;
    int i;
    //trt0d, trt1d, ntrtright
    arma::mat result(nrow+1, 6); //first row is 0
    result.zeros();
    
    for(i=0; i<nrow; i++){
        if(trtvec(i) == 0){
            result(i+1, 0) = result(i, 0) + probmat(i+1, 0) - probmat(i+1, 1) ;
            result(i+1, 1) = result(i, 1) + probmat(i+1, 2) - probmat(i+1, 1) ;
            result(i+1, 2) = result(i, 2);
            result(i+1, 3) = result(i, 3);
        }
        else{
            result(i+1, 0) = result(i, 0);
            result(i+1, 1) = result(i, 1);
            result(i+1, 2) = result(i, 2) + probmat(i+1, 0) - probmat(i+1, 1) ;
            result(i+1, 3) = result(i, 3) + probmat(i+1, 2) - probmat(i+1, 1) ;
        }
    }
    
    for(i=1; i<nrow+1; i++){
        if(trtvec(i)==0){
            if(result(i,0)+result(i,1)<0) result(i,4) = result(i-1,4) + 1;
            if(result(i,0)+result(i,1)>0) result(i,4) = result(i-1,4) - 1;
            if(result(i,0)+result(i,1)==0) result(i,4) = result(i-1,4);
            result(i,5) = result(i-1,5);
        }
        
        if(trtvec(i)==1){
            if(result(i,2)+result(i,3)<0) result(i,5) = result(i-1,5) + 1;
            if(result(i,2)+result(i,3)>0) result(i,5) = result(i-1,5) - 1;
            if(result(i,2)+result(i,3)==0) result(i,5) = result(i-1,5);
            result(i,4) = result(i-1,4);
        }
    }
    
    return result;
}


///////////////////////////////////////////
//discretize the posterior probabilities at 0.1 level
//' discretize the posterior probabilities at 0.1 level
//' @param probmat matrix posterior probabilities
//' @return a matrix of discretized probabilities
//' @export
// [[Rcpp::export]]
arma::mat discretize(arma::mat probmat){
    int ncol = probmat.n_cols;
    int nrow = probmat.n_rows;
    for(int i=0; i<nrow; i++){
        for(int j=0; j<ncol; j++){
            probmat(i,j) = std::round(probmat(i,j)*10) / 10.0;
        }
    }
    return probmat;
}

/////////////////////////////////
//generate the rbf features
//' generate the rbf features
//' @param inputvec input vector
//' @param tausq tau squared
//' @param kappa grids
//' @return a vector of rbf features
//' @export
//[[Rcpp::export]]
arma::vec genrbf(arma::vec inputvec, double tausq, arma::vec kappa){
    int n = inputvec.n_rows;
    int p = kappa.n_rows;
    arma::vec outputvec(n * p);
    double tempval;
    int i,j;
    outputvec.zeros();
    
    for(i=0;i<n;i++){
        for(j=0;j<p;j++){
            tempval = (inputvec(i) - kappa(j)) * (inputvec(i) - kappa(j));
            outputvec( i*p + j) = exp( -0.5 * tempval / tausq);
        }
    }
    
    return outputvec;
}

/////////////////////////////////
//linear value function
//[[Rcpp::export]]
double value_linear(arma::vec parms, arma::vec inputs){
    //parms is longer than inputs by 1
    int p = parms.n_rows;
    int i;
    double tempsum = parms(0);
    
    for(i=1; i<p; i++)
        tempsum += parms(i) * inputs(i-1);
        
    return tempsum;
}

//rbf value function
//[[Rcpp::export]]
double value_rbf(arma::vec parms, arma::vec inputs, double tausq, arma::vec kappa){
    // p is greater than the length of newinput by 1
    int p = parms.n_rows;
    arma::vec newinputs = genrbf(inputs, tausq, kappa);
    int i;
    double tempsum = parms(0);
    
    for(i=1; i<p; i++){
        tempsum += parms(i) * newinputs(i-1);
        //Rcpp::Rcout<<i<<","<<tempsum<<std::endl;
    }
    return tempsum;
}

//gradient for linear value
//[[Rcpp::export]]
arma::vec gd_value_linear(arma::vec parms, arma::vec inputs){
    int p = parms.n_rows;
    arma::vec result(p);
    int i;
    
    result.ones();

    for(i=1;i<p;i++)
        result(i) = inputs(i-1);
    return result;
}

//gradient for rbf value
//[[Rcpp::export]]
arma::vec gd_value_rbf(arma::vec parms, arma::vec inputs, double tausq, arma::vec kappa){
    int p = parms.n_rows;
    arma::vec result(p);
    arma::vec newinputs = genrbf(inputs, tausq, kappa);
    int i;
    
    result.ones();

    for(i=1;i<p;i++)
        result(i) = newinputs(i-1);
    return result;
}

//value function for one vector
//[[Rcpp::export]]
double value_f(arma::vec parms, arma::vec inputs, double tausq, arma::vec kappa,
                  int type){
    double result = 0;
    
    if(type == 1){
        //linear
        result = value_linear(parms, inputs);
    }else if(type == 2){
        //rbf
        result = value_rbf(parms, inputs, tausq, kappa);
    }
    return result;
}

//gradient function for one vector
//[[Rcpp::export]]
arma::vec gd_value_f(arma::vec parms, arma::vec inputs, double tausq, arma::vec kappa,
               int type){
    
    int p = parms.n_rows;
    arma::vec result(p);
    result.ones();
    
    if(type == 1){
        //linear
        result = gd_value_linear(parms, inputs);
    }else if(type == 2){
        //rbf
        result = gd_value_rbf(parms, inputs, tausq, kappa);
    }
    return result;
}

//randomized policy
//[[Rcpp::export]]
double gettrtprob(arma::mat parms, arma::vec inputs, int trt){
    //k trt, then k-1 rows in parm
    //each row is coef for trt i vs trt k
    //inputs only contains policymat predictors (no intercept
    int k = parms.n_rows + 1;
    int p = parms.n_cols;
    int i;
    arma::vec tempval;
    arma::vec fullinputs(p);

    arma::vec exps(k);
    double den=1;
    double result;
    
    fullinputs.ones();
    exps.ones();
    
    for(i=1; i<p; i++) fullinputs(i) = inputs(i-1);
    
    for(i=0; i<k-1; i++) {
        tempval = parms.row(i) * fullinputs;
        exps(i) = exp(tempval(0));
        den += exps(i);
    }
    
    result = exps(trt-1) / den;
 
    return result;
}

//randomized policy
//[[Rcpp::export]]
double getmaxtrt(arma::mat parms, arma::vec inputs){
    //k trt, then k-1 rows in parm
    //each row is coef for trt i vs trt k
    //inputs only contains policymat predictors (no intercept
    int k = parms.n_rows + 1;
    int p = parms.n_cols;
    int i;
    arma::vec tempval;
    arma::vec fullinputs(p);
    
    arma::vec exps(k);
    double den=1;
    double tempmax, temp;
    int result;
    
    fullinputs.ones();
    exps.ones();
    
    for(i=1; i<p; i++) fullinputs(i) = inputs(i-1);
    
    for(i=0; i<k-1; i++) {
        tempval = parms.row(i) * fullinputs;
        exps(i) = exp(tempval(0));
        den += exps(i);
    }
    
    tempmax = 0;
    for(i=0; i<k; i++){
        temp = exps(i) / den;
        if(temp > tempmax){
            tempmax = temp;
            result = i + 1;
        }
    }
    
    return result;
}



//Lambda function for discounted reward to be minimized w.r.t. valueparm
//' estimating equations for lambda
//' @param nsubj nsubj
//' @param valueparm valueparm
//' @param valuemat1 valuemat1
//' @param valuemat2 valuemat2
//' @param policyparm policyparm
//' @param policymat policymat
//' @param utility utility
//' @param trt trt
//' @param ppsmat ppsmat
//' @param disfactor disfactor
//' @param tausq tausq
//' @param kappa kappa
//' @param type type
//' @param tuning tuning
//' @return a scalar
//' @export
//[[Rcpp::export]]
double lambdaEEdis(int nsubj, arma::vec valueparm, arma::mat valuemat1, arma::mat valuemat2,
                    arma::mat policyparm, arma::mat policymat,
                 arma::vec utility, arma::vec trt, arma::mat ppsmat,
                 arma::vec disfactor,
                    double tausq, arma::vec kappa,
                    int type, double tuning){
    
    //parms = [value func parms, policy parms]
    int n = valuemat1.n_rows;
    int p1 = valueparm.n_rows;

    arma::vec tempvec(p1);
    arma::vec tempresult(p1);
    arma::vec temp3;
    arma::vec valueslope(p1-1);
    
    double temp1, temp2, result, cc, pp, predtrt;
    int i,j;

    tempvec.zeros();
    tempresult.zeros();
    
    for(j=0;j<p1-1;j++) valueslope(j) = valueparm(j+1);

    for(i=0; i<n; i++){
        
        predtrt = trt(i);
        cc = gettrtprob(policyparm, policymat.row(i).t(), predtrt);
        pp = ppsmat(i,predtrt-1);
    
        temp1 = cc / pp;
        //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
        temp2 = utility(i) + disfactor(i) * value_f(valueparm, valuemat2.row(i).t(), tausq, kappa, type) - value_f(valueparm, valuemat1.row(i).t(), tausq, kappa, type);
        
        for(j=0; j<p1; j++){
            tempvec = gd_value_f(valueparm, valuemat1.row(i).t(), tausq, kappa, type);
            tempresult(j) += temp1*temp2 * tempvec(j);
        }
        
        //Rcpp::Rcout<<temp1<<","<<temp2<<std::endl;
        
    }
    
    tempresult = tempresult / nsubj;
    
    temp3 = tempresult.t() * tempresult + tuning * valueslope.t() * valueslope;
    result = temp3(0);
    return result;
}


//empirical value function for discounted reward to be maximized w.r.t policyparm
//V function to be minimized w.r.t. valueparm
//' estimating equations for V
//' @param nsubj nsubj
//' @param valueparm valueparm
//' @param valuemat1 valuemat1
//' @param valuemat2 valuemat2
//' @param policyparm policyparm
//' @param policymat policymat
//' @param utility utility
//' @param trt trt
//' @param ppsmat ppsmat
//' @param disfactor disfactor
//' @param tausq tausq
//' @param kappa kappa
//' @param type type
//' @param tuning tuning
//' @return a scalar
//' @export
//[[Rcpp::export]]
double vEEdis(int nsubj, arma::vec valueparm, arma::mat valuemat1, arma::mat valuemat2,
                 arma::mat policyparm, arma::mat policymat,
                 arma::vec utility, arma::vec trt, arma::mat ppsmat,
           arma::vec disfactor,
                 double tausq, arma::vec kappa,
                 int type, double tuning){
    
    //parms = [value func parms, policy parms]
    int n = valuemat1.n_rows;
    int n2 = policyparm.n_rows;
    int p2 = policyparm.n_cols;
    double penalty = 0;

    double temp1, temp2, result, cc, pp, predtrt;
    double temp3 = 0;
    arma::vec temp4;
    int i,j;
    
    for(i=0; i<n; i++){
        
        predtrt = trt(i);
        cc = gettrtprob(policyparm, policymat.row(i).t(), predtrt);
        pp = ppsmat(i,predtrt-1);
        
        temp1 = cc / pp;
        //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
        temp2 = utility(i) + disfactor(i) * value_f(valueparm, valuemat2.row(i).t(), tausq, kappa, type);
        
        temp3 += temp1*temp2;
    }
    
    temp3 /= nsubj;
    
    for(i=0;i<n2;i++){
        for(j=1;j<p2;j++){
            penalty += policyparm(i,j) * policyparm(i,j);
        }
    }
    
    temp4 = tuning * penalty;
    result = temp3 - temp4(0); //minus because minimize -v_ee
    return result;
    
}

//Lambda function for discounted reward to be minimized w.r.t. valueparm
//' estimating equations for lambda
//' @param nsubj nsubj
//' @param valueparm valueparm
//' @param valuemat1 valuemat1
//' @param valuemat2 valuemat2
//' @param predtrt predtrt
//' @param utility utility
//' @param trt trt
//' @param pp pp
//' @param disfactor disfactor
//' @param tausq tausq
//' @param kappa kappa
//' @param type type
//' @param tuning tuning
//' @return a scalar
//' @export
//[[Rcpp::export]]
double lambdaEEdis_det(int nsubj, arma::vec valueparm, arma::mat valuemat1, arma::mat valuemat2,
                   arma::vec predtrt,
                   arma::vec utility, arma::vec trt, arma::vec pps,
                   arma::vec disfactor,
                   double tausq, arma::vec kappa,
                   int type, double tuning){
    
    //parms = [value func parms, policy parms]
    int n = valuemat1.n_rows;
    int p1 = valueparm.n_rows;
    
    arma::vec tempvec(p1);
    arma::vec tempresult(p1);
    arma::vec temp3;
    arma::vec valueslope(p1-1);
    
    double temp1, temp2, result, cc, pp;
    int i,j;
    
    tempvec.zeros();
    tempresult.zeros();
    
    for(j=0;j<p1-1;j++) valueslope(j) = valueparm(j+1);
    
    for(i=0; i<n; i++){
        
        if(trt(i) == predtrt(i)){
            cc = 1;
            pp = pps(i);
            
            temp1 = cc / pp;
            //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
            temp2 = utility(i) + disfactor(i) * value_f(valueparm, valuemat2.row(i).t(), tausq, kappa, type) - value_f(valueparm, valuemat1.row(i).t(), tausq, kappa, type);
            
            for(j=0; j<p1; j++){
                tempvec = gd_value_f(valueparm, valuemat1.row(i).t(), tausq, kappa, type);
                tempresult(j) += temp1*temp2 * tempvec(j);
            }
        }
        else {
            cc = 0;
        }
     
    }
    
    tempresult = tempresult / nsubj;
    
    temp3 = tempresult.t() * tempresult + tuning * valueslope.t() * valueslope;
    result = temp3(0);
    return result;
}


//empirical value function for discounted reward to be maximized w.r.t policyparm
//V function to be minimized w.r.t. valueparm
//' estimating equations for V
//' @param nsubj nsubj
//' @param valueparm valueparm
//' @param valuemat1 valuemat1
//' @param valuemat2 valuemat2
//' @param policyparm policyparm
//' @param policymat policymat
//' @param utility utility
//' @param trt trt
//' @param ppsmat ppsmat
//' @param disfactor disfactor
//' @param tausq tausq
//' @param kappa kappa
//' @param type type
//' @param tuning tuning
//' @return a scalar
//' @export
//[[Rcpp::export]]
double vEEdis_grid(int nsubj, arma::vec valueparm, arma::mat valuemat1, arma::mat valuemat2,
              arma::mat policyparm, arma::mat policymat,
              arma::vec utility, arma::vec trt, arma::mat ppsmat,
              arma::vec disfactor,
              double tausq, arma::vec kappa,
              int type, double tuning){
    
    //parms = [value func parms, policy parms]
    int n = valuemat1.n_rows;
    int n2 = policyparm.n_rows;
    int p2 = policyparm.n_cols;
    double penalty = 0;
    
    double temp1, temp2, result, cc, pp;
    int predtrt;
    double temp3 = 0;
    arma::vec temp4;
    int i,j;
    int k = ppsmat.n_cols;
    double temp, tempmax;
    
    for(i=0; i<n; i++){

        tempmax = 0;
        predtrt = 1;
        for(j=0; j<k; j++){
            temp = gettrtprob(policyparm, policymat.row(i).t(), j+1);
            if(temp > tempmax){
                predtrt = j + 1;
                tempmax = temp;
            }
        }
        
        if(predtrt == trt(i)){
            cc = 1;
            pp = ppsmat(i, trt(i)-1);
            
            temp1 = cc / pp;
            //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
            temp2 = utility(i) + disfactor(i) * value_f(valueparm, valuemat2.row(i).t(), tausq, kappa, type);
            
            temp3 += temp1*temp2;
        }
        else {
            cc = 0;
        }
        
        //if(i < 50) Rcpp::Rcout<<predtrt<<','<<trt(i)<<','<<temp3<<"\n";
    }
    
    temp3 /= nsubj;
    
    for(i=0;i<n2;i++){
        for(j=1;j<p2;j++){
            penalty += policyparm(i,j) * policyparm(i,j);
        }
    }
    
    temp4 = tuning * penalty;
    result = temp3 - temp4(0); //minus because minimize -v_ee
    return result;
    
}


//Lambda function for expected total reward to be minimized w.r.t. valueparm
//' estimating equations for lambda
//' @param nsubj nsubj
//' @param valueparm valueparm
//' @param valuemat1 valuemat1
//' @param valuemat2 valuemat2
//' @param policyparm policyparm
//' @param policymat policymat
//' @param utility utility
//' @param trt trt
//' @param ppsmat ppsmat
//' @param termprob termprob
//' @param tausq tausq
//' @param kappa kappa
//' @param type type
//' @param tuning tuning
//' @return a scalar
//' @export
//[[Rcpp::export]]
double lambdaEEtot(int nsubj, arma::vec valueparm, arma::mat valuemat1, arma::mat valuemat2,
                   arma::mat policyparm, arma::mat policymat,
                   arma::vec utility, arma::vec trt, arma::mat ppsmat,
                   arma::vec termprob,
                   double tausq, arma::vec kappa,
                   int type, double tuning){
    
    //parms = [value func parms, policy parms]
    int n = valuemat1.n_rows;
    int p1 = valueparm.n_rows;
    arma::vec tempvec(p1);
    arma::vec tempresult(p1);
    arma::vec temp3;
    arma::vec valueslope(p1-1);
    
    double temp1, temp2, result, cc, pp, predtrt;
    int i,j;
    
    tempvec.zeros();
    tempresult.zeros();
    
    for(j=0;j<p1-1;j++) valueslope(j) = valueparm(j+1);
    
    for(i=0; i<n; i++){
        
        predtrt = trt(i);
        cc = gettrtprob(policyparm, policymat.row(i).t(), predtrt);
        pp = ppsmat(i,predtrt-1);
        
        temp1 = cc / pp;
        //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
        temp2 = utility(i) + (1 - termprob(i)) * value_f(valueparm, valuemat2.row(i).t(), tausq, kappa, type) - value_f(valueparm, valuemat1.row(i).t(), tausq, kappa, type);
        
        for(j=0; j<p1; j++){
            tempvec = gd_value_f(valueparm, valuemat1.row(i).t(), tausq, kappa, type);
            tempresult(j) += temp1*temp2 * tempvec(j);
        }
        
        //Rcpp::Rcout<<temp1<<","<<temp2<<std::endl;
        
    }
    
    tempresult = tempresult / nsubj;
    
    temp3 = tempresult.t() * tempresult + tuning * valueslope.t() * valueslope;
    result = temp3(0);
    return result;
}


//empirical value function for total reward to be maximized w.r.t policyparm
//V function to be minimized w.r.t. valueparm
//' estimating equations for V
//' @param nsubj nsubj
//' @param valueparm valueparm
//' @param valuemat1 valuemat1
//' @param valuemat2 valuemat2
//' @param policyparm policyparm
//' @param policymat policymat
//' @param utility utility
//' @param trt trt
//' @param pps pps
//' @param termprob termprob
//' @param tausq tausq
//' @param kappa kappa
//' @param type type
//' @param tuning tuning
//' @return a scalar
//' @export
//[[Rcpp::export]]
double vEEtot(int nsubj, arma::vec valueparm, arma::mat valuemat1, arma::mat valuemat2,
              arma::mat policyparm, arma::mat policymat,
              arma::vec utility, arma::vec trt, arma::mat ppsmat,
              arma::vec termprob,
              double tausq, arma::vec kappa,
              int type, double tuning){
    
    //parms = [value func parms, policy parms]
    int n = valuemat1.n_rows;
    int n2 = policyparm.n_rows;
    int p2 = policyparm.n_cols;
    double penalty = 0;
    double temp1, temp2, result, cc, pp, predtrt;
    double temp3 = 0;
    arma::vec temp4;
    int i,j;

    for(i=0; i<n; i++){
        
        predtrt = trt(i);
        cc = gettrtprob(policyparm, policymat.row(i).t(), predtrt);
        pp = ppsmat(i,predtrt-1);
        
        temp1 = cc / pp;
        //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
        temp2 = utility(i) + (1-termprob(i)) * value_f(valueparm, valuemat2.row(i).t(), tausq, kappa, type);
        
        temp3 += temp1*temp2;
    }
    
    temp3 /= nsubj;
    
    for(i=0;i<n2;i++){
        for(j=1;j<p2;j++){
            penalty += policyparm(i,j) * policyparm(i,j);
        }
    }
    
    temp4 = tuning * penalty;
    result = temp3 - temp4(0); //minus because minimize -v_ee
    return result;
    
}


//empirical value function for average reward to be maximized w.r.t policyparm
//V function to be minimized w.r.t. valueparm
//' estimating equations for V
//' @param nsubj nsubj
//' @param valueparm valueparm
//' @param valuemat1 valuemat1
//' @param valuemat2 valuemat2
//' @param policyparm policyparm
//' @param policymat policymat
//' @param utility utility
//' @param trt trt
//' @param ppsmat ppsmat
//' @param subjden subjden
//' @param tausq tausq
//' @param kappa kappa
//' @param type type
//' @param tuning tuning
//' @return a scalar
//' @export
//[[Rcpp::export]]
double vEEavg(int nsubj, arma::vec valueparm, arma::mat valuemat1, arma::mat valuemat2,
              arma::mat policyparm, arma::mat policymat,
              arma::vec utility, arma::vec trt, arma::mat ppsmat,arma::vec subjden,
              double tausq, arma::vec kappa,
              int type, double tuning){
    
    //parms = [value func parms, policy parms]
    int n = valuemat1.n_rows;
    int n2 = policyparm.n_rows;
    int p2 = policyparm.n_cols;
    double penalty = 0;
    double temp1, temp2, result, cc, pp, predtrt;
    double temp3 = 0;
    arma::vec temp4;
    int i,j;
    
    for(i=0; i<n; i++){
        
        predtrt = trt(i);
        cc = gettrtprob(policyparm, policymat.row(i).t(), predtrt);
        pp = ppsmat(i,predtrt-1);
        
        temp1 = cc / pp;
        //Rcpp::Rcout<<temp1<<std::endl;
        //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
        temp2 = utility(i) + value_f(valueparm, valuemat2.row(i).t(), tausq, kappa, type) - value_f(valueparm, valuemat1.row(i).t(), tausq, kappa, type) ;
        
        temp3 += temp1*temp2;//subjden(i);
    }
    
    temp3 /= n;
    
    for(i=0;i<n2;i++){
        for(j=1;j<p2;j++){
            penalty += policyparm(i,j) * policyparm(i,j);
        }
    }
    
    temp4 = tuning * penalty;
    result = temp3 - temp4(0); //minus because minimize -v_ee
    return result;
    
}


//Lambda function for expected average reward to be minimized w.r.t. valueparm
//' estimating equations for lambda
//' @param nsubj nsubj
//' @param valueparm valueparm
//' @param valuemat1 valuemat1
//' @param valuemat2 valuemat2
//' @param policyparm policyparm
//' @param policymat policymat
//' @param utility utility
//' @param trt trt
//' @param ppsmat ppsmat
//' @param subjden subjden
//' @param tausq tausq
//' @param kappa kappa
//' @param type type
//' @param tuning tuning
//' @param vavg vavg
//' @return a scalar
//' @export
//[[Rcpp::export]]
double lambdaEEavg(int nsubj, arma::vec valueparm, arma::mat valuemat1, arma::mat valuemat2,
                   arma::mat policyparm, arma::mat policymat,
                   arma::vec utility, arma::vec trt, arma::mat ppsmat,
                   arma::vec subjden, double tausq, arma::vec kappa,
                   int type, double tuning, double vavg){
    
    //parms = [value func parms, policy parms]
    int n = valuemat1.n_rows;
    int p1 = valueparm.n_rows;
    
    arma::vec tempvec(p1);
    arma::vec auggrad(p1+1);
    
    arma::vec tempresult(p1+1);
    arma::vec temp3;
    arma::vec valueslope(p1-1);
    
    double temp1, temp2, result, cc, pp, predtrt;
    int i,j;
    
    tempvec.zeros();
    auggrad.ones();
    tempresult.zeros();
    
    for(j=0;j<p1-1;j++) valueslope(j) = valueparm(j+1);
    
    for(i=0; i<n; i++){
        
        predtrt = trt(i);
        cc = gettrtprob(policyparm, policymat.row(i).t(), predtrt);
        pp = ppsmat(i,predtrt-1);
        
        temp1 = cc / pp;
        //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
        temp2 = utility(i) + value_f(valueparm, valuemat2.row(i).t(), tausq, kappa, type) - value_f(valueparm, valuemat1.row(i).t(), tausq, kappa, type) - vavg;
        
        tempvec = gd_value_f(valueparm, valuemat1.row(i).t(), tausq, kappa, type);
        for(j=0; j<p1; j++) auggrad(j) = tempvec(j);
        
        for(j=0; j<p1+1; j++) tempresult(j) += temp1*temp2 * auggrad(j);

        //Rcpp::Rcout<<temp1<<","<<temp2<<std::endl;
    }
    
    tempresult = tempresult / nsubj;
    
    temp3 = tempresult.t() * tempresult + tuning * valueslope.t() * valueslope;
    result = temp3(0);
    return result;
}



//Lambda function for expected average reward to be minimized w.r.t. valueparm
//' estimating equations for lambda
//' @param nsubj nsubj
//' @param valueparm valueparm
//' @param valuemat1 valuemat1
//' @param valuemat2 valuemat2
//' @param predtrt predtrt
//' @param utility utility
//' @param trt trt
//' @param pps pps
//' @param subjden subjden
//' @param tausq tausq
//' @param kappa kappa
//' @param type type
//' @param tuning tuning
//' @param vavg vavg
//' @return a scalar
//' @export
//[[Rcpp::export]]
double lambdaEEavg_det(int nsubj, arma::vec valueparm, arma::mat valuemat1, arma::mat valuemat2,
                       arma::vec predtrt,
                   arma::vec utility, arma::vec trt, arma::vec pps,
                   double tausq, arma::vec kappa,
                   int type, double tuning, double vavg){
    
    //parms = [value func parms, policy parms]
    int n = valuemat1.n_rows;
    int p1 = valueparm.n_rows;
    
    arma::vec tempvec(p1);
    arma::vec auggrad(p1+1);
    
    arma::vec tempresult(p1+1);
    arma::vec temp3;
    arma::vec valueslope(p1-1);
    
    double temp1, temp2, result, cc, pp;
    int i,j;
    
    tempvec.zeros();
    auggrad.ones();
    tempresult.zeros();
    
    for(j=0;j<p1-1;j++) valueslope(j) = valueparm(j+1);
    
    for(i=0; i<n; i++){
        
        if(trt(i) == predtrt(i)){
            cc = 1;
            pp = pps(i);
            
            temp1 = cc / pp;
            //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
            temp2 = utility(i) + value_f(valueparm, valuemat2.row(i).t(), tausq, kappa, type) - value_f(valueparm, valuemat1.row(i).t(), tausq, kappa, type) - vavg;
            
            tempvec = gd_value_f(valueparm, valuemat1.row(i).t(), tausq, kappa, type);
            for(j=0; j<p1; j++) auggrad(j) = tempvec(j);
            
            for(j=0; j<p1+1; j++) tempresult(j) += temp1*temp2 * auggrad(j);
            
            //Rcpp::Rcout<<temp1<<","<<temp2<<std::endl;
        }
        else{
            cc = 0;
        }
   
    }
    
    tempresult = tempresult / n;
    
    temp3 = tempresult.t() * tempresult + tuning * valueslope.t() * valueslope;
    result = temp3(0);
    return result;
}

 
//empirical value function for average reward to be maximized w.r.t policyparm
//V function to be minimized w.r.t. valueparm
//' estimating equations for V
//' @param nsubj nsubj
//' @param valueparm valueparm
//' @param valuemat1 valuemat1
//' @param valuemat2 valuemat2
//' @param policyparm policyparm
//' @param policymat policymat
//' @param utility utility
//' @param trt trt
//' @param ppsmat ppsmat
//' @param subjden subjden
//' @param tausq tausq
//' @param kappa kappa
//' @param type type
//' @param tuning tuning
//' @return a scalar
//' @export
//[[Rcpp::export]]
double vEEavg_grid(int nsubj, arma::vec valueparm, arma::mat valuemat1, arma::mat valuemat2,
              arma::mat policyparm, arma::mat policymat,
              arma::vec utility, arma::vec trt, arma::mat ppsmat,
              double tausq, arma::vec kappa,
              int type, double tuning){
    
    //parms = [value func parms, policy parms]
    int n = valuemat1.n_rows;
    int n2 = policyparm.n_rows;
    int p2 = policyparm.n_cols;
    double penalty = 0;
    double temp1, temp2, result, cc, pp, predtrt;
    double temp3 = 0;
    arma::vec temp4;
    int i,j;
    double temp, tempmax;
    int k = ppsmat.n_cols;
    
    for(i=0; i<n; i++){
        
        predtrt = 1;
        for(j=0; j<k; j++){
            temp = gettrtprob(policyparm, policymat.row(i).t(), j+1);
            if(temp > tempmax){
                predtrt = j + 1;
                tempmax = temp;
            }
        }
        
        if(predtrt == trt(i)){
            cc = 1;
            pp = ppsmat(i, trt(i)-1);
        
            temp1 = cc / pp;
            //Rcpp::Rcout<<temp1<<std::endl;
            //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
            temp2 = utility(i) + value_f(valueparm, valuemat2.row(i).t(), tausq, kappa, type) - value_f(valueparm, valuemat1.row(i).t(), tausq, kappa, type) ;
            
            temp3 += temp1*temp2;//subjden(i);
        }
        else{
            cc = 0;
        }
    }
    
    temp3 /= n;
    
    for(i=0;i<n2;i++){
        for(j=1;j<p2;j++){
            penalty += policyparm(i,j) * policyparm(i,j);
        }
    }
    
    temp4 = tuning * penalty;
    result = temp3 - temp4(0); //minus because minimize -v_ee
    return result;
    
}



//[[Rcpp::export]]
double value_dis_c(int nsubj, arma::vec valueparm, arma::mat valuemat1, arma::mat valuemat2,
              arma::mat policyparm, arma::mat policymat,
              arma::vec utility, arma::vec trt, arma::mat ppsmat,
                   arma::vec disfactor){
    
    //parms = [value func parms, policy parms]
    int n = valuemat1.n_rows;
    
    double temp1, temp2, cc, pp, predtrt;
    double temp3 = 0;
    arma::vec temp4;
    int i;
    
    for(i=0; i<n; i++){
        
        predtrt = trt(i);
        cc = gettrtprob(policyparm, policymat.row(i).t(), predtrt);
        pp = ppsmat(i,predtrt-1);
        
        temp1 = cc / pp;
        //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
        
        temp4 = valuemat2.row(i) * valueparm;
        
        temp2 = utility(i) + disfactor(i) * temp4(0);
        
        temp3 += temp1*temp2;
    }
    
    temp3 /= n;

    return temp3;
    
}


//[[Rcpp::export]]
double value_dis_det_c(int nsubj, arma::vec valueparm, arma::mat valuemat1, arma::mat valuemat2,
                   arma::mat policyparm, arma::mat policymat,
                   arma::vec utility, arma::vec trt, arma::mat ppsmat,
                   arma::vec disfactor){
    
    //parms = [value func parms, policy parms]
    int n = valuemat1.n_rows;
    
    double temp1, temp2, cc, pp, predtrt;
    double temp3 = 0;
    arma::vec temp4;
    int i;
    
    for(i=0; i<n; i++){
        
        predtrt = trt(i);
        cc = gettrtprob(policyparm, policymat.row(i).t(), predtrt);
        pp = ppsmat(i,predtrt-1);
        
        temp1 = cc / pp;
        //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
        
        temp4 = valuemat2.row(i) * valueparm;
        
        temp2 = utility(i) + disfactor(i) * temp4(0);
        
        temp3 += temp1*temp2;
    }
    
    temp3 /= n;
    
    return temp3;
    
}






//[[Rcpp::export]]
double value_avg_c(int nsubj, arma::vec valueparm, arma::mat valuemat1, arma::mat valuemat2,
              arma::mat policyparm, arma::mat policymat,
              arma::vec utility, arma::vec trt, arma::mat ppsmat){
    
    //parms = [value func parms, policy parms]
    int n = valuemat1.n_rows;
    double temp1, temp2, cc, pp, predtrt;
    double temp3 = 0;
    arma::vec temp4, temp5;
    int i,j;
    double temp, tempmax;
    int k = ppsmat.n_cols;
    
    for(i=0; i<n; i++){
        
        predtrt = 1;
        for(j=0; j<k; j++){
            temp = gettrtprob(policyparm, policymat.row(i).t(), j+1);
            if(temp > tempmax){
                predtrt = j + 1;
                tempmax = temp;
            }
        }
        
        if(predtrt == trt(i)){
            cc = gettrtprob(policyparm, policymat.row(i).t(), predtrt);
            pp = ppsmat(i, trt(i)-1);
            
            temp1 = cc / pp;
            //Rcpp::Rcout<<temp1<<std::endl;
            //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
            temp4 = valuemat2.row(i) * valueparm;
            temp5 = valuemat1.row(i) * valueparm;
            temp2 = utility(i) + temp4(0) - temp5(0) ;
            
            temp3 += temp1*temp2;//subjden(i);
        }
        else{
            cc = gettrtprob(policyparm, policymat.row(i).t(), predtrt);
            pp = ppsmat(i, trt(i)-1);
            
            temp1 = cc / pp;
            //Rcpp::Rcout<<temp1<<std::endl;
            //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
            temp4 = valuemat2.row(i) * valueparm;
            temp5 = valuemat1.row(i) * valueparm;
            temp2 = utility(i) + temp4(0) - temp5(0) ;
            
            temp3 += temp1*temp2;//subjden(i);
        }
    }
    
    temp3 /= n;
    
    return temp3;
    
}



//[[Rcpp::export]]
double value_avg_det_c(int nsubj, arma::vec valueparm, arma::mat valuemat1, arma::mat valuemat2,
                   arma::mat policyparm, arma::mat policymat,
                   arma::vec utility, arma::vec trt, arma::mat ppsmat){
    
    //parms = [value func parms, policy parms]
    int n = valuemat1.n_rows;
    double temp1, temp2, cc, pp, predtrt;
    double temp3 = 0;
    arma::vec temp4, temp5;
    int i,j;
    double temp, tempmax;
    int k = ppsmat.n_cols;
    
    for(i=0; i<n; i++){
        
        predtrt = 1;
        for(j=0; j<k; j++){
            temp = gettrtprob(policyparm, policymat.row(i).t(), j+1);
            if(temp > tempmax){
                predtrt = j + 1;
                tempmax = temp;
            }
        }
        
        if(predtrt == trt(i)){
            cc = gettrtprob(policyparm, policymat.row(i).t(), predtrt);
            pp = ppsmat(i, trt(i)-1);
            
            temp1 = cc / pp;
            //Rcpp::Rcout<<temp1<<std::endl;
            //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
            temp4 = valuemat2.row(i) * valueparm;
            temp5 = valuemat1.row(i) * valueparm;
            temp2 = utility(i) + temp4(0) - temp5(0) ;
            
            temp3 += temp1*temp2;//subjden(i);
        }
        else{
            cc = gettrtprob(policyparm, policymat.row(i).t(), predtrt);
            pp = ppsmat(i, trt(i)-1);
            
            temp1 = cc / pp;
            //Rcpp::Rcout<<temp1<<std::endl;
            //temp1 = prob_trt1(policyparm, policymat.row(i).t(), trt(i)) / pps(i);
            temp4 = valuemat2.row(i) * valueparm;
            temp5 = valuemat1.row(i) * valueparm;
            temp2 = utility(i) + temp4(0) - temp5(0) ;
            
            temp3 += temp1*temp2;//subjden(i);
        }
    }
    
    temp3 /= n;
    
    return temp3;
    
}

