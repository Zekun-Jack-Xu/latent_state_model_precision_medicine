## Test environments
* local OS X install, R 3.2.4
* ubuntu 12.04 (on travis-ci), R 3.2.4
* win-builder (devel and release)

## R CMD check results

There were no ERRORs or WARNINGs. 

## Reverse dependencies

There are no reverse dependencies.

## Updates

Update documentation for em.semi and em.hmm.
Minor bugs fixed in smooth.hmm and smooth.semi.
Fix the note and error in https://cran.r-project.org/web/checks/check_results_rarhsmm.html
