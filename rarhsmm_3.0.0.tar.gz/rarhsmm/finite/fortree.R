
#########################################
#function to calculate aipw
sum_aipw <- function(data, coefs, trtname, yname, ppsname, coefname,
                     trtlabel, type=1){
  n <- nrow(data)
  truetrt <- data[,trtname]
  Q <- data[,yname]
  pps <- data[,ppsname]
  design <- cbind(1, data.matrix(data[,coefname]))
  ey <- design %*% coefs
   
  predtrt <- rep(trtlabel, n)
  aipw <- aipwrcpp(ey, Q, truetrt, predtrt, pps, type)
  #aipw <- sapply(1:n, function(k){
  #  cc <- truetrt[k]*predtrt[k] + (1-truetrt[k])*(1-predtrt[k])
  #  pp <- pps[k]*predtrt[k] + (1-pps[k])*(1-predtrt[k])
  #  cc * Q[k]/pp - (cc-pp)*ey[k]/pp
  #} )
  
  return(round(aipw,4))
}

#############################################################
#function to calculate best purity 
purity <- function(data, coefs, trtname, yname, ppsname, coefname, splitname, type=1){
  
  n <- nrow(data)
  truetrt <- data[,trtname]
  Q <- data[,yname]
  pps <- data[,ppsname]
  ey <- sapply(1:n, function(k) 
        c(1, unlist(data[k, coefname]))%*%coefs)
  
  bestaipw <- -999999
  bestvarid <- NULL
  bestcutoff <- NULL
  bestdir <- NULL
  bestleft <- NULL      #lt
  bestright <- NULL     #geq

  
  #AIPW estimator for Q values
  # C = trt*I(rule=trt) + (1-trt)*(1-I(rule=trt))
  # p = pps*I(rule=trt) + (1-pps)*(1-I(rule=trt))        
  # Qi = Ci*Yi / pi - (Ci-pi)*E(Yi)/pi
  
  for(i in 1:length(splitname)){
    thisvar <- data[,splitname[i]]
    thisvarid <- which(names(data) == splitname[i])
    #thiscutoffs <- unique( round(quantile(thisvar, seq(0.1,0.9,by=0.1)), 3) )
    thiscutoffs <- unique(  round(thisvar, 3) )
    
    for(j in 1:length(thiscutoffs)){
      
      #case 1: I(var < cutoff)
      predtrt <- ifelse(thisvar < thiscutoffs[j], 1, 0)
      thisaipw <- round(aipwrcpp(ey, Q, truetrt, predtrt, pps, type), 4)
      
         leftdata <- subset(data, thisvar < thiscutoffs[j])
         rightdata <- subset(data, thisvar >= thiscutoffs[j])

      #compare with the current best
      if(thisaipw > bestaipw){
          bestaipw <- thisaipw
          bestvarid <- thisvarid
          bestcutoff <- thiscutoffs[j]
          bestleft <- leftdata
          bestright <- rightdata
      }
      
    }

  }
  
  return(list(aipw=bestaipw,varid=bestvarid,cutoff=bestcutoff,#dir=bestdir,
              leftdata=bestleft, rightdata=bestright))
}




#####################################
splittree <- function(nodelist, maxdepth, minsize, depth,
                      coefs, trtname, yname, ppsname, coefname, splitname,
                      type=1){
  
  
  aipw <- nodelist$aipw
  var <- nodelist$var
  cutoff <- nodelist$cutoff
  #dir <- nodelist$dir
  left <- nodelist$leftdata
  right <- nodelist$rightdata
 
  nodelist$leftdata <- NULL
  nodelist$rightdata <- NULL
  
  #actually, should allow repeated variables for non linear effect
  name1 <- splitname
  name2 <- splitname
  
  #check if no split
  nl <- nrow(left)
  nr <- nrow(right)
  if(is.null(nl)|is.null(nr)){
        nodelist$rightnode <- aipw
        nodelist$leftnode <- aipw
        return(nodelist)
  }else if(nl==0|nr==0){
      nodelist$rightnode <- aipw
      nodelist$leftnode <- aipw
      return(nodelist)
  }
  
  #check maximum depth
  if(depth >= maxdepth){
     nodelist$leftnode <- sum_aipw(left, coefs, trtname, yname, 
                                    ppsname, coefname, 1, type)
     nodelist$rightnode <- sum_aipw(right, coefs, trtname, yname, 
                                    ppsname, coefname, 0, type)
     return(nodelist)
  }
  
  #process the left child
  if(nrow(left)<=minsize){
    nodelist$leftnode <- sum_aipw(left, coefs, trtname, yname, 
                                  ppsname, coefname, 1, type)
  }else{
    #name1 <- name1[name1 != nodelist$var]
    nodelist$leftnode <- purity(left, coefs, trtname, yname, ppsname, coefname, 
                                name1, type)
    nodelist$leftnode <- splittree(nodelist$leftnode, maxdepth, minsize, depth + 1,
              coefs, trtname, yname, ppsname, coefname, name1, type)
  }
  
  #process the right child
  if(nrow(right)<=minsize){
    nodelist$rightnode <- sum_aipw(right, coefs, trtname, yname, 
                                  ppsname, coefname, 0, type)
  }else{
    #name2 <- name2[name2 != nodelist$var]
    nodelist$rightnode <- purity(right, coefs, trtname, yname, ppsname, coefname, 
                                name2, type)
    nodelist$rightnode <- splittree(nodelist$rightnode, maxdepth, minsize, depth + 1,
              coefs, trtname, yname, ppsname, coefname, name2, type)
  }
  return(nodelist)
}

######

extract <- function(treelist, datanames, print=TRUE, depth=1){
  
  if(is.vector(treelist, mode="list")){
      if(print==TRUE){
          cat(rep(" ",depth-1),depth, ",", datanames[treelist$varid], " ", treelist$cutoff,
              " (",treelist$aipw,") ","\n")
      }
  
      assign("rules", rbind(rules, c(depth, treelist$varid,
                              treelist$cutoff, treelist$aipw)),
             envir = .GlobalEnv)
      
      extract(treelist$leftnode, datanames,  print, depth+1)
      extract(treelist$rightnode, datanames, print, depth+1)
          
  }else{
    if(print==TRUE)
        cat(rep(" ",depth-1), depth, " (",treelist,") \n")
     assign("rules", rbind(rules, c(depth, 9999, 9999, treelist)),
           envir = .GlobalEnv)
  }

  return(rules)
}


############################################
#function to convert rulemat into AIPW vec
#for a given stage
rule2aipw <- function(data, coefs, trtname, yname, ppsname, coefname,
                      urules, type=1, maxdepth){
  
  n <- nrow(data)
  truetrt <- data[,trtname]
  Q <- data[,yname]
  pps <- data[,ppsname]
  design <- cbind(1, data.matrix(data[,coefname]))
  ey <- design %*% coefs
  nrule <- length(urules)
  
  aipwvec <- aipwvecrcpp(data.matrix(data),ey,Q,truetrt,pps,urules,nrule, type, maxdepth)  
  return(aipwvec)
}


#################################
prog <- '
load("fortree.RData")
 
yname="y"
trtname="trt"
ppsname="pps"
coefname=c("trt","b1",paste("x",1:5,sep=""),
          "b1trt",paste("x",1:5,"trt",sep=""))
splitname=c("b1","b1n",paste("x",1:5,sep=""),paste("x",1:5,"n",sep=""))
splitname=c("b1n","x5n")
test <- purity(tempdata, coefs, trtname, yname, ppsname, 
               coefname, splitname)

nodelist <- test

treelist=splittree(nodelist, maxdepth=2, minsize=1, depth=1,
          coefs, trtname, yname, ppsname, coefname, splitname)


rules <- c(level=NULL,varid=NULL,lt=NULL,aipw=NULL)

extract(treelist, names(tempdata), print=TRUE,depth=1)

predtrt <- rule2trtrcpp(rules, data.matrix(tempdata))


'

