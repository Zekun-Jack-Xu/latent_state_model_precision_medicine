
require(Matrix)
########################################################
#generate gaussian mixture obs and probs
gaussianmix <- function(mumat, covcube, wvec){
  k <- nrow(mumat)
  cutoff <- cumsum(wvec)
  u <- runif(1)
  
  for(i in 1:length(cutoff)){
    if(u<=cutoff[i]){
      index <- i
      break
    }
  }
  
  obs <- mvrnorm(1, mumat[index,], covcube[,,index])
  probs <- rep(NA, k)
  for(i in 1:k) probs[i] <- mvdnorm(obs, mumat[i,], covcube[,,i], FALSE)
  probs <- probs / sum(probs)
  return(list(obs=obs, probs=probs))
}

##################################
trtdiff <- function(trtvec, statevec){
  templ <- length(trtvec)
  if(templ==1){
     return(c(0,0))
  }else{
    tempeval <- data.frame(cbind(trt=trtvec[-templ], 
                                 state=statevec[-1]))
    trt0s1 <- nrow(subset(tempeval, trt==0 & state==1))
    trt0s2 <- nrow(subset(tempeval, trt==0 & state==2))
    trt1s1 <- nrow(subset(tempeval, trt==1 & state==1))
    trt1s2 <- nrow(subset(tempeval, trt==1 & state==2))
    c(trt0s1 - trt0s2, trt1s1 - trt1s2)
  }
}

trtdiff3 <- function(trtvec, statevec){
  templ <- length(trtvec)
  if(templ==1){
    return(c(0,0,0,0))
  }else{
    tempeval <- data.frame(cbind(trt=trtvec[-templ], 
                                 state=statevec[-1]))
    trt0s1 <- nrow(subset(tempeval, trt==0 & state==1))
    trt0s2 <- nrow(subset(tempeval, trt==0 & state==2))
    trt0s3 <- nrow(subset(tempeval, trt==0 & state==3))
    trt1s1 <- nrow(subset(tempeval, trt==1 & state==1))
    trt1s2 <- nrow(subset(tempeval, trt==1 & state==2))
    trt1s3 <- nrow(subset(tempeval, trt==1 & state==3))
    c(trt0s1 - trt0s2, trt0s3 - trt0s2,
      trt1s1 - trt1s2, trt1s3 - trt1s2)
  }
}  
###################################################################
#create formatted data for backward induction from lists
#also need to generate a set of negative sign features!!!
#because decision tree rule is I(x < theta)
#need to consider I(-x < -theta)
format1 <- function(indexvec, maxtime, maxstage, timelist, trtlist, foolist,
                    actualstageleft #baselist=NULL, xlist=NULL, tau, kappa
                    ){
  
  nsubj <- length(timelist)
  #indexvec contains the largest index (stage) for each subject
  
  tvec <- sapply(1:nsubj,function(k) 
    if(indexvec[k]>0) timelist[[k]][indexvec[k]]
    else NA)
  
  timeleft <- maxtime - tvec
  
  stageleft <- sapply(1:nsubj,function(k) 
    if(indexvec[k]>0) maxstage - indexvec[k]
    else NA)
  
  actualstageleft <- actualstageleft
  
  trtvec <- sapply(1:nsubj,function(k){
    if(indexvec[k]>0) trtlist[[k]][indexvec[k]]
    else NA
  })
  
  m <- ncol(foolist[[k]])
  bmat <- t(sapply(1:nsubj,function(k) {
    if(indexvec[k]>0) foolist[[k]][indexvec[k],]
    else rep(NA, m)
  }))
  
  if(m==2){
    diffmat <- t(sapply(1:nsubj, function(k){
        if(indexvec[k]>0){
            temptrt <- trtlist[[k]][1:indexvec[k]]
            tempstate <- sapply(1:indexvec[k], function(kkk) 
              which.max(foolist[[k]][kkk,]))
            trtdiff(temptrt,tempstate)
        }else{rep(NA,2)}
    }))
    
    #baseline covariates doesn't matter
    xdata <- data.frame(cbind(trtvec,timeleft,stageleft,actualstageleft,bmat,
                              diffmat))
    names(xdata) <- c("trt","timeleft","stageleft","actualstageleft",
                      paste("p",1:m,sep=''),c("trt0d","trt1d"))
    xdata$p1n <- -xdata$p1
    xdata$p2n <- -xdata$p2
    xdata$trt0dn <- -xdata$trt0d
    xdata$trt1dn <- -xdata$trt1d
    xdata$dd0v1 <- xdata$trt0d - xdata$trt1d
    xdata$dd0v1n <- -xdata$dd0v1
    xdata$trt0dtrt <- xdata$trt0d * xdata$trt
    xdata$trt1dtrt <- xdata$trt1d * xdata$trt
    
  }else{
    diffmat <- t(sapply(1:nsubj, function(k){
      if(indexvec[k]>0){
        temptrt <- trtlist[[k]][1:indexvec[k]]
        tempstate <- sapply(1:indexvec[k], function(kkk) 
          which.max(foolist[[k]][kkk,]))
        trtdiff3(temptrt,tempstate)
      }else{rep(NA,4)}
    }))
    
    #baseline covariates doesn't matter
    xdata <- data.frame(cbind(trtvec,timeleft,stageleft,actualstageleft,bmat,
                              diffmat))
    names(xdata) <- c("trt","timeleft","stageleft","actualstageleft",
                      paste("p",1:m,sep=''),
                      c("trt0_1v2","trt0_3v2","trt1_1v2","trt1_3v2"))
    xdata$p1n <- -xdata$p1
    xdata$p2n <- -xdata$p2
    xdata$trt0_1v2n <- -xdata$trt0_1v2
    xdata$trt0_3v2n <- -xdata$trt0_3v2
    xdata$trt1_1v2n <- -xdata$trt1_1v2
    xdata$trt1_3v2n <- -xdata$trt1_3v2
    
    xdata$trt0_1v2trt <- xdata$trt0_1v2 * xdata$trt
    xdata$trt0_3v2trt <- xdata$trt0_3v2 * xdata$trt
    xdata$trt1_1v2trt <- xdata$trt1_1v2 * xdata$trt
    xdata$trt1_3v2trt <- xdata$trt1_3v2 * xdata$trt
  }
   
  return(xdata)
}

########################################3
#return propensity score model
get_ppsmod <- function(nsubj, maxtime, maxstage, ylist, timelist,
                       trtlist, foolist,  #baselist,xlist,
                       ppsvarnames){
  
  indexvec <- sapply(1:nsubj, function(k) length(trtlist[[k]]))
  obsmaxstage <- max(indexvec)
  
  xdata <- format1(indexvec, maxtime, maxstage, timelist, trtlist, foolist,0)
  
  for(i in 1:obsmaxstage){
    indexvec <- indexvec - 1
    temp <- format1(indexvec, maxtime, maxstage, timelist, trtlist, foolist,i)
    temp <- temp[complete.cases(temp),]
    xdata <- rbind(xdata, temp)
  }
  
  m <- ncol(foolist[[1]])
  subdata <- xdata[,c("trt",ppsvarnames)]
  ppsmod <- glm(trt ~ ., data=subdata, family=binomial(link="logit"))
  
  return(list(ppsmod=ppsmod,xdata=xdata))
}

##################################################################
#main function for backward induction
#return the coefficient list and augmented data (id = subj + visit)
#maxstage must be greater than max observed number of stages


#####################################
#do not pool but distribute the result evenly
backward2 <- function(nsubj, maxtime,maxstage, 
                      ylist, timelist,
                      trtlist, foolist, ppsmod, #baselist=NULL,
                      ppsvarnames, n0=10, #pool=5, #type=1,
                      #tau=0.25, kappa=c(0,0.25,0.5,0.75,1),
                      ycoefnames=c("trt","b1","b1trt"),
                      print=FALSE){
  
  #get the formatted data from lists
  coefs <- vector(mode="list", length=maxstage)
  indexvec <- sapply(1:nsubj, function(k) length(trtlist[[k]]))
  obsmaxstage <- max(indexvec)
  
  xdata <- format1(indexvec, maxtime, maxstage, timelist, trtlist, foolist,
                   0)
  yvec <- unlist(ylist)
  xdata$y <- yvec
  
  #append the column for PPS
  pps <- predict(ppsmod, xdata[,ppsvarnames,drop=FALSE],type='response')
  
  xdata$pps <- pps
  temp <- xdata
  temptrim <- temp
  #w <- ifelse(temp$trt==1, 1/temp$pps, 1/(1-temp$pps))
  
  designmat <- data.matrix(temp[, ycoefnames])
  coefs[[maxstage]] <- wridge(designmat, temp$y, shrink1=1e-5)
  
  counter <- 1 #counter for pooling
  lastgoodstage <- maxstage #last stage with non missing coefs
  
  
  #backward induction
  for(stage in (maxstage-1):(maxstage-obsmaxstage+1)){
    
    indexvec <- indexvec - 1
    
    for(i in 1:nsubj){
      
      if(indexvec[i]>0){
        if(m==2) {
           statename <- c("trt0d","trt1d")
           yhat1 <- c(1,  unlist(temp[i,c("p1","trt","trt0d","trt1d")]), 
                      unlist(temp[i, statename])#, 
                     )%*%coefs[[lastgoodstage]]
           yhat2 <- c(1,  unlist(temp[i,c("p1","trt","trt0d","trt1d")]),  #
                      rep(0, length(statename)))%*%coefs[[lastgoodstage]] 
           
        }else{
          statename <- c("trt0_1v2","trt0_3v2","trt1_1v2","trt1_3v2")
          yhat1 <- c(1,  unlist(temp[i,c("p1","p2","trt",
                                        "trt0_1v2","trt0_3v2","trt1_1v2","trt1_3v2")]),
                     unlist(temp[i, statename]))%*%coefs[[lastgoodstage]]
          yhat2 <- c(1,  unlist(temp[i,c("p1","p2","trt",
                                "trt0_1v2","trt0_3v2","trt1_1v2","trt1_3v2")]),
                     rep(0, length(statename)))%*%coefs[[lastgoodstage]] 
        }
        
        better <- max(yhat1, yhat2)
        ey <- c(1,  unlist(temp[i,ycoefnames]))%*%coefs[[lastgoodstage]]
        yvec[i] <- yvec[i] + better - ey
      }
      else yvec[i] <- NA
    }
    
    #format the data from lists
    temp <- format1(indexvec, maxtime, maxstage, timelist, trtlist, foolist,
                    maxstage-stage)
    
    temp$y <- yvec
    
    temptrim <- temp[complete.cases(temp),]
    pps <- predict(ppsmod, temptrim[,ppsvarnames,drop=FALSE],type='response')
    temptrim$pps <- pps
  
    
    if(nrow(temptrim)<n0) break
    
     designmat <- data.matrix(temptrim[,ycoefnames])
      #w <- ifelse(acc$trt==1, 1/acc$pps, 1/(1-acc$pps))
      coefs[[stage]] <-  wridge(designmat, temptrim$y, shrink1=1e-5)
      lastgoodstage <- stage
 
    xdata <- rbind(xdata, temptrim)
    
  }
  
  if(print==TRUE) print(stage)
  
  #pooling the tail stages
  rest <- temptrim
   
  for(k in (stage-1):(maxstage-obsmaxstage+1)){
      indexvec <- indexvec - 1

      for(i in 1:nsubj){
      if(indexvec[i]>0){
        if(m==2) {
          statename <- c("trt0d","trt1d")
          yhat1 <- c(1,  unlist(temp[i,c("p1","trt","trt0d","trt1d")]), 
                     unlist(temp[i, statename])#, 
          )%*%coefs[[lastgoodstage]]
          yhat2 <- c(1,  unlist(temp[i,c("p1","trt","trt0d","trt1d")]),  #
                     rep(0, length(statename)))%*%coefs[[lastgoodstage]] 
          
        }else{
          statename <- c("trt0_1v2","trt0_3v2","trt1_1v2","trt1_3v2")
          yhat1 <- c(1,  unlist(temp[i,c("p1","p2","trt",
                                         "trt0_1v2","trt0_3v2","trt1_1v2","trt1_3v2")]),
                     unlist(temp[i, statename]))%*%coefs[[lastgoodstage]]
          yhat2 <- c(1,  unlist(temp[i,c("p1","p2","trt",
                                         "trt0_1v2","trt0_3v2","trt1_1v2","trt1_3v2")]),
                     rep(0, length(statename)))%*%coefs[[lastgoodstage]] 
        }
        better <- max(yhat1, yhat2)
        ey <- c(1,  unlist(temp[i,ycoefnames]))%*%coefs[[lastgoodstage]]
        yvec[i] <- yvec[i] + better - ey
      }
        else yvec[i] <- NA
    }
    #format the data from lists
    temp <- format1(indexvec, maxtime, maxstage, timelist, trtlist, foolist,
                    maxstage-stage)
    
    temp$y <- yvec
    
    temptrim <- temp[complete.cases(temp),]
    pps <- predict(ppsmod, temptrim[,ppsvarnames,drop=FALSE],type='response')
    temptrim$pps <- pps
    rest <- rbind(rest,temptrim)
    
  }
  
  designmat <- data.matrix(rest[,ycoefnames])
  #w <- ifelse(acc$trt==1, 1/acc$pps, 1/(1-acc$pps))
  coefs[[stage]] <-  wridge(designmat, rest$y, shrink1=1e-5)
  
  distcoef <- vector(mode="list",length=maxstage)
  steps <- floor(maxstage / (maxstage-stage))
  
  j <- 1
  for(i in stage:maxstage){
        distcoef[[j]] <- coefs[[i]]
        j <- j+1
  }
  for(l in j:maxstage) distcoef[[l]] <- coefs[[maxstage]]
   #j is start of the coefs for last stage
  return(list(augdata=xdata, coefs=distcoef, lastindex=j))
}


##################################################
#weighted ridge regression
wridge <- function(x, y, w=NULL, shrink1=0){
  n <- nrow(x)
  if(is.null(n)){
    return("too few obs")
  }else if(n==1){
    return("too few obs") 
  }else{
    x <- cbind(1,x)
    if(!is.null(w)){
      part1 <- t(x) %*% Diagonal(n, w) %*%x + Diagonal(ncol(x), shrink1)
      part2 <- t(x) %*% Diagonal(n, w) %*% y
      coef <- solve(part1, part2)
    }else{
      part1 <- t(x) %*% x + diag(rep(shrink1, ncol(x)))
      part2 <- t(x) %*% y
      coef <- solve(part1, part2)
    }
    return(as.matrix(coef))
  }
}


##################################################################
#no pooling
policysearch2 <- function(augdata, coeflist, maxstage,
                          trtname, yname, ppsname, 
                          coefname, splitname, 
                          n0=10, lastindex=1, maxdepth=2, minsize=1, 
                          print=FALSE, type=1){
  
  obsmaxstage <- max(augdata$actualstageleft)
  flag <- 0
  
  xdata <- subset(augdata, actualstageleft==0)
  coefs <- coeflist[[maxstage - 0]]
  nodelist <- purity(xdata, coefs, trtname, yname, ppsname, 
                     coefname, splitname,
                     type)
  
  treelist <- splittree(nodelist, maxdepth, minsize, 1,
                        coefs, trtname, yname, ppsname, coefname, splitname,
                        type)
  rules <- extract(treelist, names(augdata), print=print)
    
  for(i in 1:obsmaxstage){
     
    temp <- subset(augdata, actualstageleft==i)
      if(nrow(temp)<=n0) {
        temp <- subset(augdata, actualstageleft>=i)
        flag <- 1
      }
      
      coefs <- coeflist[[lastindex-i]]
      nodelist <- purity(temp, coefs, trtname, yname, ppsname, 
                           coefname, splitname, type)
        
      treelist <- splittree(nodelist, maxdepth, minsize, 1,
                              coefs, trtname, yname, ppsname, coefname, splitname,
                              type)
      rules <- extract(treelist, names(augdata), print=print)
      
      if(print==TRUE) print(i)
      if(flag==1) break
    }
  
  return(rules)
}


##########################################
#function to extract unique rules as a list
unique_rules <- function(rulemat, maxdepth=1, nsubj=200, tuning=0){
  row <- nrow(rulemat)
  nrule <- sum(rulemat[,1]=="1")
  
  rulelist <- vector(mode="list", length=nrule)
  j <- 0
  
  for(i in 1:row){
    if(rulemat[i,1]=="1"){
      j <- j+1
      rulelist[[j]] <- rulemat[i,]
    }else{
      rulelist[[j]] <- rbind(rulelist[[j]], rulemat[i,])
    }
  }
  
  if(maxdepth>1){
      for(i in 1:nrule){
         thismat <- rulelist[[i]]
         aipw <- sum(thismat[thismat[,1]==maxdepth,4])/nsubj
         for(j in (maxdepth-1):1){
             tempaipw <- sum(thismat[thismat[,1]==j,4])/nsubj 
             if(aipw - tempaipw >= tuning){
               break
             }else{
               aipw <- tempaipw
               thismat <- thismat[thismat[,1]<=j+1,,drop=FALSE]
               thismat[thismat[,1]==j+1,-1] <- 9999
             }
         }
         rulelist[[i]] <- thismat[,-4,drop=FALSE]
      }
  }
  return(unique(rulelist))
}

 

##################################################################
#no pooling + setting the last index
triang_aipw2<- function(augdata, coeflist, maxstage, trtname, yname, ppsname, coefname,
                       urules, nsubj, n0=10, lastindex=1, type=1, maxdepth){
  
  nrule <- length(urules)
  aipwmat <- matrix(NA, nrow=maxstage, ncol=nrule)
  
  maxobsstage <- max(augdata$actualstageleft)
  flag <- 0
  
  coef <- coeflist[[maxstage]]
  xdata <- subset(augdata, actualstageleft==0)
  aipwmat[maxstage,] <- rule2aipw(xdata, coef, trtname, yname, 
                                  ppsname, coefname,urules, type, maxdepth)
  for(k in maxstage:lastindex) aipwmat[k,] <- aipwmat[maxstage,]
  #############
  
  for(s in 1:maxobsstage){
    temp <- subset(augdata, actualstageleft==s)
    
    if(nrow(temp)<=n0){
      temp <- subset(augdata, actualstageleft>=s)
      flag <- 1
    }
    
      coef <- coeflist[[lastindex-s]]
      aipwmat[lastindex-s,] <- rule2aipw(temp, coef, trtname, yname, 
                                        ppsname, coefname,urules, type, maxdepth)
      
      if(flag==1) break
    }
    
  for(i in 1:lastindex){
    if(all(is.na(aipwmat[i,]))) aipwmat[i,] <- aipwmat[lastindex-s,]
  } 
  return(aipwmat)
}


#################################################################
#5.nllk for zip reg
nllk_zipreg <- function(parm, augdata, m, cov=TRUE){
  nllk <- 0
  if(cov==TRUE){
    zeroparm <- parm[1:m]
    meanparm <- parm[(m+1):(2*m)]
    for(i in 1:nrow(augdata)){
      xvec <- unlist(c(1,augdata[i,5:(5+m-2)]))
      zeroprop <- exp(zeroparm%*%xvec)/(1+exp(zeroparm%*%xvec))
      lambda <- exp(meanparm%*%xvec + log(augdata[i,2]+1))
      trunc <- augdata[i,3]
      y <- augdata[i,4]
      temp <- dzip(zeroprop, lambda, trunc, y, TRUE)   
      nllk <- nllk - temp
    }
  }else{
    zeroparm <- parm[1]
    meanparm <- parm[2]
    for(i in 1:nrow(augdata)){
      zeroprop <- exp(zeroparm)/(1+exp(zeroparm))
      lambda <- exp(meanparm + log(augdata[i,2]+1))
      trunc <- augdata[i,3]
      y <- augdata[i,4]
      temp <- dzip(zeroprop, lambda, trunc, y, TRUE)   
      nllk <- nllk - temp
    }
  }
  return(nllk)
}
