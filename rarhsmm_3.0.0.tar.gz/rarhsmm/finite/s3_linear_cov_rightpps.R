rm(list=ls())
require(Matrix)
require("Rcpp")
setwd("~/Desktop/myRpackage")
compileAttributes("rarhsmm_2.0.1")
setwd("~/Desktop/myRpackage/rarhsmm_2.0.1/finite")
#devtools::use_package("pracma")
devtools::document()
devtools::load_all()
#devtools::check()
#devtools::build()

source("batchsim.R")
source("util.R")
source("fortree.R")

set.seed(215)
nsubj <- 200

m <- 3
maxtime <- 364
maxstage <- 70
maxdepth <- 3

mumat0 <- matrix(0,nrow=3,ncol=5)
covcube0 <- array(0,dim=c(5,5,3))
covcube0[,,1] <- diag(2,5)
covcube0[,,2] <- diag(1,5)
covcube0[,,3] <- diag(3,5)
wvec <- c(1/3,1/3,1/3)

qform <- 2   #rightmu
zipcov <- TRUE

############################################
trtfun0 <- function(obj){
  vec <- c(1, obj$delta[1], obj$delta[2],
           obj$trt0_1v2, obj$trt0_3v2, obj$trt1_1v2,obj$trt1_3v2)
  coef <- c(0.1, 0,0, -0.3,-0.3,0.3,0.3)
  lp <- vec %*% coef
  p <- exp(lp) / (1+exp(lp))
  trt <- rbinom(1, 1, p)
  return(trt)
}
trtfun <- trtfun0

sim1 <- batchsim3( m,nsubj,maxtime,maxstage,
                   mumat0,covcube0,wvec,
                   trtfun, maxdepth,#basecov=TRUE,
                   optimal=FALSE,zipparm=NULL,zipcov=TRUE,
                   triang_Q=NULL, urules=NULL,
                   only_y=FALSE,qform=qform)

xlist <- sim1$xlist
ylist <- sim1$ylist
#trtlist <- sim1$trtlist
trtlist <- lapply(1:nsubj,function(k) cbind(1,sim1$trtlist[[k]]))

timelist <- sim1$timelist
statelist <- sim1$statelist
problist <- sim1$problist
initiallist <- sim1$initiallist
statelist <- sim1$statelist
mod <- sim1$mod


#get those with only 1 decision stage at baseline
nullid <- NULL
for(j in 1:nsubj){
  if(is.null(nrow(xlist[[j]]))) nullid <- c(nullid,j)
}

if(length(nullid)==0) nullid <- -1

#mle fitting
time <- proc.time()
fitted <- ar1.smp.fit1(mod,timelist, initiallist, xlist, trtlist, 
                       nullid, stepsize=0.001,maxit=2,eps=1e-4,
                       ar_diag=TRUE,cov_diag=FALSE)
proc.time() - time

natparm <- fitted$natparm

#################################################
foolist <- vector(mode="list",length=nsubj)

for(k in 1:nsubj){
  if(nrow(trtlist[[k]])==1) foolist[[k]] <- 
      matrix(initiallist[[k]],nrow=1)
  else foolist[[k]] <- ar1.smp.filter1(timelist[[k]], natparm, 
                                       initiallist[[k]],trtlist[[k]],xlist[[k]])
}
#foolist <- problist
#################################################
###################################################################
#propensity score
trtlist <- lapply(1:nsubj,function(k) trtlist[[k]][,2])

ppsvarnames <- c("p1", "p2",
                 "trt0_1v2", "trt0_3v2","trt1_1v2","trt1_3v2")
temp <- get_ppsmod(nsubj, maxtime, maxstage,ylist, timelist,trtlist, foolist,
                   ppsvarnames)
ppsmod <- temp$ppsmod
zipdata <- temp$xdata

#############################################################
#ZIP for remaining number of stages

#cov
initparm <- c(-2,0,0,-3,0,0)

zipresult <- optim(initparm,nllk_zipreg,augdata=zipdata,m=3,cov=TRUE,
                   method="CG",control=list(trace=1,maxit=2))
zipparm <- zipresult$par



##############################################################
#Triangular Qs --- store lm coefficients for each stage and augmented data

n0=30

indexvec <- sapply(1:nsubj, function(k) length(trtlist[[k]]))
max(indexvec)

#only pool at the end and distribute evenly
ycoefnames <- c( "p1","p2","trt",
                 "trt0_1v2","trt0_3v2","trt1_1v2","trt1_3v2",
                 "trt0_1v2trt","trt0_3v2trt","trt1_1v2trt","trt1_3v2trt")
dat_coef <- backward2(nsubj, maxtime, maxstage, ylist, timelist,
                      trtlist, foolist, ppsmod, 
                      ppsvarnames,
                      n0, #pool,
                      ycoefnames=ycoefnames,print=TRUE)


augdata <- dat_coef$augdata
coeflist <- dat_coef$coefs
unique(coeflist)

######################e##########3
######################e##########3
rules <- c(NULL,NULL,NULL,NULL)
yname="y"
trtname="trt"
ppsname="pps"
coefname=c( "p1","p2","trt",
            "trt0_1v2","trt0_3v2","trt1_1v2","trt1_3v2",
            "trt0_1v2trt","trt0_3v2trt","trt1_1v2trt","trt1_3v2trt")
#must consider the negative version of variables
#because policy is I(x < theta)
splitname=c("p1","p2","trt0_1v2n","trt0_3v2n","trt1_1v2","trt1_3v2")
#splitname=c("dd0v1","dd0v1n")
#maxdepth=1
maxdepth=3
minsize=1


lastindex <- dat_coef$lastindex
rules <- c(NULL,NULL,NULL,NULL)
rules1 <- policysearch2(augdata, coeflist, maxstage,
                        trtname, yname, ppsname, 
                        coefname, splitname,
                        n0, lastindex, maxdepth, minsize, print=FALSE,
                        type=1)

rules <- c(NULL,NULL,NULL,NULL)
rules2 <- policysearch2(augdata, coeflist, maxstage,
                        trtname, yname, ppsname, 
                        coefname, splitname,
                        n0, lastindex, maxdepth, minsize, print=FALSE,
                        type=2)

rules <- c(NULL,NULL,NULL,NULL)
rules3 <- policysearch2(augdata, coeflist, maxstage,
                        trtname, yname, ppsname, 
                        coefname, splitname,
                        n0, lastindex, maxdepth, minsize, print=FALSE,
                        type=3)
#unique decision rules
urules1 <- unique_rules(rules1,maxdepth=maxdepth, nsubj=nsubj, tuning=0.01)

urules2 <- unique_rules(rules2,maxdepth=maxdepth, nsubj=nsubj, tuning=0.01)

urules3 <- unique_rules(rules3,maxdepth=maxdepth, nsubj=nsubj, tuning=0.01)
names(augdata)
urules1[[1]]

#get the estimated aipw for each rule at each stage
triang1 <- triang_aipw2(augdata, coeflist, maxstage, trtname, 
                        yname, ppsname, coefname,urules1, nsubj,n0, lastindex,
                        type=1, maxdepth)

triang2 <- triang_aipw2(augdata, coeflist, maxstage, trtname, 
                        yname, ppsname, coefname,urules2, nsubj,n0, lastindex,
                        type=2, maxdepth)

triang3 <- triang_aipw2(augdata, coeflist, maxstage, trtname, 
                        yname, ppsname, coefname,urules3, nsubj,n0, lastindex,
                        type=3, maxdepth)
#sapply(1:maxstage, function(k) which.max(triang1[k,]))
#nextid function works well
#aa2=rule2trtrcpp(rulemat,data.matrix(augdata),3)

#stage_left cannot be greater than maxstage-1
calcQrcpp_cov(triang1[,1], maxstage=50, stageleft=28, timeleft=50, zipparm,
              m, matrix(data.matrix(zipdata)[1,],nrow=1))
#calc_Q(triang[,1], 50, 0,5, zipparm)



##################################################### 
#apply this function to the subjects in this batch
#simulate according to the optimal policy
###################################################
#1. random policy
trtfun1 <- function(obj){
  trt <- rbinom(1,1,0.5)
  return(trt)
}
trtfun <- trtfun1


nsims <- 100
j <- 1
this1 <- matrix(NA,nsims,nsubj)

time <- proc.time()
while(j<=nsims){
  print(j)
  temp <- batchsim3( m,nsubj,maxtime,maxstage,
                     mumat0,covcube0,wvec,
                     trtfun, maxdepth, 
                     optimal=FALSE,zipparm=NULL,zipcov=TRUE,
                     triang_Q=NULL, urules=NULL,
                     only_y=TRUE,qform=qform)
  if(is.character(temp)) next
  else this1[j,] <- unlist(temp)
  j <- j+1
}
proc.time() - time


mean(rowMeans(this1))
sd(rowMeans(this1))

######################################################


#############################################################3
#optimal policy: linear

trtfun3 <- function(obj, urules, 
                    triang_Q, maxstage, stage_left, time_left, zipparm,
                    maxdepth,m,zipcov=TRUE){
  nrules <- length(urules)
  
  augdatarow <- matrix(c(0,0,0,0,obj$delta,obj$trt0_1v2,obj$trt0_3v2,
                         obj$trt1_1v2,obj$trt1_3v2,
                         obj$deltan,obj$trt0_1v2n,obj$trt0_3v2n,
                         obj$trt1_1v2n,obj$trt1_3v2n), nrow=1)
  
  temp <- aipwrowrcpp(augdatarow, triang_Q, urules, nrules,
                      maxstage, stage_left, time_left, zipparm,maxdepth,
                      m,zipcov)
  #for(j in 1:length(urules)){
  #  trtgrid[j] <- rule2trtrcpp(urules[[j]], augdatarow)
  #  qvec <- triang_Q[,j]
  #  Q_grid[j] <- calc_Q(qvec, maxstage, stage_left, time_left,zipparm)
  #}
  trtgrid <- temp$trtgrid
  aipwgrid <- temp$aipwgrid
  index <- which.max(aipwgrid)
  trt <- trtgrid[index]
  #print(trt)
  return(trt)
}
trtfun <- trtfun3

#aipw
nsims <- 100
j <- 1
this3 <- matrix(NA,nsims,nsubj)

time <- proc.time()
while(j<=nsims){
  print(j)
  temp <- batchsim3(m,nsubj,maxtime,maxstage,
                    mumat0,covcube0,wvec,
                    trtfun, maxdepth, 
                    optimal=TRUE,zipparm=zipparm,zipcov=TRUE,
                    triang_Q=triang1, urules=urules1,
                    only_y=TRUE,qform=qform)
  if(is.character(temp)) next
  else this3[j,] <- unlist(temp)
  j <- j+1
}
proc.time() - time

mean(rowMeans(this3))
sd(rowMeans(this3))


#ipw
nsims <- 100
j <- 1
this4 <- matrix(NA,nsims,nsubj)

time <- proc.time()
while(j<=nsims){
  print(j)
  temp <- batchsim3(m,nsubj,maxtime,maxstage,
                    mumat0,covcube0,wvec,
                    trtfun, maxdepth, 
                    optimal=TRUE,zipparm=zipparm,zipcov=TRUE,
                    triang_Q=triang2, urules=urules2,
                    only_y=TRUE,qform=qform)
  if(is.character(temp)) next
  else this4[j,] <- unlist(temp)
  j <- j+1
}
proc.time() - time

mean(rowMeans(this4))
sd(rowMeans(this4))


#reg
nsims <- 100
j <- 1
this5 <- matrix(NA,nsims,nsubj)

time <- proc.time()
while(j<=nsims){
  print(j)
  temp <- batchsim3(m,nsubj,maxtime,maxstage,
                    mumat0,covcube0,wvec,
                    trtfun, maxdepth, 
                    optimal=TRUE,zipparm=zipparm,zipcov=TRUE,
                    triang_Q=triang3, urules=urules3,
                    only_y=TRUE,qform=qform)
  if(is.character(temp)) next
  else this5[j,] <- unlist(temp)
  j <- j+1
}
proc.time() - time

mean(rowMeans(this5))
sd(rowMeans(this5))



c(mean(rowMeans(this1)),mean(rowMeans(this3)),
  mean(rowMeans(this4)),mean(rowMeans(this5)))
c(sd(rowMeans(this1)),sd(rowMeans(this3)),
  sd(rowMeans(this4)),sd(rowMeans(this5)))

