rm(list=ls())
require(Matrix)
require("Rcpp")
setwd("~/Desktop/myRpackage")
compileAttributes("rarhsmm_1.0.8")
setwd("~/Desktop/myRpackage/rarhsmm_1.0.8")
devtools::document()
devtools::load_all()

##################################################
#weighted ridge regression
ridge <- function(x, y, shrink1){
  n <- nrow(x)
  if(is.null(n)){
    return("too few obs")
  }else if(n==1){
    return("too few obs") 
  }else{
    part1 <- t(x) %*% x + Diagonal(ncol(x), shrink1)
    part2 <- t(x) %*% y
    coef <- solve(part1, part2)
    return(as.matrix(coef))
  }
}



aipw_sim <- function(pps_coef, y_coef, xmat){
  mat1 <- cbind(1,xmat)
  n <- nrow(xmat)
  y <- rep(NA, n)
  trt <- rep(NA, n)
  
  for(i in 1:n){
    logitp <- mat1[i,] %*% pps_coef
    p <- exp(logitp) / (1+exp(logitp))
    trt[i] <- rbinom(1, 1, p)
    vec2 <- c(1, trt[i], xmat[i,])
    y[i] <- vec2 %*% y_coef + rnorm(1)
  }
  return(list(y=y,trt=trt))
}


aipw_est <- function(y, trt, xmat, shrink=0){
  n <- nrow(xmat)
  p <- ncol(xmat)
  xname <- paste("x",1:p,sep='')
  ppsmat <- cbind(trt,xmat,y)
  colnames(ppsmat) <- c("trt",xname,"y")
  ppsmat <- data.frame(ppsmat)
  
  #propensity score model
  body1 <- paste(c("trt",xname),c("~",rep("+",p-1),""),collapse="")
  ppsmod <- glm(body1, data=ppsmat, family=binomial(link="logit"))
  pps <- predict(ppsmod, ppsmat[,xname], type="response")
  
  #since no unmeasured confounders!
  #no need to use ipw when computing y_coef, already consistent!
  #in this example, misspecified conditional expectation for y
  #should be trt+x1+...+x3
  mat <- cbind(1, data.matrix(ppsmat[,c("trt",xname[1])]))
  y_coef <- ridge(mat, ppsmat$y, shrink)
  yhat <- mat %*% y_coef
  
  y_aipw <- sapply(1:n, function(k){
    if(ppsmat$trt[k]==1){
      y[k] / pps[k] - (1-pps[k]) * yhat[k] / pps[k] 
    }else{
      y[k] / (1-pps[k]) - pps[k] * yhat[k] / (1-pps[k])
    }
  })
  
  ymat <- data.frame(cbind(trt=ppsmat$trt, y_aipw=y_aipw))
  agg <- aggregate(y_aipw~trt, data=ymat, mean)
  ate <- agg[2,2] - agg[1,2]
  return(list(rawtrt=y_coef[2], aipw=ate))
}

##################################
#small simulation study
xmat <- mvrnorm(500, c(0,0,0), matrix(c(1,0.5,0.3,0.4,1.3,0.4,0.3,0.5,1),3,3,byrow=T))
pps_coef <- c(0.1, 0.1, 0.2, 0.3)
y_coef <- c(1,0.5, 0.4, 0.3,0.2)
raw <- rep(NA, 200)
aipw <- rep(NA, 200)

for(b in 1:200){
  res <- aipw_sim(pps_coef, y_coef, xmat)
  y <- res$y
  trt <- res$trt
  
  est <- aipw_est(y, trt, xmat, shrink=0)
  raw[b] <- est$rawtrt
  aipw[b] <- est$aipw
}

mean(raw)
mean(aipw)
#https://www.ncbi.nlm.nih.gov/pmc/articles/PMC3640350/
#aipw for qhat

