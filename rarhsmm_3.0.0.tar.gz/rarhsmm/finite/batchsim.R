batchsim2 <- function(m,nsubj,maxtime,maxstage,
                         mumat0,covcube0,wvec,
                         trtfun, maxdepth,#basecov=TRUE,
                         optimal=FALSE,zipparm=NULL, zipcov,
                         triang_Q=NULL, urules=NULL,
                         only_y=FALSE,qform=1){
  
  trtlist <- vector(mode="list",length=nsubj)
  timelist <- vector(mode="list",length=nsubj)
  xlist <- vector(mode="list",length=nsubj)
  statelist <- vector(mode="list",length=nsubj)
  problist <- vector(mode="list",length=nsubj)
  baselist <- vector(mode="list",length=nsubj)
  initiallist <- vector(mode="list",length=nsubj)
  ylist <- vector(mode="list",length=nsubj)
  error <- 0
  i <- 1
  
  while(i <= nsubj){
    if(error > 200){ return("error!")}
    
    gaussian <- gaussianmix(mumat0,covcube0,wvec)
    base4y <- gaussian$obs
    delta <- gaussian$probs
    #uu <- runif(1)
    #delta <- c(uu, 1-uu)
    
    u1 <- runif(1,-4,-3)
    u2 <- runif(1,-4,-3)
    scalemat <- matrix(c(u1, 0.1,
                         u2, 0.1), 
                       byrow=TRUE,nrow=2,ncol=2)
    
    mumat <- matrix(c(-7,-5,-3,
                      7,5,3),
                    byrow=TRUE,nrow=2,ncol=3)
    covcube <- array(0, dim=c(3,3,2))
    arcube <- array(0, dim=c(3,3,2))
    covcube[,,2] <- diag(2-0.2,3) + matrix(0.2,3,3)
    covcube[,,1] <- diag(1,3)
    arcube[,,2] <- diag(0.1,3)
    
    mod <- list(m=m,scalemat=scalemat,
                mumat=mumat, covcube=covcube, arcube=arcube)
    u5 <- runif(1, -4, -3)
    u6 <- runif(1, -3, -2)
    zeroparm <- c(u5, 0.1)# int,  p[1:m-1]
    rateparm <- c(u6, -0.1)#
    
    if(optimal==TRUE){
      result <- try(ar1.smp.sim1opt(maxtime, maxstage,mod, delta,
                                    zeroparm, rateparm,
                                    zipparm, zipcov, triang_Q, urules,
                                    trtfun,maxdepth),silent=TRUE)
      if(class(result)=="try-error") {
        error <- error + 1
        next}
    }else{
      result <- ar1.smp.sim1(maxtime,maxstage,mod,delta,zeroparm,rateparm,
                             trtfun)
    } 
    
    #summarize the trt responses: state 1 is good, 2 is bad
    tempd <- trtdiff(result$trts, result$states)
    trt0d <- tempd[1]
    trt1d <- tempd[2]
    
    #get the other predictors
    e <- rnorm(1,0,1)
    treatment <- tail(result$trts, 1)
    p1 <- tail(result$stateprobs, 1)[1]
    if(trt1d > 0) dopt <- 1
    else{
      if(trt0d < 0) dopt <- 1
      else dopt <- 0
    }
    
    ccc <- treatment * dopt + (1-treatment) * (1-dopt)
     
    if(qform==2){
        y <- 1 + 0.5 * p1 + 5.5*ccc + e 
    }else if(qform==3){
      y <- 1 + 0.5*exp(p1-0.1) + 1.2 * exp(1.8 * ccc) + e
    }
     
    #gather the results
    timelist[[i]] <- result$times
    trtlist[[i]] <- result$trts
    baselist[[i]] <- base4y
    problist[[i]] <- result$stateprobs
    statelist[[i]] <- result$states
    initiallist[[i]] <- delta
    ylist[[i]] <- y
    
    if(i==nsubj & is.null(result$series)){
      xlist[[i+1]] <- 1
      xlist[[i+1]] <- NULL
    }else{
      xlist[[i]] <- result$series
    }
    
    i <- i+1
  }
  
  if(only_y) return(ylist)
  else return(list(xlist=xlist,baselist=baselist,timelist=timelist,
                   trtlist=trtlist,statelist=statelist,
                   initiallist=initiallist,
                   problist=problist,ylist=ylist,mod=mod))
}


########################################################################
batchsim3 <- function(m,nsubj,maxtime,maxstage,
                      mumat0,covcube0,wvec,
                      trtfun, maxdepth,#basecov=TRUE,
                      optimal=FALSE,zipparm=NULL, zipcov,
                      triang_Q=NULL, urules=NULL,
                      only_y=FALSE,qform=1){
  
  trtlist <- vector(mode="list",length=nsubj)
  timelist <- vector(mode="list",length=nsubj)
  xlist <- vector(mode="list",length=nsubj)
  statelist <- vector(mode="list",length=nsubj)
  problist <- vector(mode="list",length=nsubj)
  baselist <- vector(mode="list",length=nsubj)
  initiallist <- vector(mode="list",length=nsubj)
  ylist <- vector(mode="list",length=nsubj)
  error <- 0
  i <- 1
  
  while(i <= nsubj){
    if(error > 200){ return("error!")}
    
    gaussian <- gaussianmix(mumat0,covcube0,wvec)
    base4y <- gaussian$obs
    delta <- gaussian$probs
    #uu <- runif(1)
    #delta <- c(uu, 1-uu)
    
    u1 <- runif(6, -4, -3) #be careful of this initial value
    
    scalemat <- matrix(c(u1[1], 0.1, u1[2], 0.1, u1[3], 0.1,
                         u1[4], 0.1, u1[5], 0.1, u1[6], 0.1), 
                       byrow=TRUE,nrow=6,ncol=2)
    
   
    mumat <- matrix(c(-8,-8,-8,
                      0,0,0,
                      8,8,8),
                    byrow=TRUE,nrow=3,ncol=3)
    
    covcube <- array(0, dim=c(3,3,3))
    arcube <- array(0, dim=c(3,3,3))
    covcube[,,1] <- diag(2-0.1,3) + matrix(0.1,3,3)
    covcube[,,3] <- diag(2-0.1,3) + matrix(0.1,3,3)
    covcube[,,2] <- diag(1,3)
    arcube[,,1] <- diag(0.1,3)
    arcube[,,3] <- diag(0.1,3)
    
    
    mod <- list(m=m,scalemat=scalemat,
                mumat=mumat, covcube=covcube, arcube=arcube)
    u5 <- runif(1, -4, -3)
    u6 <- runif(1, -3, -2)
    zeroparm <- c(u5, -0.1, 0.1)#int, p[1:m-1]
    rateparm <- c(u6, 0.1, -0.1)# 
    
    if(optimal==TRUE){
      result <- try(ar1.smp.sim1opt(maxtime, maxstage,mod, delta,
                                    zeroparm, rateparm,
                                    zipparm, zipcov, triang_Q, urules,
                                    trtfun,maxdepth),silent=TRUE)
      if(class(result)=="try-error") {
        error <- error + 1
        next}
    }else{
      result <- ar1.smp.sim1(maxtime,maxstage,mod,delta,zeroparm,rateparm,
                             trtfun)
    } 
    
    #summarize the trt responses: state 2 is good, 1 and 3 are bad
    tempd <- trtdiff3(result$trts, result$states)
    trt0_1v2 <- tempd[1]
    trt0_3v2 <- tempd[2]
    trt1_1v2 <- tempd[3]
    trt1_3v2 <- tempd[4]
    
    #get the other predictors
    e <- rnorm(1,0,0.1)
    treatment <- tail(result$trts, 1)
    p1 <- tail(result$stateprobs, 1)[1]
    p2 <- tail(result$stateprobs, 1)[2]
    
    if(trt0_1v2 > 0){
      if(trt0_3v2 > 0) dopt <- 1
      else{
        if(trt1_1v2 < 0) dopt <- 1
        else dopt <- 0
      }
    }else{
      if(trt0_3v2 < 0) dopt <- 0
      else{
        if(trt1_3v2 > 0) dopt <- 0
        else dopt <- 1
      }
    }
         
    
    ccc <- treatment * dopt + (1-treatment) * (1-dopt)
    
    if(qform==2){
      y <- 1 - 0.3*p1 + 0.4*p2 + 5.5*ccc + e
    }
    else if(qform==3){ 
    }
    
    #gather the results
    timelist[[i]] <- result$times
    trtlist[[i]] <- result$trts
    baselist[[i]] <- base4y
    problist[[i]] <- result$stateprobs
    statelist[[i]] <- result$states
    initiallist[[i]] <- delta
    ylist[[i]] <- y
    
    if(i==nsubj & is.null(result$series)){
      xlist[[i+1]] <- 1
      xlist[[i+1]] <- NULL
    }else{
      xlist[[i]] <- result$series
    }
    
    i <- i+1
  }
  
  if(only_y) return(ylist)
  else return(list(xlist=xlist,baselist=baselist,timelist=timelist,
                   trtlist=trtlist,statelist=statelist,
                   initiallist=initiallist,
                   problist=problist,ylist=ylist,mod=mod))
}
