########################################################################
batchsim3_inf <- function(m,nsubj,maxtime,maxstage,
                      mumat0,covcube0,wvec,
                      trtfun, utilfun,
                      optimal=FALSE,zipparm=NULL, zipcov,
                      triang_Q=NULL, urules=NULL,
                      only_u=FALSE){
  
  trtlist <- vector(mode="list",length=nsubj)
  timelist <- vector(mode="list",length=nsubj)
  xlist <- vector(mode="list",length=nsubj)
  statelist <- vector(mode="list",length=nsubj)
  problist <- vector(mode="list",length=nsubj)
  baselist <- vector(mode="list",length=nsubj)
  initiallist <- vector(mode="list",length=nsubj)
  ulist <- vector(mode="list",length=nsubj)
  trtcontrastlist <- vector(mode="list",length=nsubj)
  
  error <- 0
  i <- 1
  
  while(i <= nsubj){
    if(error > 200){ return("error!")}
    
    gaussian <- gaussianmix(mumat0,covcube0,wvec)
    base4y <- gaussian$obs
    delta <- gaussian$probs
    #uu <- runif(1)
    #delta <- c(uu, 1-uu)
    
    u1 <- runif(6, -4,-3) #be careful of this initial value
    
    scalemat <- matrix(c(u1[1], 0.1,-0.1, u1[2], 0.1,-0.1, u1[3], 0.1,-0.1,
                         u1[4], 0.1,-0.1, u1[5], 0.1,-0.1, u1[6], 0.1,-0.1), 
                       byrow=TRUE,nrow=6,ncol=3)
    
    
    mumat <- matrix(c(-8,-8,-8,
                      0,0,0,
                      8,8,8),
                    byrow=TRUE,nrow=3,ncol=3)
    
    covcube <- array(0, dim=c(3,3,3))
    arcube <- array(0, dim=c(3,3,3))
    covcube[,,1] <- diag(2-0.1,3) + matrix(0.1,3,3)
    covcube[,,3] <- diag(2-0.1,3) + matrix(0.1,3,3)
    covcube[,,2] <- diag(1,3)
    #arcube[,,1] <- diag(0.1,3)
    #arcube[,,3] <- diag(0.1,3)
    
    
    mod <- list(m=m,scalemat=scalemat,
                mumat=mumat, covcube=covcube, arcube=arcube)
    u5 <- runif(1, -4, -3) 
    u6 <- runif(1, -3, -2)
    zeroparm <- c(u5, -0.1,0.1)#int, p[1:m-1]   -0.1,0.1
    rateparm <- c(u6, 0.1,-0.1)#             0.1,-0.1
    
   
      result <- ar1.smp.sim2(maxtime,maxstage,mod,delta,zeroparm,rateparm,
                             trtfun, utilfun)
    
    
    #gather the results
    timelist[[i]] <- result$times
    trtlist[[i]] <- result$trts
    baselist[[i]] <- base4y
    problist[[i]] <- result$stateprobs
    statelist[[i]] <- result$states
    initiallist[[i]] <- delta
    ulist[[i]] <- result$utility
    trtcontrastlist[[i]] <- result$trtcontrasts
    
    if(i==nsubj & is.null(result$series)){
      xlist[[i+1]] <- 1
      xlist[[i+1]] <- NULL
    }else{
      xlist[[i]] <- result$series
    }
    
    i <- i+1
  }
  
  if(only_u) return(ulist)
  else return(list(xlist=xlist,baselist=baselist,timelist=timelist,
                   trtlist=trtlist,statelist=statelist,
                   initiallist=initiallist,trtcontrastlist=trtcontrastlist,
                   problist=problist,ulist=ulist,mod=mod))
}


########################################################################
batchsim3_inf_fuzzy <- function(m,nsubj,maxtime,maxstage,
mumat0,covcube0,wvec,
trtfun, utilfun,
optimal=FALSE,zipparm=NULL, zipcov,
triang_Q=NULL, urules=NULL,
only_u=FALSE){
    
    trtlist <- vector(mode="list",length=nsubj)
    timelist <- vector(mode="list",length=nsubj)
    xlist <- vector(mode="list",length=nsubj)
    statelist <- vector(mode="list",length=nsubj)
    problist <- vector(mode="list",length=nsubj)
    baselist <- vector(mode="list",length=nsubj)
    initiallist <- vector(mode="list",length=nsubj)
    ulist <- vector(mode="list",length=nsubj)
    trtcontrastlist <- vector(mode="list",length=nsubj)
    
    error <- 0
    i <- 1
    
    while(i <= nsubj){
        if(error > 200){ return("error!")}
        
        gaussian <- gaussianmix(mumat0,covcube0,wvec)
        base4y <- gaussian$obs
        delta <- gaussian$probs
        #uu <- runif(1)
        #delta <- c(uu, 1-uu)
        
        u1 <- runif(6, -4,-3) #be careful of this initial value
        
        scalemat <- matrix(c(u1[1], 0.1,-0.1, u1[2], 0.1,-0.1, u1[3], 0.1,-0.1,
        u1[4], 0.1,-0.1, u1[5], 0.1,-0.1, u1[6], 0.1,-0.1),
        byrow=TRUE,nrow=6,ncol=3)
        
        
        mumat <- matrix(c(-4,-2, 2,
        0,0,0,
        4,2,-2),
        byrow=TRUE,nrow=3,ncol=3)
        
        covcube <- array(0, dim=c(3,3,3))
        arcube <- array(0, dim=c(3,3,3))
        covcube[,,1] <- diag(2-0.1,3) + matrix(0.1,3,3)
        covcube[,,3] <- diag(2-0.1,3) + matrix(0.1,3,3)
        covcube[,,2] <- diag(1,3)
        #arcube[,,1] <- diag(0.1,3)
        #arcube[,,3] <- diag(0.1,3)
        
        
        mod <- list(m=m,scalemat=scalemat,
        mumat=mumat, covcube=covcube, arcube=arcube)
        u5 <- runif(1, -4, -3)
        u6 <- runif(1, -3, -2)
        zeroparm <- c(u5, -0.1,0.1)#int, p[1:m-1]   -0.1,0.1
        rateparm <- c(u6, 0.1,-0.1)#             0.1,-0.1
        
        
        result <- ar1.smp.sim2(maxtime,maxstage,mod,delta,zeroparm,rateparm,
        trtfun, utilfun)
        
        
        #gather the results
        timelist[[i]] <- result$times
        trtlist[[i]] <- result$trts
        baselist[[i]] <- base4y
        problist[[i]] <- result$stateprobs
        statelist[[i]] <- result$states
        initiallist[[i]] <- delta
        ulist[[i]] <- result$utility
        trtcontrastlist[[i]] <- result$trtcontrasts
        
        if(i==nsubj & is.null(result$series)){
            xlist[[i+1]] <- 1
            xlist[[i+1]] <- NULL
        }else{
            xlist[[i]] <- result$series
        }
        
        i <- i+1
    }
    
    if(only_u) return(ulist)
    else return(list(xlist=xlist,baselist=baselist,timelist=timelist,
    trtlist=trtlist,statelist=statelist,
    initiallist=initiallist,trtcontrastlist=trtcontrastlist,
    problist=problist,ulist=ulist,mod=mod))
}
