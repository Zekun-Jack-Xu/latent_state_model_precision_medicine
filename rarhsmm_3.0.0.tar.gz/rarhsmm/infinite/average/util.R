
require(Matrix)
########################################################
#generate gaussian mixture obs and probs
gaussianmix <- function(mumat, covcube, wvec){
  k <- nrow(mumat)
  cutoff <- cumsum(wvec)
  u <- runif(1)
  
  for(i in 1:length(cutoff)){
    if(u<=cutoff[i]){
      index <- i
      break
    }
  }
  
  obs <- mvrnorm(1, mumat[index,], covcube[,,index])
  probs <- rep(NA, k)
  for(i in 1:k) probs[i] <- mvdnorm(obs, mumat[i,], covcube[,,i], FALSE)
  probs <- probs / sum(probs)
  return(list(obs=obs, probs=probs))
}

##################################

###################################################################
#create formatted data  
format2 <- function(m, trtlist, foolist,  ulist, timelist,
                    xlist, problist=NULL){
  
  nsubj <- length(trtlist) 
  #remove the last treatment assignment since
  #the corresponding utility is not observed
  aug_trtlist <- lapply(1:nsubj, function(k)
                 trtlist[[k]][-length(trtlist[[k]])])
  trtvec <- Reduce("c",aug_trtlist)
  
  timedifflist <- lapply(1:nsubj,function(k)diff(timelist[[k]]))
  timediffvec <- Reduce("c",timedifflist)
  
  terminallist <- lapply(1:nsubj,function(k){
                      l <- length(aug_trtlist[[k]])
                      c(rep(0,l-1),1)   })
  terminalvec <- Reduce("c", terminallist)
  
  aug_probt <- lapply(1:nsubj, function(k)
                foolist[[k]][-nrow(foolist[[k]]),,drop=FALSE])
  probt <- Reduce("rbind", aug_probt)
  aug_probtp1 <- lapply(1:nsubj, function(k)
               foolist[[k]][-1,,drop=FALSE])
  probtp1 <- Reduce('rbind',aug_probtp1)
  
  
  uvec <- Reduce("c",ulist)
  
  nrep <- sapply(1:nsubj, function(k) length(ulist[[k]]))
  subjvec <- rep(1:nsubj, nrep)
  
  aug_xlist <- lapply(1:nsubj, function(k)
    rbind(rep(NA,ncol(xlist[[1]])),
          xlist[[k]][-nrow(xlist[[k]]),,drop=FALSE])
    )
  aug_x <- Reduce("rbind",aug_xlist)
  aug_tp1x <- Reduce("rbind",xlist)
  xnames <- paste(c(rep("x",ncol(aug_tp1x)),rep("tp1x",ncol(aug_tp1x))),
                        1:ncol(aug_tp1x),sep="")
  
  if(is.null(problist)){
    augdat <- data.frame(cbind(subjvec,trtvec,probt,probtp1,
                               uvec, terminalvec, timediffvec,
                               aug_x,aug_tp1x))
    if(m==2){
        colnames(augdat) <- c("subjid","trt","p1t","p2t","p1tp1","p2tp1",
                              "u", "final",
                              "timediff",xnames)
       
    }else if(m==3){
      colnames(augdat) <- c("subjid","trt","p1t","p2t","p3t",
                            "p1tp1","p2tp1","p3tp1",
                            "u","final",
                            "timediff",xnames)
    }
  }else{ #not is.null(problist)
    
    true_probt <- lapply(1:nsubj, function(k)
      problist[[k]][-nrow(problist[[k]]),,drop=FALSE])
    trueprobt <- Reduce("rbind", true_probt)
    true_probtp1 <- lapply(1:nsubj, function(k)
      problist[[k]][-1,,drop=FALSE])
    trueprobtp1 <- Reduce('rbind',true_probtp1)
    
    augdat <- data.frame(cbind(subjvec,trtvec,probt,probtp1,
                               uvec, terminalvec, timediffvec,
                               aug_x,aug_tp1x,trueprobt,trueprobtp1))
    if(m==2){
      colnames(augdat) <- c("subjid","trt","p1t","p2t","p1tp1","p2tp1",
                            "u", "final",
                            "timediff",xnames,"truep1t","truep2t",
                            "truep1tp1","truep2pt1")
      
    }else if(m==3){
      colnames(augdat) <- c("subjid","trt","p1t","p2t","p3t",
                            "p1tp1","p2tp1","p3tp1",
                            "u","final",
                            "timediff",xnames,"truep1t","truep2t","truep3t",
                            "truep1tp1","truep2tp1","truep3tp1")
    }
  }

  return(augdat)
}



##############################################
###################################################
#valueparm | policyparm: argmin estimating equations
Lambda_func_dis <- function(valueparm, policyparm, nsubj, data, 
                         valuename1, valuename2,  policyname,
                        disfactor, ppsmat, ktrt,
                        tausq=0.0625, 
                        kappa=c(0,0.25,0.5,0.75,1),
                        type=1, tuning=0.001){
  
  
    #separate datamat into valuemat and policymat
    #separate parms into valueparm and policyparm
    utility <- data$u
    trt <- data$trt
    #pps <- data$pps
    valuemat1 <- data.matrix(data)[,valuename1,drop=FALSE]
    valuemat2 <- data.matrix(data)[,valuename2,drop=FALSE]
    policymat <- data.matrix(data)[,policyname,drop=FALSE]
    
    p2 <- length(policyname)+1
    policyparmmat <- matrix(policyparm,nrow=ktrt-1,ncol=p2,byrow=TRUE)
    
    val <- lambdaEEdis(nsubj, valueparm, valuemat1, valuemat2,
                       policyparmmat, policymat,utility, trt,
                       ppsmat, disfactor, tausq,kappa,type,tuning)
    
    return(val)
    
}

##############################
#policyparm | valueparm: argmax empirical value
V_func_dis <- function(policyparm, valueparm,
                   nsubj, data, 
                   valuename1, valuename2,  policyname,
                   disfactor,ppsmat,ktrt,
                   tausq=0.0625, 
                   kappa=c(0,0.25,0.5,0.75,1),
                   type=1, tuning=0.001){
  

    utility <- data$u
    trt <- data$trt
    #pps <- data$pps
    valuemat1 <- data.matrix(data)[,valuename1,drop=FALSE]
    valuemat2 <- data.matrix(data)[,valuename2,drop=FALSE]
    policymat <- data.matrix(data)[,policyname,drop=FALSE]
    p2 <- length(policyname)+1
    policyparmmat <- matrix(policyparm,nrow=ktrt-1,ncol=p2,byrow=TRUE)
    
      val <- vEEdis(nsubj, valueparm, valuemat1, valuemat2,
                       policyparmmat, policymat,utility, trt,
                       ppsmat, disfactor, tausq,kappa,type,tuning)
   
    return(-val)
}

#########################################
####################################
fit.dis <- function(valueparm, policyparm,
                        nsubj, augdata, valuename1, valuename2, policyname,
                        disfactor, ppsmat, ktrt, tausq=0.0625, 
                        kappa=c(0,0.25,0.5,0.75,1),
                        type=1,  tuning1=1, tuning2=1,
                        maxit=30,eps=1e-3,
                        print=TRUE){
  
  #start with value parm all zeros

  temppol <- optim(policyparm, V_func_dis,
                   valueparm=valueparm,
                   nsubj=nsubj,data=augdata, 
                   valuename1=valuename1, valuename2=valuename2,
                   policyname=policyname,
                   disfactor=disfactor,ppsmat=ppsmat,
                   ktrt=ktrt,tausq=tausq,
                   kappa=kappa, type=type, tuning=tuning2,
                   method="BFGS")
  
  policyparm <- temppol$par
  
  old_par_pol <- temppol$par
  old_nllk_pol <- temppol$val
  
  for(k in 1:maxit){
    if(print==TRUE) cat("iteration:", k,"\n")
    
    tempv <- optim(valueparm, Lambda_func_dis,
                   policyparm=policyparm,
                   nsubj=nsubj,data=augdata, 
                   valuename1=valuename1, valuename2=valuename2,
                   policyname=policyname,
                   disfactor=disfactor,ppsmat=ppsmat,
                   ktrt=ktrt,tausq=tausq,
                   kappa=kappa, type=type, tuning=tuning1, 
                   method="BFGS")
    
    valueparm <- tempv$par
    
    temppol <- optim(policyparm, V_func_dis,
                     valueparm=valueparm,
                     nsubj=nsubj,data=augdata, 
                     valuename1=valuename1, valuename2=valuename2,
                     policyname=policyname,
                     disfactor=disfactor,ppsmat=ppsmat,
                     ktrt=ktrt,tausq=tausq,
                     kappa=kappa, type=type, tuning=tuning2, 
                     method="BFGS")
   
    policyparm <- temppol$par
    new_par_pol <- temppol$par
    new_nllk_pol <- temppol$value
    
    
    tol1 <- sum(abs(new_par_pol-old_par_pol))/sum(abs(old_par_pol))
    tol2 <- abs(new_nllk_pol - old_nllk_pol)/abs(old_nllk_pol)
    tol3 <- abs(new_nllk_pol - old_nllk_pol)
    if( tol1 < eps & (tol2 < eps | tol3 < eps)){
      break
    }else{
      old_nllk_pol <- new_nllk_pol
      old_par_pol <- new_par_pol
    }
    if(print==TRUE) {
      cat("reldiff_pol:", tol1,"; -value",old_nllk_pol,"\n")
      print(valueparm)
      print(policyparm)
    }
  }
  
  return(list(valueparm=valueparm,policyparm=policyparm))
}

##############################################
###################################################
#valueparm | policyparm: argmin estimating equations
Lambda_func_tot <- function(valueparm, policyparm, nsubj, data, 
                            valuename1, valuename2,  policyname,
                            termprob,ppsmat,ktrt,
                            tausq=0.0625, 
                            kappa=c(0,0.25,0.5,0.75,1),
                            type=1, tuning=0.001){
  
  
  #separate datamat into valuemat and policymat
  #separate parms into valueparm and policyparm
  utility <- data$u
  trt <- data$trt
  #pps <- data$pps
  valuemat1 <- data.matrix(data)[,valuename1,drop=FALSE]
  valuemat2 <- data.matrix(data)[,valuename2,drop=FALSE]
  policymat <- data.matrix(data)[,policyname,drop=FALSE]
  p2 <- length(policyname)+1
  policyparmmat <- matrix(policyparm,nrow=ktrt-1,ncol=p2,byrow=TRUE)
  
  val <- lambdaEEtot(nsubj, valueparm, valuemat1, valuemat2,
                     policyparmmat, policymat,utility, trt,
                     ppsmat, termprob, tausq,kappa,type,tuning)
  
  return(val)
  
}

##############################
#policyparm | valueparm: argmax empirical value
V_func_tot <- function(policyparm, valueparm,
                       nsubj, data, 
                       valuename1, valuename2,  policyname,
                       termprob,ppsmat,ktrt,
                       tausq=0.0625, 
                       kappa=c(0,0.25,0.5,0.75,1),
                       type=1, tuning=0.001){
  
  
  utility <- data$u
  trt <- data$trt
  #pps <- data$pps
  valuemat1 <- data.matrix(data)[,valuename1,drop=FALSE]
  valuemat2 <- data.matrix(data)[,valuename2,drop=FALSE]
  policymat <- data.matrix(data)[,policyname,drop=FALSE]
  p2 <- length(policyname)+1
  policyparmmat <- matrix(policyparm,nrow=ktrt-1,ncol=p2,byrow=TRUE)
  
  val <- vEEtot(nsubj, valueparm, valuemat1, valuemat2,
                policyparmmat, policymat,utility, trt,
                ppsmat, termprob, tausq,kappa,type,tuning)
  
  return(-val)
}

#########################################
####################################
fit.tot <- function(valueparm, policyparm,
                    nsubj, augdata, valuename1, valuename2, policyname,
                    termprob, ppsmat,ktrt, tausq=0.0625, 
                    kappa=c(0,0.25,0.5,0.75,1),
                    type=1,  tuning1=1, tuning2=1,
                    maxit=30,eps=1e-3,
                    print=TRUE){
  
  #start with value parm all zeros
  
  temppol <- optim(policyparm, V_func_tot,
                   valueparm=valueparm,
                   nsubj=nsubj,data=augdata, 
                   valuename1=valuename1, valuename2=valuename2,
                   policyname=policyname,
                   termprob=termprob,ppsmat=ppsmat,
                   ktrt=ktrt,tausq=tausq,
                   kappa=kappa, type=type, tuning=tuning2,
                   method="BFGS")
  
  policyparm <- temppol$par
  old_par_pol <- temppol$par
  old_nllk_pol <- temppol$val
  
  for(k in 1:maxit){
    if(print==TRUE) cat("iteration:", k,"\n")
    
    tempv <- optim(valueparm, Lambda_func_tot,
                   policyparm=policyparm,
                   nsubj=nsubj,data=augdata, 
                   valuename1=valuename1, valuename2=valuename2,
                   policyname=policyname,
                   termprob=termprob,ppsmat=ppsmat,
                   ktrt=ktrt,tausq=tausq,
                   kappa=kappa, type=type, tuning=tuning1, 
                   method="BFGS")
    
    valueparm <- tempv$par
    
    temppol <- optim(policyparm, V_func_tot,
                     valueparm=valueparm,
                     nsubj=nsubj,data=augdata, 
                     valuename1=valuename1, valuename2=valuename2,
                     policyname=policyname,
                     termprob=termprob,ppsmat=ppsmat,
                     ktrt=ktrt,tausq=tausq,
                     kappa=kappa, type=type, tuning=tuning2, 
                     method="BFGS")
    
    policyparm <- temppol$par
    new_par_pol <- temppol$par
    new_nllk_pol <- temppol$value
    
    tol1 <- sum(abs(new_par_pol-old_par_pol))/sum(abs(old_par_pol))
    tol2 <- abs(new_nllk_pol - old_nllk_pol)/abs(old_nllk_pol)
    tol3 <- abs(new_nllk_pol - old_nllk_pol)
    if( tol1 < eps & (tol2 < eps | tol3 < eps)){
      break
    }else{
      old_nllk_pol <- new_nllk_pol
      old_par_pol <- new_par_pol
    }
    if(print==TRUE) {
      cat("reldiff_pol:", tol1,"; -value",old_nllk_pol,"\n")
      print(valueparm)
      print(policyparm)
    }
  }
  
  
  return(list(valueparm=valueparm,policyparm=policyparm))
}

##############################################
###################################################
#valueparm | policyparm: argmin estimating equations
Lambda_func_avg <- function(augvalueparm, policyparm, nsubj, data, 
                            valuename1, valuename2,  policyname, 
                            ppsmat, ktrt, tausq=0.0625, 
                            kappa=c(0,0.25,0.5,0.75,1),
                            type=1, tuning=0.001){
  
  
  #separate datamat into valuemat and policymat
  #separate parms into valueparm and policyparm
  utility <- data$u
  trt <- data$trt
  #pps <- data$pps
  subjden <- augdata$subjden
  
  valueparm <- augvalueparm[-length(augvalueparm)]
  vavg <- augvalueparm[length(augvalueparm)]
    
  valuemat1 <- data.matrix(data)[,valuename1,drop=FALSE]
  valuemat2 <- data.matrix(data)[,valuename2,drop=FALSE]
  policymat <- data.matrix(data)[,policyname,drop=FALSE]
  p2 <- length(policyname)+1
  policyparmmat <- matrix(policyparm,nrow=ktrt-1,ncol=p2,byrow=TRUE)
  
  val <- lambdaEEavg(nsubj, valueparm, valuemat1, valuemat2,
                     policyparmmat, policymat,utility, trt,
                     ppsmat, subjden,tausq,kappa,type,tuning, vavg)
  
  return(val)
  
}

##############################
#policyparm | valueparm: argmax empirical value
V_func_avg <- function(policyparm, augvalueparm,
                       nsubj, data, 
                       valuename1, valuename2,  policyname, 
                       ppsmat,ktrt,tausq=0.0625, 
                       kappa=c(0,0.25,0.5,0.75,1),
                       type=1, tuning=0.001){
  
  m <- m
  utility <- data$u
  trt <- data$trt
  #pps <- data$pps
  subjden <- augdata$subjden
  
  timediff <- data$timediff
  thisstate <- data$thisstate
  valuemat1 <- data.matrix(data)[,valuename1,drop=FALSE]
  valuemat2 <- data.matrix(data)[,valuename2,drop=FALSE]
  policymat <- data.matrix(data)[,policyname,drop=FALSE]
  valueparm <- augvalueparm[-length(augvalueparm)]
  
  p2 <- length(policyname)+1
  policyparmmat <- matrix(policyparm,nrow=ktrt-1,ncol=p2,byrow=TRUE)
  
  val <- vEEavg(nsubj, valueparm, valuemat1, valuemat2,
                policyparmmat, policymat,utility, trt,
                ppsmat, subjden, tausq,kappa,type,tuning)
  
  return(-val)
}

#########################################
####################################
fit.avg <- function(augvalueparm, policyparm, 
                    nsubj, augdata, valuename1, valuename2, policyname,
                    ppsmat, ktrt, tausq=0.0625, 
                    kappa=c(0,0.25,0.5,0.75,1),
                    type=1,  tuning1=1, tuning2=1,
                    maxit=30,eps=1e-3,
                    print=TRUE,...){
  
  #start with value parm all zeros
  
  temppol <- optim(policyparm, V_func_avg,
                   augvalueparm=augvalueparm,
                   nsubj=nsubj,data=augdata, 
                   valuename1=valuename1, valuename2=valuename2,
                   policyname=policyname, ppsmat=ppsmat, 
                   ktrt=ktrt,tausq=tausq,
                   kappa=kappa, type=type, tuning=tuning2,
                   method="BFGS",...)
  
  policyparm <- temppol$par
  old_par_pol <- temppol$par
  old_nllk_pol <- temppol$val
  
  for(k in 1:maxit){
    if(print==TRUE) cat("iteration:", k,"\n")
    
    tempv <- optim(augvalueparm, Lambda_func_avg,
                   policyparm=policyparm, 
                   nsubj=nsubj,ppsmat=ppsmat,data=augdata, 
                   valuename1=valuename1, valuename2=valuename2,
                   policyname=policyname, ktrt=ktrt,tausq=tausq,
                   kappa=kappa, type=type, tuning=tuning1, 
                   method="BFGS")
    
    augvalueparm <- tempv$par
    
    temppol <- optim(policyparm, V_func_avg,
                     augvalueparm=augvalueparm,
                     nsubj=nsubj,data=augdata, 
                     valuename1=valuename1, valuename2=valuename2,
                     policyname=policyname, ppsmat=ppsmat, 
                     ktrt=ktrt,tausq=tausq,
                     kappa=kappa, type=type, tuning=tuning2, 
                     method="BFGS",...)
    
    policyparm <- temppol$par
    new_par_pol <- temppol$par
    new_nllk_pol <- temppol$value
    
    tol1 <- sum(abs(new_par_pol-old_par_pol))/sum(abs(old_par_pol))
    tol2 <- abs(new_nllk_pol - old_nllk_pol)/abs(old_nllk_pol)
    tol3 <- abs(new_nllk_pol - old_nllk_pol)
    if( tol1 < eps & (tol2 < eps | tol3 < eps)){
      break
    }else{
      old_nllk_pol <- new_nllk_pol
      old_par_pol <- new_par_pol
    }
    if(print==TRUE) {
      cat("reldiff_pol:", tol1,"; -value",-augvalueparm[length(augvalueparm)],"\n")
      print(augvalueparm)
      print(policyparm)
    }
  }
  
  
  return(list(augvalueparm=augvalueparm,policyparm=policyparm))
}

