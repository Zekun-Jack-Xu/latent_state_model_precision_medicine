rm(list=ls())
require(Matrix)
require("Rcpp")
require("nnet")
##################


setwd("~/Desktop/myRpackage")
compileAttributes("rarhsmm_2.0.5")
setwd("~/Desktop/myRpackage/rarhsmm_2.0.5")
#devtools::use_package("pracma")
devtools::document()
devtools::load_all()
#devtools::check()
#devtools::build()

setwd("~/Desktop/myRpackage/rarhsmm_2.0.5/infinite/average")
source("batchsim.R")
source("util.R")


###################################################
set.seed(1357)
nsubj <- 200


m <- 3
maxtime <- 364
maxstage <- 100

mumat0 <- matrix(0,nrow=3,ncol=5)
covcube0 <- array(0,dim=c(5,5,3))
covcube0[,,1] <- diag(2,5)
covcube0[,,2] <- diag(1,5)
covcube0[,,3] <- diag(3,5)
wvec <- c(1/3,1/3,1/3)

############################################
trtfun0 <- function(obj){
  #vec <- c(1, obj$delta[1],obj$delta[2])
  #coef1v3 <- c(-0.2,0.8,-0.5)
  #coef2v3 <- c(-0.2,-0.5,0.8)
  #lp1v3 <- coef1v3 %*% vec
  #lp2v3 <- coef2v3 %*% vec
  #p1 <- exp(lp1v3) / (1 + exp(lp1v3) + exp(lp2v3))
  #p2 <- exp(lp2v3) / (1 + exp(lp1v3) + exp(lp2v3))
  #p3 <- 1 / (1 + exp(lp1v3) + exp(lp2v3))
  
  #trt <- rmultinomial(1,3,c(p1,p2,p3),c(1,2,3))
  trt <- rmultinomial(1,3,rep(1/3,3),c(1,2,3))
  if(trt==1) trtcontrast <- c(1,0)
  else if(trt==2) trtcontrast <- c(0,1)
  else trtcontrast <- c(0,0)
  
  return(list(trt=trt,trtcontrast=trtcontrast))
}
trtfun <- trtfun0

############################################
utilfun0 <- function(obj){
  vec <- c(1, obj$lasttrt, 
           obj$lastobj$delta[1],obj$lastobj$delta[2],obj$lastobj$delta[3], #3:5
           obj$delta[2]) #
  
  #simple case first
  
  thisprob1 <- vec[3]
  thisprob2 <- vec[4]
  thisprob3 <- vec[5]
  nextprob2 <- vec[6]
  #trt01v2 <- max(min(vec[5], 5), -5)
  
  #####
  trt <- vec[2]
  u <-  0.5*nextprob2 + rnorm(1) +
    2.5 * (thisprob1 * ifelse(trt==1,1,0) + thisprob2 * ifelse(trt==2,1,0) +
             thisprob3 * ifelse(trt==3,1,0))
  
  return(u)
}

utilfun <- utilfun0

sim1 <- batchsim3_inf_fuzzy( m,nsubj,maxtime,maxstage,
                       mumat0,covcube0,wvec,
                       trtfun, utilfun, 
                       optimal=FALSE,zipparm=NULL,only_u=FALSE)

xlist <- sim1$xlist

#trtlist <- sim1$trtlist
trtcontrastlist <- lapply(1:nsubj,function(k) cbind(1,sim1$trtcontrastlist[[k]]))

timelist <- sim1$timelist
statelist <- sim1$statelist
problist <- sim1$problist
initiallist <- sim1$initiallist
statelist <- sim1$statelist
ulist <- sim1$ulist
mod <- sim1$mod

#get those with only 1 decision stage at baseline
nullid <- NULL
for(j in 1:nsubj){
  if(is.null(nrow(xlist[[j]]))) nullid <- c(nullid,j)
}

if(length(nullid)==0) nullid <- -1


#mle fitting: momentum gradient
#use trtcontrastlist!!!
time <- proc.time()
fitted <- ar1.smp.fit2(mod,timelist, initiallist, xlist, trtcontrastlist, 
                       nullid, mfactor=0.01, stepsize=0.001,maxit=2,eps=1e-4,
                       ar_diag=TRUE,cov_diag=FALSE)
proc.time() - time

natparm <- fitted$natparm

#################################################
foolist <- vector(mode="list",length=nsubj)

for(k in 1:nsubj){
  if(nrow(trtcontrastlist[[k]])==1) foolist[[k]] <- 
      matrix(initiallist[[k]],nrow=1)
  else foolist[[k]] <- ar1.smp.filter1(timelist[[k]], natparm, 
                                       initiallist[[k]],trtcontrastlist[[k]],
                                       xlist[[k]])
}

####################################
trtlist <- sim1$trtlist


#trt&foo&trtd: 1:K    utility: 2:K
#next tasks is to format the data for:
#1. pps:  trt[k] | trtd[k], prob[k]
#2. DTR equation:  

augdata <- format2(m,trtlist, foolist, ulist,timelist,
                   xlist,problist)
augdata <- augdata[complete.cases(augdata),]
#avgprocess <- function(augdata){
#  augdata$thisstate <- apply(augdata[,c("p1t","p2t","p3t")],
#                             1,which.max) - 1 #indexing in c++ starts from 0
#  valuecols <- c("p1t","p2t","p3t","p1tp1","p2tp1","p3tp1")
#  for(nn in valuecols) augdata[,nn] <- round(augdata[,nn])
#  return(augdata)
#}
#augdata <- avgprocess(augdata)

#################################################
###################################################################
#propensity score
ppsmod <- multinom(trt ~ x1+x2+x3, data=augdata)
ppsmat <- predict(ppsmod, augdata[,c("x1","x2","x3")],type="probs")


#ppsmod <- glm(trt ~ p1t+p2t, data=augdata, family=binomial(link="logit"))
#pps <- predict(ppsmod, augdata[,c("x1","x2","x3"),drop=FALSE],type='response')
#augdata$pps1 <- pps
#augdata$pps <- augdata$trt * pps + (1-augdata$trt)*(1-pps)

head(augdata)


runlength <- rle(augdata$subjid)
subjden <- rep(runlength$lengths, runlength$lengths)
augdata$subjden <- subjden

###########################################
#subx <- subset(augdata,!is.na(pps))

valuename1 <- c("x1", "x2","x3")
valuename2 <- c("tp1x1", "tp1x2","tp1x3")
policyname <- c("x1", "x2","x3")

tausq=9
kappa=c(-6,-3,0,3,6)

tuning1=1e-4
tuning2=9e-1
type <- 1

maxit=10
eps=1e-3

augvalueparm <- rep(0,5)
policyparm <- rep(0,8)
ktrt=3

#policygradient
plin <- fit.avg(augvalueparm, policyparm, 
                nsubj, augdata, valuename1, valuename2, policyname,
                ppsmat, ktrt,
                tausq=tausq, kappa=kappa, type=type, 
                tuning1=tuning1, tuning2=tuning2, 
                maxit=maxit,eps=eps,print=TRUE)


#gettrtprob(matrix(plin$policyparm,2,3,byrow=T),c(0,0),1)

V_func_avg(plin$policyparm, plin$augvalueparm,
           nsubj, augdata, 
           valuename1, valuename2,  policyname, 
           ppsmat,ktrt=3,
           tausq, kappa,type=1, tuning2)

#########################################
type <- 2
valueparm <- rep(0,17)
policyparm <- rep(0,8)

tuning1=1e-4
tuning2=9e-1
eps=1e-3


prbf <- fit.avg(augvalueparm, policyparm,
                nsubj, augdata, valuename1, valuename2, policyname,
                ppsmat,ktrt,
                tausq=tausq, kappa=kappa, type=type, 
                tuning1=tuning1, tuning2=tuning2, 
                maxit=maxit,eps=eps, print=TRUE)


##################################################### 
#apply this function to the subjects in this batch
#simulate according to the optimal policy
###################################################
#1. observed

this1 <- mean(sapply(1:nsubj,function(k)mean(ulist[[k]])))


#############################################################3
#optimal policy: linear
trtfun2 <- function(obj){
  vec <- c(1, obj$x[1],obj$x[2],obj$x[3])
  coef1v3 <- plin$policyparm[1:4]
  coef2v3 <- plin$policyparm[5:8]
  lp1v3 <- coef1v3 %*% vec
  lp2v3 <- coef2v3 %*% vec
  p1 <- exp(lp1v3) / (1 + exp(lp1v3) + exp(lp2v3))
  p2 <- exp(lp2v3) / (1 + exp(lp1v3) + exp(lp2v3))
  p3 <- 1 / (1 + exp(lp1v3) + exp(lp2v3))
  
  trt <- rmultinomial(1,3,c(p1,p2,p3),c(1,2,3))
  #trt3 as the reference
  if(trt==1) trtcontrast <- c(1,0)
  else if(trt==2) trtcontrast <- c(0,1)
  else trtcontrast <- c(0,0)
  
  return(list(trt=trt,trtcontrast=trtcontrast))
}

trtfun <- trtfun2

#linear v-learning
nsims <- 100
j <- 1
templist <- vector(mode="list",length=nsims)
this2 <- numeric(nsims)

time <- proc.time()
while(j<=nsims){
  print(j)
  
  temp <- batchsim3_inf_fuzzy( m,nsubj,maxtime,maxstage,
                             mumat0,covcube0,wvec,
                             trtfun, utilfun, 
                             optimal=FALSE,zipparm=NULL,only_u=TRUE)
  if(is.character(temp)) next
  else{
    this2list <- sapply(1:nsubj,function(k) mean(temp[[k]]))
    this2[j] <- mean(this2list)
    j <- j+1
  }
}
proc.time() - time


mean(this2)
sd(this2)

#############################################################3
#optimal policy: rbf

#m0 <- range(augdata$trt0dt)
#m1 <- range(augdata$trt1dt)

trtfun3 <- function(obj){
  vec <- c(1, obj$x[1],obj$x[2],obj$x[3])
  coef1v3 <- prbf$policyparm[1:4]
  coef2v3 <- prbf$policyparm[5:8]
  lp1v3 <- coef1v3 %*% vec
  lp2v3 <- coef2v3 %*% vec
  p1 <- exp(lp1v3) / (1 + exp(lp1v3) + exp(lp2v3))
  p2 <- exp(lp2v3) / (1 + exp(lp1v3) + exp(lp2v3))
  p3 <- 1 / (1 + exp(lp1v3) + exp(lp2v3))
  
  trt <- rmultinomial(1,3,c(p1,p2,p3),c(1,2,3))
  #trt3 as the reference
  if(trt==1) trtcontrast <- c(1,0)
  else if(trt==2) trtcontrast <- c(0,1)
  else trtcontrast <- c(0,0)
  
  return(list(trt=trt,trtcontrast=trtcontrast))
}


trtfun <- trtfun3

#linear v-learning
nsims <- 100
j <- 1
templist <- vector(mode="list",length=nsims)
this3 <- numeric(nsims)

time <- proc.time()
while(j<=nsims){
  print(j)
  
  temp <- batchsim3_inf_fuzzy( m,nsubj,maxtime,maxstage,
                             mumat0,covcube0,wvec,
                             trtfun, utilfun, 
                             optimal=FALSE,zipparm=NULL,only_u=TRUE)
  if(is.character(temp)) next
  else{
    this3list <- sapply(1:nsubj,function(k) mean(temp[[k]]))
    this3[j] <- mean(this3list)
    j <- j+1
  }
}
proc.time() - time


mean(this3)
sd(this3)

###################\#
#optimal deterministic
trtfun4 <- function(obj){
  argmax <- obj$state
  
  if(argmax==1){
    trt <- 1
    trtcontrast <- c(1,0)
  }else if(argmax==2){
    trt <- 2
    trtcontrast <- c(0,1)
  }else{
    trt <- 3
    trtcontrast <- c(0,0)
  }
  
  return(list(trt=trt,trtcontrast=trtcontrast))
}


trtfun <- trtfun4

#linear v-learning
nsims <- 100
j <- 1
templist <- vector(mode="list",length=nsims)
this4 <- numeric(nsims)

time <- proc.time()
while(j<=nsims){
  print(j)
  
  temp <- batchsim3_inf_fuzzy( m,nsubj,maxtime,maxstage,
                         mumat0,covcube0,wvec,
                         trtfun, utilfun, 
                         optimal=FALSE,zipparm=NULL,only_u=TRUE)
  if(is.character(temp)) next
  else{
    this4list <- sapply(1:nsubj,function(k) mean(temp[[k]]))
    this4[j] <- mean(this4list)
    j <- j+1
  }
}
proc.time() - time

mean(this4)
