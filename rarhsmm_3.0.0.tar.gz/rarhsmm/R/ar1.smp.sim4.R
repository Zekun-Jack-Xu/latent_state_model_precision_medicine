######################################################################
#' Simulate an infinite-horizon continuous-time POMDP where states are random multinomial
#' distribution with dirichlet parameters.
#' @param maxtime a scalar for the maximum potential time for the last decision point.
#' @param maxstage a scalar for the maximum number of stages.
#' @param mod list consisting of the following items: 
#' mod$m = number of states; 
#' mod$dirparm = vector of dirichlet parameters
#' mod$mumat = matrix of the conditional means for the multivariate normal 
#' distributions in each latent state;
#' mod$covcube = 3-dimensional array of the conditional variances for the multivariate
#' normal distributions in each latent state;
#' mod$arcube = 3-dimensional array of the conditional autoregressive coefficients
#' in each latent state.
#' @param initialprob a vector of initial state probabilities
#' @param zeroparm a vector of parameters for the logit of termination probability 
#' at each decision stage. The parameters are intercept, slope for treatment and 
#' slopes for posterior probabilities (except last state).
#' @param rateparm a vector of parameters for log rate of exponential interarrival time. 
#' The parameters are intercept, slope for treatment and slopes for posterior 
#' probabilities (except last state)
#' @param trtfun function object that defines the decision rule
#' @param utilfun function object that defines the utility
#' @param ktrt ktrt
#' @return a list containing the realized time points(1:K), simulated series(2:K), 
#' states(1:K), treatment(1:K), state probabilities (1:K).
#' @useDynLib rarhsmm, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom graphics points
#' @importFrom stats rnorm
#' @importFrom glmnet glmnet
#' @export
ar1.smp.sim4 <- function(maxtime, maxstage, mod, initialprob,
                         zeroparm, rateparm,
                         trtfun, utilfun, ktrt=3){
  
  m <- mod$m
  covcube <- mod$covcube
  arcube <- mod$arcube
  mumat <- mod$mumat
  p <- length(mod$mumat[1,])
  delta <- initialprob
  #scalemat <- mod$scalemat
  dirparm <- mod$dirparm
  
  #result:  
  states <- NULL  #1:K
  series <- NULL  #2:K (the first obs is baseline)
  times <- NULL   #1:K
  trts <- NULL    #2:K
  stateprobs <- NULL  #1:K
  utility <- NULL  #2:K
  trtcontrasts <- NULL #2:K
  
  #initialize
  
  laststate <- rmultinomial(1, m, delta, 1:m)
  states <- c(states, laststate)
  
  laststateprob <- delta
  stateprobs <- rbind(stateprobs, laststateprob)
  
  lasttime <- 1
  times <- c(times, lasttime)
  
  stage <- 1
  
  lastseries <- rep(0, ncol(mumat))
  lastobj <- list(delta=delta, x=lastseries)
  thistrtcontrast <- rep(0, ktrt)
    
  visitx <- c(1, laststateprob[1:(m-1)])
  zeroprop <- exp(visitx%*%zeroparm)/(1+exp(visitx%*%zeroparm))
  
  
    exprate <- exp(visitx%*%rateparm)
    nexttime <- lasttime + ceiling(rexp(1, rate=exprate))
    
    #recursion
    while(nexttime<=maxtime & stage < maxstage){
      
      
      times <- c(times, nexttime)
      
      tempx <- c(1, thistrtcontrast) #trt[j] is trt at j-1
      #tpm <- get_transit(tempx, scalemat, nexttime-lasttime,m)
      pparm <- rexp(dirparm) 
      pparm <- pparm / sum(pparm)
      
      thisstate <- rmultinomial(1, m, pparm, 1:m)
      
      if(length(times)==2) {tempmean <- mumat[thisstate,]}else{
        tempmean <- mumat[thisstate,] + arcube[,,thisstate] %*% t(lastseries)}
      thisseries <- mvrnorm(1, tempmean, covcube[,,thisstate])
      
      nodeprob <- rep(NA, m)
      for(jj in 1:m){
        if(length(times)==2){ tempmean <- mumat[jj,]}else{
          temppmean <- mumat[jj,] + arcube[,,jj] %*% t(lastseries)}
        nodeprob[jj] <- mvdnorm(thisseries, tempmean, covcube[,,jj],FALSE)
      }
      
      foo <- pparm * nodeprob
      sumfoo <- sum(foo)
      thisstateprob <- foo / sumfoo
      
      ##################  
        obj <- list(delta=thisstateprob, x=thisseries,state=thisstate,
                    lastobj=lastobj, mod=mod, interval=nexttime-lasttime)
        
        trtobj <- trtfun(obj)
        thistrt <- trtobj$trt
        thistrtcontrast <- trtobj$trtcontrast
        obj$trt <- thistrt
        
      thisutil <- utilfun(obj)
      
      #update
      lasttrtcontrast <- thistrtcontrast
      lasttime <- nexttime
      laststate <- thisstate
      lastseries <- thisseries
      laststateprob <- thisstateprob
      lasttrt <- thistrt
      lastobj <- obj
      lastutil <- thisutil
      
      states <- c(states,laststate)
      series <- rbind(series,lastseries)
      utility <- c(utility, lastutil)
      stateprobs <- rbind(stateprobs, laststateprob)
      trts <- c(trts, lasttrt)
      trtcontrasts <- rbind(trtcontrasts,lasttrtcontrast)
      
      #check if any more visits
      visitx <- c(1, laststateprob[1:(m-1)])
      zeroprop <- exp(visitx%*%zeroparm)/(1+exp(visitx%*%zeroparm))
      
      terminate <- runif(1)
      if(terminate<=zeroprop){
        break
      }else{
        exprate <- exp(visitx%*%rateparm)
        nexttime <- lasttime + ceiling(rexp(1, rate=exprate))
        stage <- stage + 1
      }
    }
    rownames(stateprobs) <- NULL
    return(list(series=series, states=states, times=times, 
                trts=trts, trtcontrasts=trtcontrasts,
                stateprobs=stateprobs,utility=utility))
  
}





##############################################
#get the matrix of shape and scale parameters
ssmat <- function(x, shapemat, scalevec){
  result <- matrix(NA, nrow=length(scalevec), ncol=2)
  for(j in 1:length(scalevec)){
    result[j,2] <- scalevec[j]
    result[j,1] <- exp(x %*% shapemat[j,]) / scalevec[j]
  }
  return(result)
}

#########
#convolution
convr <- function(vec1, vec2, m){
  result <- 0
  for(i in 1:(m-1)) result <- result + vec1[m-i] * vec2[i]
  return(result)
}

#general case: 
#each row of parmmat is the offdiagonal gamma shape and scale
smp <- function(parmmat, M, time, ngrid, lower){
  
  pp <- array(0,dim=c(M,M,ngrid))
  pp[,,1] <- diag(1,M) #initialize pp at 0
  
  grids <- seq(lower, time, length=ngrid)
  h <- median(diff(grids))
  
  densities <- array(0, dim=c(M,M,ngrid))
  cdfs <- array(0, dim=c(M,M,ngrid))
  
  for(m in 1:ngrid){
    nextindex <- 1
    for(i in 1:M) {
      for(j in 1:M){
        if(i!=j){
          densities[i,j,m] <- dgamma(grids[m],
                                     shape=parmmat[nextindex,1],
                                     scale=parmmat[nextindex,2])
          cdfs[i,j,m] <- pgamma(grids[m],
                                shape=parmmat[nextindex,1],
                                scale=parmmat[nextindex,2])
          nextindex <- nextindex + 1
        }
      }
    }
  }
  
  
  
  for(m in 2:ngrid){
    for(i in 1:M){
      for(j in 1:M){
        if(i!=j){
          
          pp[i,j,m] <- 0
          
          for(k in 1:M){
            if(k!=i){
              vec1 <- pp[k,j,1:(m-1)]
              #must normalize!!!
              vec2 <- rep(NA, m-1)
              for(n in 1:(m-1)){
                vec2[n] <- densities[i,k,n]*cdfs[i,k,n]/sum(cdfs[i,,n])
              }
              
              pp[i,j,m] <- pp[i,j,m] + h*convr(vec1,vec2,m)
            }
          }
        }
      }
    }
    for(i in 1:M) pp[i,i,m] <- max(0,1 - sum(pp[i,,m]))
    
  }
  return(pp[,,ngrid])
  
}


