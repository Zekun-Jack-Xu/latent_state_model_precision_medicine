######################################################################
#' value given policyparm
#' @param policyparm policyparm
#' @param valueparm valueparm
#' @param nsubj nsubj
#' @param data data
#' @param valuename1 valuename1
#' @param valuename2 valuename2
#' @param policyname policyname
#' @param disfactor disfactor
#' @param ppsmat ppsmat
#' @param ktrt ktrt
#' @param type type
#' @return value
#' @useDynLib rarhsmm, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom graphics points
#' @importFrom stats rnorm
#' @importFrom glmnet glmnet
#' @export
value_dis <- function(policyparm, valueparm, nsubj, data,
valuename1, valuename2,  policyname,
disfactor,ppsmat,ktrt, type="stochastic"){
    
    utility <- data$u
    trt <- data$trt
    #pps <- data$pps
    valuemat1 <- cbind(1, data.matrix(data)[,valuename1,drop=FALSE])
    valuemat2 <- cbind(1, data.matrix(data)[,valuename2,drop=FALSE])
    policymat <- data.matrix(data)[,policyname,drop=FALSE]
    p2 <- length(policyname)+1
    policyparmmat <- matrix(policyparm,nrow=ktrt-1,ncol=p2,byrow=TRUE)
    
    if(type=="stochastic"){
        val <- value_dis_c(nsubj, valueparm, valuemat1, valuemat2,
        policyparmmat, policymat,utility, trt, ppsmat, disfactor)
    }else{
        val <- value_dis_det_c(nsubj, valueparm, valuemat1, valuemat2,
        policyparmmat, policymat,utility, trt, ppsmat, disfactor)
    }
    
    return(val)
    
}
