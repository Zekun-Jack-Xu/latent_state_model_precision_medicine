######################################################################
#' value given fixed policy
#' @param augvalueparm augvalueparm
#' @param nsubj nsubj
#' @param data data
#' @param valuename1 valuename1
#' @param predtrt predtrt
#' @param pps pps
#' @param ktrt ktrt
#' @param tausq tausq
#' @param kappa kappa
#' @param type type
#' @param tuning tuning
#' @return value
#' @useDynLib rarhsmm, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom graphics points
#' @importFrom stats rnorm
#' @importFrom glmnet glmnet
#' @export
Lambda_det_avg <- function(augvalueparm, nsubj, data,
valuename1, valuename2,  predtrt, pps, ktrt, tausq=0.0625,
kappa=c(0,0.25,0.5,0.75,1),
type=1, tuning=0.001){
    
    
    #separate datamat into valuemat and policymat
    #separate parms into valueparm and policyparm
    utility <- data$u
    trt <- data$trt
    #pps <- data$pps 
    valueparm <- augvalueparm[-length(augvalueparm)]
    vavg <- augvalueparm[length(augvalueparm)]
    
    valuemat1 <- data.matrix(data)[,valuename1,drop=FALSE]
    valuemat2 <- data.matrix(data)[,valuename2,drop=FALSE]
    
    
    val <- lambdaEEavg_det(nsubj, valueparm, valuemat1, valuemat2,
    predtrt, utility, trt, pps, tausq, kappa,
    type, tuning, vavg)
    
    return(val)
    
}
