######################################################################
#' negative policy value given valueparm
#' @param formula formula
#' @param valueparm valueparm
#' @param nsubj nsubj
#' @param augdata augdata
#' @param valuename1 valuename1
#' @param valuename2 valuename2
#' @param disfactor disfactor
#' @param ppsmat ppsmat
#' @param tausq tausq
#' @param kappa kappa
#' @param type type
#' @param tuning1 tuning1
#' @param maxit maxit
#' @param eps eps
#' @param control control
#' @param print print
#' @return value
#' @useDynLib rarhsmm, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom graphics points
#' @importFrom stats rnorm
#' @importFrom glmnet glmnet
#' @importfrom rpart rpart
#' @export
fit.rpart.dis <- function(formula, valueparm,
nsubj, augdata, valuename1, valuename2,
disfactor, ppsmat, tausq=0.0625,
kappa=c(0,0.25,0.5,0.75,1),
type=1,  tuning1=1e-8,
maxit=1, eps=1e-3,
control=list(minsplit=10, maxdepth=4, xval=5,cp=0.001),
print=TRUE){
    
    #start with value parm all zeros
    pps <- sapply(1:nrow(ppsmat), function(k) ppsmat[k, augdata$trt[k]])
    ktrt <- ncol(ppsmat)
    
    # weighted by centralized value
    augdata$v <- (augdata$u +  disfactor[1] *
    cbind(1, data.matrix(augdata[,valuename2])) %*%
    valueparm -
    cbind(1, data.matrix(augdata[,valuename1])) %*%
    valueparm ) / pps
    
    #augdata$weight <- abs(augdata$v)
    augdata$weight <- ifelse(augdata$v > 0, augdata$v, 0)
    
    #augdata$label <- sapply(1:length(pps), function(k){
    #    if(augdata$v[k] >= 0){
    #        res <- augdata$trt[k]
    #    }else{
    #        pool <- 1:ktrt
    #        prob <- ppsmat[k,]
    #        #sample according to ppsmat!
    #        thistrt <- augdata$trt[k]
    #        exclude <- which(pool==thistrt)
    #        pool <- pool[-exclude]
    #        prob <- prob[-exclude] / sum(prob[-exclude])
    #        res <- sample(pool, 1, prob=prob)
    #    }
    #    return(res)}
    #)
    augdata$label <- augdata$trt
    
    
    #oldparm <- valueparm
    oldval <- mean(augdata$u)
    
    for(k in 1:maxit){
        
        tempfit <- rpart(as.formula(formula),
        data=augdata, method="class", weights=weight,
        control=control)
        ptrt <- predict(tempfit, newdata=augdata[,valuename1], type="class")
        
        
        tempv <- optim(valueparm, Lambda_det_dis,
        nsubj=nsubj,data=augdata,
        valuename1=valuename1, valuename2=valuename2,
        predtrt=ptrt,
        disfactor=disfactor,pps=pps,
        ktrt=ktrt,tausq=tausq,
        kappa=kappa, type=type, tuning=tuning1,
        control=list(maxit=1000))
        
        newparm <- tempv$par
        
        vcol <- (augdata$u + disfactor[1] *
        cbind(1, data.matrix(augdata[,valuename2])) %*%
        newparm )  / pps
        
        newval <- mean(ifelse(ptrt==augdata$trt,1,0) * vcol)
        
        reldiff <- (newval - oldval) / (1 + sum(abs(newval)))
   
        if(reldiff <= eps & k > 1){
            break
        }else{
            valueparm <- newparm
            oldval <- newval
            #oldparm <- newparm
            
            # weighted by centralized value
            augdata$v <- vcol - (cbind(1, data.matrix(augdata[,valuename1])) %*%
            valueparm ) / pps
            
            #augdata$weight <- abs(augdata$v)
            augdata$weight <- ifelse(augdata$v > 0, augdata$v, 0)
            
            #augdata$label <- sapply(1:length(pps), function(k){
            #    if(augdata$v[k] >= 0){
            #        res <- augdata$trt[k]
            #    }else{
            #        pool <- 1:ktrt
            #        prob <- ppsmat[k,]
            #        #sample according to ppsmat!
            #        thistrt <- augdata$trt[k]
            #        exclude <- which(pool==thistrt)
            #        pool <- pool[-exclude]
            #        prob <- prob[-exclude] / sum(prob[-exclude])
            #        res <- sample(pool, 1, prob=prob)
            #    }
            #    return(res)}
            #)
            augdata$label <- augdata$trt
            
            if(print==TRUE) {
                cat("iter:", k, "; reldiff:", reldiff, "; value:", oldval, "\n")
                print(valueparm)
            }
        }
        
    }
    return(list(valueparm=valueparm, tree=tempfit))
}
    
