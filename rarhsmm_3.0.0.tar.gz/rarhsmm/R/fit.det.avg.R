######################################################################
#' negative policy value given valueparm
#' @param augvalueparm valueparm
#' @param policyparm policyparm
#' @param nsubj nsubj
#' @param augdata augdata
#' @param valuename1 valuename1
#' @param valuename2 valuename2
#' @param policyname policyname
#' @param ppsmat ppsmat
#' @param ktrt ktrt
#' @param tausq tausq
#' @param kappa kappa
#' @param type type
#' @param tuning1 tuning1
#' @param tuning2 tuning2
#' @param maxit maxit
#' @param eps eps
#' @param print print
#' @return value
#' @useDynLib rarhsmm, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom graphics points
#' @importFrom stats rnorm
#' @importFrom glmnet glmnet
#' @export
fit.det.avg <- function(augvalueparm, policyparm,
nsubj, augdata, valuename1, valuename2, policyname,
ppsmat, ktrt, tausq=0.0625,
kappa=c(0,0.25,0.5,0.75,1),
type=1,  tuning1=1, tuning2=1,
maxit=1,eps=1e-3,
print=TRUE,...){
    
    #start with value parm all zeros
    
    temppol <- optim(policyparm, V_sto_avg,
    augvalueparm=augvalueparm,
    nsubj=nsubj,data=augdata,
    valuename1=valuename1, valuename2=valuename2,
    policyname=policyname, ppsmat=ppsmat,
    ktrt=ktrt,tausq=tausq,
    kappa=kappa, type=type, tuning=tuning2,
    method="BFGS",...)
    
    policyparm <- temppol$par
    old_par_pol <- temppol$par
    old_nllk_pol <- temppol$val
    
    for(k in 1:maxit){
        if(print==TRUE) cat("iteration:", k,"\n")
        
        tempv <- optim(augvalueparm, Lambda_sto_avg,
        policyparm=policyparm,
        nsubj=nsubj,ppsmat=ppsmat,data=augdata,
        valuename1=valuename1, valuename2=valuename2,
        policyname=policyname, ktrt=ktrt,tausq=tausq,
        kappa=kappa, type=type, tuning=tuning1,
        method="BFGS")
        
        augvalueparm <- tempv$par
        
        temppol <- optim(policyparm, V_sto_avg,
        augvalueparm=augvalueparm,
        nsubj=nsubj,data=augdata,
        valuename1=valuename1, valuename2=valuename2,
        policyname=policyname, ppsmat=ppsmat,
        ktrt=ktrt,tausq=tausq,
        kappa=kappa, type=type, tuning=tuning2,
        method="BFGS",...)
        
        policyparm <- temppol$par
        new_par_pol <- temppol$par
        new_nllk_pol <- temppol$value
        
        tol1 <- sum(abs(new_par_pol-old_par_pol))/sum(abs(old_par_pol))
        tol2 <- abs(new_nllk_pol - old_nllk_pol)/abs(old_nllk_pol)
        tol3 <- abs(new_nllk_pol - old_nllk_pol)
        if( tol1 < eps & (tol2 < eps | tol3 < eps)){
            break
        }else{
            old_nllk_pol <- new_nllk_pol
            old_par_pol <- new_par_pol
        }
        if(print==TRUE) {
            cat("reldiff_pol:", tol1,"; -value",-augvalueparm[length(augvalueparm)],"\n")
            print(augvalueparm)
            print(policyparm)
        }
    }
    
    
    return(list(augvalueparm=augvalueparm,policyparm=policyparm))
}
