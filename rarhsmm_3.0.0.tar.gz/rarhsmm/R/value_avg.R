######################################################################
#' negative policy value given valueparm
#' @param policyparm policyparm
#' @param augvalueparm augvalueparm
#' @param nsubj nsubj
#' @param data data
#' @param valuename1 valuename1
#' @param valuename2 valuename2
#' @param policyname policyname
#' @param ppsmat ppsmat
#' @param ktrt ktrt
#' @param type type
#' @return value
#' @useDynLib rarhsmm, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom graphics points
#' @importFrom stats rnorm
#' @importFrom glmnet glmnet
#' @export
value_avg <- function(policyparm, augvalueparm,
nsubj, data,
valuename1, valuename2,  policyname,
ppsmat,ktrt, type="stochastic"){
    
    
    utility <- data$u
    trt <- data$trt
    #pps <- data$pps
    subjden <- data$subjden
    
    timediff <- data$timediff
    thisstate <- data$thisstate
    valuemat1 <- cbind(1, data.matrix(data)[,valuename1,drop=FALSE])
    valuemat2 <- cbind(1, data.matrix(data)[,valuename2,drop=FALSE])
    policymat <- data.matrix(data)[,policyname,drop=FALSE]
    valueparm <- augvalueparm[-length(augvalueparm)]
    
    p2 <- length(policyname)+1
    policyparmmat <- matrix(policyparm,nrow=ktrt-1,ncol=p2,byrow=TRUE)
    
    if(type=="stochastic"){
        val <- value_avg_c(nsubj, valueparm, valuemat1, valuemat2,
            policyparmmat, policymat,utility, trt, ppsmat)
    }else{
        val <- value_avg_det_c(nsubj, valueparm, valuemat1, valuemat2,
        policyparmmat, policymat,utility, trt, ppsmat)
    }
    
    return(val)
}
