######################################################################
#' negative policy value given valueparm
#' @param valueparm valueparm
#' @param policyparm policyparm
#' @param nsubj nsubj
#' @param augdata augdata
#' @param valuename1 valuename1
#' @param valuename2 valuename2
#' @param policyname policyname
#' @param disfactor disfactor
#' @param ppsmat ppsmat
#' @param trt trt
#' @param tausq tausq
#' @param kappa kappa
#' @param type type
#' @param tuning1 tuning1
#' @param tuning2 tuning2
#' @param maxit maxit
#' @param eps eps
#' @param nstart nstart
#' @param print print
#' @return value
#' @useDynLib rarhsmm, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom graphics points
#' @importFrom stats rnorm
#' @importFrom glmnet glmnet
#' @export
fit.grid.dis <- function(valueparm, policyparm,
nsubj, augdata, valuename1, valuename2, policyname,
disfactor, ppsmat,
trt, tausq=0.0625,
kappa=c(0,0.25,0.5,0.75,1),
type=1,  tuning1=1, tuning2=1,
maxit=1,eps=1e-3,nstart=1,
print=TRUE){
    
    #start with value parm all zeros
    pps <- sapply(1:nrow(ppsmat), function(k) ppsmat[k, trt[k]])
    ktrt <- max(trt)
    p2 <- length(policyname) + 1
    
    pol <- NULL
    tempmin <- 999999
    
    if(nstart == 1){
        temppol <- optim(policyparm, V_grid_dis,
        valueparm=valueparm,
        nsubj=nsubj,data=augdata,
        valuename1=valuename1, valuename2=valuename2,
        policyname=policyname,
        disfactor=disfactor,ppsmat=ppsmat,
        ktrt=ktrt,tausq=tausq,
        kappa=kappa, type=type, tuning=tuning2,
        control=list(maxit=5000))
        
        policyparm <- temppol$par
        tempmin <- temppol$value
    }else{
      for(i in 1:nstart){
        
            policyparm <- runif(p2*(ktrt-1),-2,2)
        
            temppol <- optim(policyparm, V_grid_dis,
            valueparm=valueparm,
            nsubj=nsubj,data=augdata,
            valuename1=valuename1, valuename2=valuename2,
            policyname=policyname,
            disfactor=disfactor,ppsmat=ppsmat,
            ktrt=ktrt,tausq=tausq,
            kappa=kappa, type=type, tuning=tuning2,
            control=list(maxit=5000))
            if(temppol$value < tempmin){
                tempmin <- temppol$value
                policyparm <- temppol$par
            }
   
      }
    }
 
    old_par_pol <- policyparm
    old_nllk_pol <- tempmin
    
    for(k in 1:maxit){
        if(print==TRUE) cat("iteration:", k,"\n")
        
        policyparmmat <- matrix(policyparm,nrow=ktrt-1,ncol=p2,byrow=TRUE)
        predtrt <- sapply(1:nrow(ppsmat),
            function(jj) getmaxtrt(policyparmmat, data.matrix(augdata[jj,policyname]))  )
        
        tempv <- optim(valueparm, Lambda_det_dis,
        nsubj=nsubj,data=augdata,
        valuename1=valuename1, valuename2=valuename2,
        predtrt=predtrt,
        disfactor=disfactor, pps=pps,
        ktrt=ktrt,tausq=tausq,
        kappa=kappa, type=type, tuning=tuning1,
        method="BFGS")
        
        valueparm <- tempv$par
        
        
            temppol <- optim(policyparm, V_grid_dis,
            valueparm=valueparm,
            nsubj=nsubj,data=augdata,
            valuename1=valuename1, valuename2=valuename2,
            policyname=policyname,
            disfactor=disfactor,ppsmat=ppsmat,
            ktrt=ktrt,tausq=tausq,
            kappa=kappa, type=type, tuning=tuning2,
            control=list(maxit=5000))
            
        policyparm <- temppol$par
        
        new_par_pol <- policyparm
        new_nllk_pol <- temppol$value
        
        
        tol1 <- sum(abs(new_par_pol-old_par_pol))/sum(abs(old_par_pol))
        tol2 <- abs(new_nllk_pol - old_nllk_pol)/abs(old_nllk_pol)
        tol3 <- abs(new_nllk_pol - old_nllk_pol)
        if( tol1 < eps & (tol2 < eps | tol3 < eps)){
            break
        }else{
            old_nllk_pol <- new_nllk_pol
            old_par_pol <- new_par_pol
        }
        if(print==TRUE) {
            cat("reldiff_pol:", tol1,"; -value",old_nllk_pol,"\n")
            print(valueparm)
            print(policyparm)
        }
    }
    
    return(list(valueparm=valueparm,policyparm=policyparm))
}
