######################################################################
#' Fit a infinite-horizon continuous-time first-order autoregressive Gaussian 
#' semi-Markov process. Assume a binary treatment {0,1}. The initial
#' probabilities are already estimated from the baseline characteristics.
#' The transitions only depend on treatment, which is assigned according
#' to a random or deterministic policy.
#' @param mod list consisting of the following items: 
#' mod$m = number of states; 
#' mod$delta = vector of initial probabilities; 
#' mod$scalemat = matrix of the coefficients in the scale parameters for the
#' transition rate matrix;
#' mod$mumat = matrix of the conditional means for the multivariate normal 
#' distributions in each latent state;
#' mod$covcube = 3-dimensional array of the conditional variances for the multivariate
#' normal distributions in each latent state;
#' mod$arcube = 3-dimensional array of the conditional autoregressive coefficients
#' in each latent state.
#' @param timelist a list of observed time points for each subject.
#' @param initiallist a list of initial state probabilities for each subject.
#' @param xlist a list of time-varying covariates for each subject.
#' @param trtlist a list of time-dependent treatment for each subject.
#' @param nullid a vector of subject ids who only has baseline measurements. 
#' Default to -1.
#' @param mfactor momentum factor. Default to 0.1.
#' @param stepsize Default to 0.001.
#' @param maxit Default to 100.
#' @param eps Default to 1e-3.
#' @param ar_diag whether the autoregression matrix is diagonal. Default to FALSE.
#' @param cov_diag whether the covariance matrix is diagonal. Default to FALSE.
#' @param print Default to TRUE.
#' @return a list containing the parameter estimates
#'
#' @useDynLib rarhsmm, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom graphics points
#' @importFrom stats rnorm
#' @importFrom glmnet glmnet
#' @importFrom pracma grad
#' @export
ar1.smp.fit2 <- function(mod, timelist, initiallist, xlist, trtlist, 
                         nullid=-1, mfactor=0.1,
                         stepsize=0.001,maxit=100,eps=1e-3,
                         ar_diag=FALSE, cov_diag=FALSE, print=TRUE){
  allparm <- ar1.smp.workparm1(mod)
  allparm <- allparm + runif(length(allparm), -0.1, 0.1)
  ncolx <- ncol(xlist[[1]])
  ncolscale <- ncol(trtlist[[1]])
  nsubj <- length(xlist)
  m <- mod$m
  velocity <- 0
  
  oldnllk <- ar1_smp_nllk1(allparm, timelist, initiallist, m,  
                           ncolscale,xlist, ncolx, trtlist,
                           nsubj, nullid)
  
  for(k in 1:maxit){
    if(print==TRUE) cat("iteration:", k, "; nllk:", oldnllk,"\n")
    gradient <- pracma::grad(f=ar1_smp_nllk1,x0=allparm,
                             timelist=timelist,M=m,
                             initiallist=initiallist, 
                             ncolscale=ncolscale,x=xlist,ncolx=ncolx,
                             trt=trtlist,nsubj=nsubj,nullid=nullid)
    
    #momentum gradient
    velocity <- mfactor * velocity + gradient / nsubj
    allparm <- allparm - stepsize * velocity
    
    #allparm <- allparm - stepsize / nsubj * gradient
    newnllk <- ar1_smp_nllk1(allparm, timelist, initiallist, m,  
                             ncolscale,xlist, ncolx, trtlist,
                             nsubj, nullid)
    if(abs(oldnllk-newnllk)/abs(oldnllk) < eps | newnllk > oldnllk){
      newnllk <- oldnllk
      allparm <- allparm + stepsize / nsubj * gradient
      break
    }else{oldnllk <- newnllk}
  }
  
  nllk <- newnllk
  workparm <- allparm
  natparm <- retrieve_ar1smp(workparm, m, ncolscale, ncolx)
  natparm$m <- m
  
  #need to filter the state probs for all subjects
  #estimate the covariance and vector autoreg ad hoc
  foolist <- vector(mode="list",length=nsubj)
  
  for(k in 1:nsubj){
    if(nrow(trtlist[[k]])==1) foolist[[k]] <- NULL
    else foolist[[k]] <- ar1.smp.filter1(timelist[[k]], natparm, 
                                         initiallist[[k]],trtlist[[k]],xlist[[k]])[-1,]
  }
  
  if(length(foolist)<nsubj) {
    foolist[[nsubj+1]] <- 1
    foolist[[nsubj+1]] <- NULL
  }
  
  #gather the predictors, response
  prevx <- tomat(xlist,"last")
  nextx <- tomat(xlist,"first")
  weight <- tomat(foolist,"first")
  weightsum <- colSums(weight)
  
  ar_est <- array(0, dim=c(ncolx,ncolx,mod$m))
  cov_est <- array(0, dim=c(ncolx,ncolx,mod$m))
  
  #ad hoc estimates on covariance matrix via glmnet
  for(l in 1:mod$m){
    model <- glmnet::glmnet(prevx,nextx,family="mgaussian",lambda=0.0001,alpha=0,
                            intercept = T,standardize = F,weights=weight[,l])
    
    tempcoef <- glmnet::coef.glmnet(model)
    coefmat <- tempcoef[[1]]
    for(p in 2:ncol(prevx)) coefmat <- cbind(coefmat, tempcoef[[p]])
    coefmat <- as.matrix(coefmat)
    temp_ar <- coefmat[-1,]
    for(rr in 1:ncolx){ 
      temp_ar[rr,] <- natparm$arcube[rr,rr,l] * temp_ar[rr,] / temp_ar[rr,rr]
      temp_ar[rr,-rr] <- 0.5 * temp_ar[rr,-rr]
    }
    ar_est[,,l] <- temp_ar
    
    
    expandrow <- weight[,l] %*% t(rep(1,ncol(prevx)))
    yhat <- glmnet:::predict.mrelnet(model,prevx,type="response")[,,1]
    resid <- nextx - yhat
    rprodvar <- resid * expandrow
    tempcov <- t(rprodvar) %*% resid / weightsum[[l]]
    for(rr in 1:ncolx){
      tempcov[rr,] <- natparm$covcube[rr,rr,l] * tempcov[rr,] / tempcov[rr,rr]
      #tempcov[rr,-rr] <- 0.5 * tempcov[rr,-rr]
    }
    cov_est[,,l] <- tempcov
  }
  
  if(ar_diag==FALSE)natparm$arcube <- ar_est
  if(cov_diag==FALSE)natparm$covcube <- cov_est
  
  return(list(nllk=nllk,natparm=natparm,workparm=workparm))
}


#############################
#function to get the natural parameters to working parameters
ar1.smp.workparm1 <- function(mod){
  m <- mod$m
  covcube <- mod$covcube
  arcube <- mod$arcube
  mumat <- mod$mumat
  p <- length(mod$mumat[1,])
  scalemat <- mod$scalemat
  
  allparm <- NULL
  for(i in 1:nrow(scalemat))
    allparm <- c(allparm, scalemat[i,])
  
  
  for(i in 1:nrow(mumat))
    allparm <- c(allparm, mumat[i,])
  
  for(i in 1:dim(covcube)[3]){
    allparm <- c(allparm, log(diag(covcube[,,i])) )
  }
  
  #compound symmetry
  #for(i in 1:dim(covcube)[3]){
  #  allparm <- c(allparm, glogit(max(covcube[1,2,i],0.01)/(0.9*min(diag(covcube[,,i]))) ))
  #}
  
  #tanh = (e^x-e^(-x))/(e^x+e^(-x))
  #tanh^(-1) = 0.5 * log ((1+x)/(1-x))
  for(i in 1:dim(arcube)[3]){
    tempvec <- diag(arcube[,,i])
    tempvec <- 0.5 * log((1+tempvec)/(1-tempvec))
    allparm <- c(allparm, tempvec)
  }
  
  return(allparm)
}

############################
#function to convert list into matrix by removing #rows <= 1
tomat <- function(input, remove="first"){
  
  nsubj <- length(input)
  
  if(remove=="first"){
    for(id1 in 1:nsubj){
      temprow <- nrow(input[[id1]])
      if( !is.null(temprow) & temprow > 1 ){
        result <- input[[id1]][-1,]
        break
      }
    }
    
    for(id2 in (id1+1):nsubj){
      temprow <- nrow(input[[id2]])
      if(is.null(temprow)) {
        next
      }else if(temprow<=1){
        next
      }else{
        result <- rbind(result, input[[id2]][-1,])
      }
    }
  }else if(remove=="last"){
    for(id1 in 1:nsubj){
      temprow <- nrow(input[[id1]])
      if( !is.null(temprow) & temprow > 1 ){
        result <- input[[id1]][-temprow,]
        break
      }
    }
    
    for(id2 in (id1+1):nsubj){
      temprow <- nrow(input[[id2]])
      if(is.null(temprow)) {
        next
      }else if(temprow<=1){
        next
      }else{
        result <- rbind(result, input[[id2]][-temprow,])
      }
    }
  }
  return(result)
}
