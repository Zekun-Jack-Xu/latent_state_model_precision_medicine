######################################################################
#' generate multinomial random variables
#' @param n number of random variables
#' @param k number of categories
#' @param prob vector of probabilities
#' @param label vector of labels
#' @return multinomial random variables
#' @useDynLib rarhsmm, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom graphics points
#' @importFrom stats rnorm
#' @importFrom glmnet glmnet
#' @export
gen_multinomial <- function(n, k, prob, label){
    return(rmultinomial(n, k, prob, label))
}
