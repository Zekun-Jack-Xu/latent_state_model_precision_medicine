######################################################################
#' Compute the forward filtering probabilities for continuous-time first-order 
#' autoregressive Gaussian semi-Markov process.Assume a binary treatment {0,1}. 
#' The initial probabilities are already estimated from the baseline characteristics.
#' The transitions only depend on treatment, which is assigned according
#' to a random or deterministic policy.
#' @param timepoints a vector of timepoints for potential observations.
#' @param mod list consisting of the following items: 
#' mod$m = number of states; 
#' mod$delta = vector of initial probabilities; 
#' mod$scalemat = matrix of the coefficients in the scale parameters for the
#' transition rate matrix;
#' mod$mumat = matrix of the conditional means for the multivariate normal 
#' distributions in each latent state;
#' mod$covcube = 3-dimensional array of the conditional variances for the multivariate
#' normal distributions in each latent state;
#' mod$arcube = 3-dimensional array of the conditional autoregressive coefficients
#' in each latent state.
#' @param initialprob a vector of initial state probabilities.
#' @param trt a matrix of time-dependent treatment assignments
#' @param covariates a matrix of time-varying covariates
#' @param posterior default to TRUE
#' @param lowpoint starting point of the integral approximation by finite sum. 
#' Default to 0.01.
#' @param ngrid an integer number of grid points to approximate integral by finite sum.
#' Default to 30.
#' @return a matrix containing the filtered state probabilities
#'
#' @useDynLib rarhsmm, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom graphics points
#' @importFrom stats rnorm
#' @importFrom glmnet glmnet
#' @export
ar1.smp.filter1 <- function(timepoints, mod, initialprob, trt, covariates, 
                           posterior=TRUE){
  ns <- length(timepoints)
  m <- mod$m
  covcube <- mod$covcube
  arcube <- mod$arcube
  mumat <- mod$mumat
  p <- length(mod$mumat[1,])
  scalemat <- mod$scalemat
  delta <- initialprob
  
  if(posterior==FALSE){
    single <- ar1_smp_nllk_single1(delta,scalemat,mumat,
                                  covcube,arcube,timepoints,m,covariates,
                                  trt)$alpha
  }else{
    single <- ar1_smp_fb(delta,scalemat,mumat,
                         covcube,arcube,timepoints,m,covariates,
                         trt)
  }
  return(single)
}


