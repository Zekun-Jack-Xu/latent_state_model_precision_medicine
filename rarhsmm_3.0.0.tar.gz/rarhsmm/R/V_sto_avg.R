######################################################################
#' negative policy value given valueparm
#' @param policyparm policyparm
#' @param augvalueparm augvalueparm
#' @param nsubj nsubj
#' @param data data
#' @param valuename1 valuename1
#' @param valuename2 valuename2
#' @param policyname policyname
#' @param ppsmat ppsmat
#' @param ktrt ktrt
#' @param tausq tausq
#' @param kappa kappa
#' @param type type
#' @param tuning tuning
#' @return value
#' @useDynLib rarhsmm, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom graphics points
#' @importFrom stats rnorm
#' @importFrom glmnet glmnet
#' @export
V_sto_avg <- function(policyparm, augvalueparm,
nsubj, data,
valuename1, valuename2,  policyname,
ppsmat,ktrt,tausq=0.0625,
kappa=c(0,0.25,0.5,0.75,1),
type=1, tuning=0.001){
    
    
    utility <- data$u
    trt <- data$trt
    #pps <- data$pps
    subjden <- data$subjden
    
    timediff <- data$timediff
    thisstate <- data$thisstate
    valuemat1 <- data.matrix(data)[,valuename1,drop=FALSE]
    valuemat2 <- data.matrix(data)[,valuename2,drop=FALSE]
    policymat <- data.matrix(data)[,policyname,drop=FALSE]
    valueparm <- augvalueparm[-length(augvalueparm)]
    
    p2 <- length(policyname)+1
    policyparmmat <- matrix(policyparm,nrow=ktrt-1,ncol=p2,byrow=TRUE)
    
    val <- vEEavg(nsubj, valueparm, valuemat1, valuemat2,
    policyparmmat, policymat,utility, trt,
    ppsmat, subjden, tausq,kappa,type,tuning)
    
    return(-val)
}
